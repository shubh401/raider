<template>
   <ici-input @blur="$emit('blur')" ref="iciinput" :label="label" :focus="focus" :value="value" :hint="hint" @input="input" @keyup-enter="enter" @select="select">
      <template slot-scope="list">
         <div class="company-item" v-html="boldKey(list.item.value,content)">{{list.item.value}}</div>
      </template>
   </ici-input>
</template>

<script>
   import {positionKey} from '../ajax/contact'
   import inputHint from '../mixin/input-hint'

   export default {
      mixins:[inputHint],
      name: "contact-title-input",
      methods: {
         getAjax(value){
			 positionKey(value).then((data) => {
               this.hint = data;
            }).catch((err) => {
               console.log(err)
            })
         }
      },
   }
</script>

<style scoped>
   .company-item {
      font-size: 15px;
      padding: 2px;
      color: #666;
      word-break: break-all;
      word-wrap: break-word;
      white-space: pre-wrap;
   }
</style>
