<template>
   <ici-input ref="iciinput" :label="label" :focus="focus" :value="value" :hint="hint" :required="required"
              @input="input" @keyup-enter="enter" @select="select">
      <template slot-scope="list">
         <div class="company-item">
            <span  class="flex-auto" v-html="boldKey(list.item.value,content)"></span>
         </div>
      </template>
   </ici-input>
</template>

<script>
   import {cityKey} from '../ajax/contact.js'
   import inputHint from '../mixin/input-hint.js'

   export default {
      mixins:[inputHint],
      name: "city-input",
      methods: {
         getAjax(value){
			 cityKey(value).then((data) => {

               this.hint = data.filter((val)=>{
                  return !this.filterIds.some(v=>v===val.id)
               });
            }).catch((err) => {
               console.log(err)
               this.$icimsg.error(err.msg||err);
            })
         },
      },
   }
</script>

<style scoped lang="less">
   .company-item {
      font-size: 15px;
      padding: 2px;
      color: #666;
      width:100%;
      word-break: break-all;
      word-wrap: break-word;
      white-space: pre-wrap;
      display: flex;
      >.flex-auto{
         margin-left:10px;
      }
   }
</style>
