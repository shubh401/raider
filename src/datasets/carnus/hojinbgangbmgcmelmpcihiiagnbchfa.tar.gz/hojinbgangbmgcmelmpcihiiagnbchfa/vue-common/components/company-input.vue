<template>

	<ici-input ref="iciinput" :label="label" :focus="focus" :value="value" :hint="hint" @input="input"
				  @keyup-enter="enter" @select="select">
		<template slot-scope="list">
			<div class="company-item" v-html="boldKey(list.item.value,content)">{{list.item.value}}</div>
		</template>
	</ici-input>

</template>

<script>
	import {companyKey} from '../ajax/contact.js'
	import inputHint from '../mixin/input-hint.js'

	export default {
		mixins: [inputHint],
		name: "company-input",
		methods: {
			getAjax(value) {
				return new Promise((resolve, reject) => {
					companyKey(value).then((data) => {
						this.hint = data;
						resolve(data)
					}).catch((err) => {
						console.log(err)
						reject(err)
					})
				})

			},
			enter(val) {

				if (val === -2) {
					var bool = false
					this.loading = true
					this.timeoutPromise.then(() => {

						bool = this.hint.some((val, index) => {
							if (val.value.toLowerCase() === this.content.toLowerCase()) {
								this.select(index)
								return true
							}
						});

						if (!bool) {
							this.$emit('select', {
								isAdd: true,
								value: this.content
							});
						}

					}).finally(() => {
						this.loading = false
					})


				}
			}
		},
	}
</script>

<style scoped>
	.company-item {
		font-size: 15px;
		padding: 2px;
		color: #666;
		width: 100%;
		word-break: break-word;
		word-wrap: break-word;
		white-space: pre-wrap;
	}
</style>
