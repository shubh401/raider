class DataItem {

	//@param item {Object} 本地数据
	constructor(item) {
		this.md5_code = '';
		this.updated = false; //是否已经更新
		this.whois = false;
		this.serverData = null;
		this.someNames = []; //同名人的数据

		this.directUpdate = false; //数据对比结果
		this.requestStatus = 0; //网络状态 0无请求，1请求中，2合并，3请求错误，4成功
		this.msg = '';
		if (item) {
			item.status = 1; //状态，0表示黄色，1表示绿色，3表示蓝色，2表示灰色
			this.data = item;
			//转首字母大写
			this.data.contact_name = this.capitalize(item.contact_name);
			this.data.company = this.capitalize(item.company);
			this.data.first_name = this.capitalize(item.first_name);
			this.data.last_name = this.capitalize(item.last_name);
			this.data.title = item.title ? item.title.split(/, ?| ?& ?/).join(',') : '';
		}

		//添加访问器属性，对比有无更新
		Object.defineProperty(this, 'isUpdate', {
			get() {
				var boolArray = this.contactIsUpdate();
				if (boolArray) {
					this.directUpdate = this.getDirectUpdate(boolArray);
					return boolArray.some((v) => {
						if (v.value) return false;
						else {
							console.log(v.name + '有更新', v.s, v.d)
							return true;
						}
					});
				} else {
					this.directUpdate = false;
					return false;
				}

			},
			set(bool) {
				this.updated = !bool;
			}
		});
	}


	//正在添加或编辑中
	requesting() {
		this.requestStatus = 1;
	}

	//请求添加或编辑成功操作
	//@param contact_id {Int} 联系人id
	//@param serverData|noUpdated {Object|boolean} 成功后的联系人数据 （可选）
	//
	requestSuccess(contact_id, serverData) {
		this.requestStatus = 4;
		this.contact_id = contact_id;
		if (serverData !== null && typeof serverData === 'object') {
			this.getServerData(serverData)
		} else if (serverData === false) {
			this.updated = false;
		} else {
			this.updated = true;
		}
	}

	//添加或编辑失败
	//@param msg {String} 失败的原因说明
	requestError(msg) {
		if (this.requestStatus === 1) {
			this.requestStatus = 3;
			this.msg = msg;
		}
	}

	//写入whois状态数据
	whoisData(data) {
		this.whois = data;
		return this;
	}

	//重新初始化
	init(items) {
		Object.assign(this, items)
		return this;
	}

	//为采集的联系人数据附上ID
	//如果联系人不存在 ID为0
	getServerData(serverData, noId) {

		this.contact_id = 0;
		this.serverData = '';
		if (typeof serverData == "object") {
			if (!noId) {
				this.contact_id = serverData.id || '';
			}
			this.serverData = serverData;
		}
		return this;
	}

	//对比本地数据和服务器数据是否有更新
	//return {Boolean} true有更新，false 无更新
	contactIsUpdate(d, s) {
		var d = this.data, s = this.serverData;
		var boolArray = []
		if (d && s && !this.updated) {

			//contact_name是否不同
			var isContactName = DataItem.comparisonText(d.contact_name, s.contact_name, 'contact_name', 1);
			boolArray.push(isContactName);
			//firstname 和 lastName是否不同
			var isFirstName = DataItem.comparisonText(d.first_name, s.first_name, 'first_name', 0);
			boolArray.push(isFirstName);

			var isLastName = DataItem.comparisonText(d.last_name, s.last_name, 'last_name', 0);
			boolArray.push(isLastName);

			//公司是否相同
			var isCompany = DataItem.comparisonText(d.company, s.company, 'company', 2);
			boolArray.push(isCompany)

			//城市是否相同
			var isCity = DataItem.comparisonText(d.city, s.city, 'city', 1);
			boolArray.push(isCity);

			//职位
			var isTitle = DataItem.comparisonArray(d.title, s.title, 'title', 1);
			boolArray.push(isTitle);

			var isInfo = {value: true, type: 'none', d: d.contact, s: s.info, name: 'contact', weight: 4};

			//联系人对比
			if (!d.contact || d.contact.length === 0) {
				isInfo.value = true;
				isInfo.type = 'none';
			} else if (!s.info || s.info.length === 0) {
				isInfo.value = false;
				isInfo.type = 'add';
			} else if (d.contact.length > s.info.length) {
				isInfo.value = false;
				isInfo.type = 'addto'
			} else {
				var bool = d.contact.every((val) => {
					return s.info.some((v) => {
						return v.type == val.type && funs.pageUniqueId(v.info) == funs.pageUniqueId(val.info);
					});
				});

				if (bool) {
					isInfo.value = true;
					isInfo.type = 'eq';
				} else {
					//必须是所有数据类型都是服务器上没有的，改成添加指命
					// var bool2 = d.contact.every(val => s.info.every(v => v.type !== val.type));
					// isInfo.type = bool2 ? 'add' : 'clash';
					isInfo.value = false;
					isInfo.type = 'add';
				}
			}

			boolArray.push(isInfo);
			var isImg = {value: true, type: 'none', d: d.img, s: s.imgs, name: 'img', weight: 4};

			//图片对比 isImg;
			if (this.md5_code) {
				if (s.imgs && s.imgs.length) {
					var bool = s.imgs.some(val => val.md5_code === this.md5_code);
					if (bool) {
						isImg.type = "eq"
					} else {
						isImg.type = "addto"
						isImg.weight = 0
						isImg.value = false
					}
				} else {
					isImg.value = false;
					isImg.type = 'add';
				}
			}

			boolArray.push(isImg);

			return boolArray
		} else {
			return false;
		}
	}

	//整理直接更新的数据
	getDirectUpdate(boolArray) {

		if (boolArray.some(val => val.type === 'add' || val.type == 'addto')) {

			//计算权重, 只计算eq(相等)和addto(追加)的权重，累加
			var weight = 0;
			boolArray.forEach((val) => {
				if (val.type == 'eq' || val.type == 'addto') weight += val.weight;
			});

			var obj = {};
			boolArray.forEach((val) => {
				if ((val.type === 'add' || val.type == 'addto')) {
					switch (val.name) {
						case 'contact_name':
						case 'first_name':
						case 'last_name':
						case 'company':
						case 'city':
						case 'title':
						case 'img':
							obj[val.name] = val.d;
							break;
						case 'contact':
							var arr = [];
							val.s.forEach((con) => {
								arr.push({type: con.type, info: con.info})
							});

							val.d.forEach((con) => {
								if (val.s.every((v) => v.info !== con.info)) {
									arr.push({type: con.type, info: con.info})
								}
							});

							obj['contact'] = arr;
							break;
					}
				}
			});

			obj.contact_id = this.contact_id || this.serverData.id || 0;
			obj.weight = weight;

			console.log('直接更新内容', obj)
			return obj;
		} else {
			return false;
		}
	}

	//对比两个值是否一样，一样返回true,d不存在也返回true
	//@param d {data}
	//@param s {serverData}
	//@return {Object} {value:Boolean/true 为不操作，即不合并也不添加,false为有变化，需要添加或合并;type:String/类型,weight:权重}
	//					type:none无新数据|add可添加|chash有冲突
	static comparisonText(d, s, name, weight) {
		if (!d) {
			return {value: true, type: 'none', d, s, name, weight}
		} else if (!s) {
			return {value: false, type: 'add', d, s, name, weight}
		} else {
			if (d.toLowerCase() === s.toLowerCase()) {
				return {value: true, type: 'eq', d, s, name, weight}
			} else {
				return {value: false, type: 'clash', d, s, name, weight}
			}
		}
	}

	//对比数组，
	//d在s里有不同的元素为false,
	static comparisonArray(d, s, name) {

		var dArr = d.split(',').filter(val => !!val), sArr = s.split(',').filter(val => !!val)
		if (dArr.length === 0) {
			return {value: true, type: 'none', d, s, name, weight: 0}
		} else if (sArr.length == 0) {
			return {value: false, type: 'add', d, s, name, weight: 0}
		} else if (dArr.length > sArr.length) {
			if (sArr.every(v => dArr.some(v2 => v2 === v))) {
				return {value: false, type: 'addto', d, s, name, weight: 1}
			} else {
				return {value: false, type: 'clash', d, s, name, weight: 1}
			}
		} else {
			if (dArr.every(v => sArr.some((v2) => v2 === v))) {
				return {value: true, type: 'eq', d, s, name, weight: 2}
			} else {
				return {value: false, type: 'clash', d, s, name, weight: 1}
			}
		}
	}

	//首字母大写
	capitalize(str) {
		if (typeof str === 'string') {
			return str.toLowerCase().split(/  ?/).map(function (v) {
				return v.charAt(0).toUpperCase() + v.slice(1)
			}).join(' ');
		} else {
			return '';
		}
	}

	//合并初始化
	mergeInit() {

		if (this.data && this.serverData) {

			var datas = JSON.parse(JSON.stringify(this));

			datas.newData = {};

			var serverContact = [];
			datas.serverData.info.forEach((val) => {
				serverContact.push({type: val.type, info: val.info});
			});

			var newContact = [];
			datas.data.contact.forEach((val) => {
				//去除重复联系方式
				if (!datas.serverData.info.some((val2) => {
					return val2.type == val.type && funs.shortUrl(val2.info) == funs.shortUrl(val.info)
				})) {
					newContact.push({
						type: val.type,
						info: val.info,
					});
				}
			});

			if (datas.serverData.imgs && datas.serverData.imgs.length && datas.data &&
				datas.serverData.imgs.some(val => val.md5_code === datas.md5_code)) {
				datas.data.img = '';
			}

			//把去重后的新联系方式给本地数据
			datas.data.contact = newContact;

			var contacts = [...serverContact, ...newContact];

			//分解职位，转成数组
			datas.serverData.title = datas.serverData.title.split(/, ?/);
			datas.data.title = datas.data.title.split(/, ?/);

			//组织新数据
			//新数据默认优先使用服务器数据，如果服务器没有，使用本地数据
			datas.newData = {
				contact_id: datas.serverData.id,
				contact_name: datas.serverData.contact_name,
				first_name: datas.serverData.first_name || datas.data.first_name,
				last_name: datas.serverData.last_name || datas.data.last_name,
				birth_year: datas.serverData.birth_year || datas.data.birth_year || 0,
				birth_month: datas.serverData.birth_month || datas.data.birth_month || 0,
				birth_day: datas.serverData.birth_day || datas.data.birth_day || 0,
				is_show: 0,
				contact_name: datas.serverData.contact_name,
				title: datas.serverData.title,
				city: datas.serverData.city || datas.data.city,
				company: datas.serverData.company || datas.data.company,
				img: datas.data.img,
				contact: contacts,
			}

			return datas
		} else {
			return {}
		}
	}

	//初始化someName 数据
	initSomeName(data) {
		this.someNames = data
	}
};

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory :
		typeof define === 'function' && define.amd ? define(factory) :
			(global.DataItem = factory);
}(this, DataItem))
