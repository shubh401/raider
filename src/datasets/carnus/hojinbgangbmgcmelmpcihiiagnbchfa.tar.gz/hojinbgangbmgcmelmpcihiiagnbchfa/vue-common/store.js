import Vuex from 'vuex';
import Vue from 'vue';
import i18n from './i18n/index'
import injectCustom from '../browser_page/store'
import popupStore from '../popup/store'

import {
	setUserInfo,
	getLanguage,
	setLanguage,
} from "./functions/functions";

Vue.use(Vuex);

const store = new Vuex.Store({
	state: {
		//用户数据，没登录时为空
		userInfo: null,
		language: 'en',
		...popupStore.state,
		...injectCustom.state
	},
	mutations: {
		//设置用户信息
		setUserInfo(state, userInfo) {
			state.userInfo = userInfo;
			setUserInfo(userInfo);
		},
		//即出登录
		logout(state) {
			state.userInfo = null;
			setUserInfo(null);
		},

		//更改语言
		changeLang(state, val) {
			setLanguage(val).then(() => {
				state.language = val;
				i18n.locale = val;
			})
		},
		...popupStore.mutations,
		...injectCustom.mutations
	},
	actions: {}
});


var pushState = history.pushState;
history.pushState = function (state) {
	if (typeof history.onpushstate == "function") {
		history.onpushstate({state: state});
	}
	return pushState.apply(history, arguments);
};

window.onpopstate = function () {
	store.state.viewTransition = 'reslide'
}

history.onpushstate = function (e) {
	store.state.viewTransition = 'slide'
}

getLanguage().then((val) => {
	i18n.locale = val;
	store.state.language = val;
});
export default store;
