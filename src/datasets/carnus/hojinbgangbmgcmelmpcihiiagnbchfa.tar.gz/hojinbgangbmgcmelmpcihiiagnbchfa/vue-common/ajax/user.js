import ajax from './ajax'

export function login (data){
    return ajax.post('login/index',data)
}

export function changeLang (val){
	return ajax.userPost('index/change_lang',{lang:val})
}