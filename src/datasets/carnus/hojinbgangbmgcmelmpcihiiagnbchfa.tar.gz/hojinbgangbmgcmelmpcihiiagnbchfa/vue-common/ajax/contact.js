import ajax from './ajax'
//添加联系人
export function addContact (data){
  return ajax.userPost('contacts/addSingleContact',data)
}

//联系人详细
export function contactDetail (id){
	return ajax.userPost('contacts/getInfo',{id:id})
}

//检查联系人是否已经添加
export function checkContactStatus(data){
  return ajax.userPost('plugin/checkContactStatus',data)
}

export function checkStatus(data){
	return ajax.userPost('plugin/checkStatus',data)
}

//删除联系人图片
export function delImg(id){
	return ajax.userPost('contacts/delImg',{id})
}

//设置默认头像
export function setDefaultImg(data){
	return ajax.userPost('contacts/setDefaultImg',data)
}


//编辑联系人
export function EditContact(data){
	return ajax.userPost('contacts/mergeContact',data);
}

//模糊查找联系人
export function findContact(keyword,is_accurate){
	var obj = {key:keyword}
	if(is_accurate){
		obj.is_accurate = is_accurate;
	}
	return ajax.userPost('index/getContactByKey',obj);
}

//上传图片
export function uploadImg(data){
	return ajax.userPost('index/uploadImg',data)
}

//添加公司
export function addCompany(data){
	return ajax.userPost('company/addCompany',data)
}

//whois搜索
export function searchWhois(name){
	return ajax.userGet('whois/searchWhoiss',{domainName:name})
}

//修改whois状态
export function setWhoisStatus(data){
	return ajax.userPost('Whois/WhoisStatus',data)
}

//人脸对比
export function faceplusMatch(data){
	return ajax.userPost('faceplus/match',data);
}
//人脸对比 设置图片与指定联系人无关
export function faceplusSetNoFile(data){
	return ajax.userPost('faceplus/setNoFile',data);
}

//公司搜索
export function companySearch(keyword){
	return ajax.userPost('Company/getList',{pagesize:10,page:1,keyword:keyword});
}

//更改联系人状态
export function changeStatus(data){
	return ajax.userPost('contacts/changeStatus',data);
}


//公司提示
export function companyKey(key){
	return ajax.userGet('prompt/getCompanyByKey',{key});
}

//职位提示
export function positionKey(key){
	return ajax.userGet('prompt/getPositionByKey',{key});
}

//城市提示
export function cityKey(key){
	return ajax.userGet('prompt/getCityCodeByKey',{key});
}


