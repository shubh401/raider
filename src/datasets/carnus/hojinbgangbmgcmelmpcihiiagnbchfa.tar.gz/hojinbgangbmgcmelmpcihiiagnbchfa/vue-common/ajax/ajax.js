import axios from 'axios';
import store from '../store';
import i18n from '../i18n/index'
import {getUserInfo} from "../functions/functions";

var instance = axios.create({
	baseURL: 'https://fieldflint.hydrophis.cn/api',
	timeout: 30000,
	// withCredentials:true,
	// headers: {'X-Custom-Header': 'foobar'}
});


class Ajax {
	get(url, data = {}) {
		return instance.get(url, {params:data})
			.then(this.dispose)
			.catch(this.error)
	}

	userGet(url, data = {}) {

		return getUserInfo().then((userInfo)=>{
			return instance.get(url, {params: {token:userInfo && userInfo.token, ...data}})
				.then(this.dispose)
				.catch(this.error)
		})
	}

	post(url, data = {}) {
		return instance.post(url, data)
			.then(this.dispose)
			.catch(this.error)
	}

	userPost(url, data = {}) {
		return getUserInfo().then((userInfo)=>{
			return instance.post(url, {token:userInfo && userInfo.token, ...data})
				.then(this.dispose)
				.catch(this.error)
		})
	}

	//响应处理
	dispose(res) {
		if (res.status !== 200 || !res.data) {
			return Promise.reject({msg: i18n.t('请求发生错误'), code: res.status})
		}

		var data = res.data;
		if (data.code !== 0) {
			if (data.code == 101 || data.code == 102) {
				store.commit('logout')
			}
			return Promise.reject(data)
		} else {
			return Promise.resolve(data.data);
		}
	}

	//错误处理
	//@param err { Error|string|Object{code(int),msg(string)} } 错误内容
	error(err) {

		if (err instanceof Error) {

			if (err.response && err.response.status === 404) {
				return Promise.reject({msg: i18n.t('接口不存在'), code: 404})
			} else if (err.response && err.response.status === 500) {
				return Promise.reject({msg: i18n.t('服务器500错误'), code: 404})
			}
			if (err.request && err.request.status === 0) {
				// console.log(err.request)
				// Object.keys(err).forEach((val) => {
				//   console.log(val)
				//   console.log(err[val])
				// })
				return Promise.reject({msg: i18n.t('请求超时'), code: 404})
			}

		} else if (typeof err === 'object' && err.code) {
			return Promise.reject(err)

		} else if (typeof err === 'string') {
			return Promise.reject({msg: err, code: 500})
		}

	}
}

export default new Ajax()
