/*
* 搜索whois 混入
*
* */
import {searchWhois} from '../ajax/contact'
import {addServerData} from '../functions/functions'
import DataItem from '../../vue-common/DataItem.class'

export default {
	methods: {
		searchSubmit(value) {

			return new Promise((resolve, reject) => {

				//搜索whois,@parem 关键字
				return searchWhois(value).then((res) => {

					//获取搜索的内容
					var data = res.data.WhoisRecord;

					//联系人容器
					//可能会有多个联系人，用数组保存
					var arr = [];

					// 搜索必须有内容
					// 且code不能为0或为空
					if (data) {
						//有注册人信息
						if (data.registrant) {

							var reg = data.registrant,
								admin = data.administrativeContact,
								tech = data.technicalContact;
							//处理拿到的注册人信息
							var re = this.disposalData(reg, 'dnsreg');

							//注册人确保有邮箱
							var hasRegEmail = re.contact.some(v => v.type === 'Email');

							if (hasRegEmail) {
								re.plugin_id = reg.email;
							} else if (!hasRegEmail && data.contactEmail) {

								// 如果没有邮箱,但有联系人邮箱，使用联系人邮箱
								re.contact.push({type: 'Email', info: data.contactEmail})
								re.plugin_id = data.contactEmail;
							}

							arr.push(re);

							// 管理员存在，且管理员与注册人不是同一人
							if (admin && admin.name != reg.name) {

								var ad = this.disposalData(admin, 'dnsadm');
								if (admin.email) {
									ad.plugin_id = admin.email;
								}

								this.contactUnique(arr,ad)

								if(ad.contact.length){
									arr.push(ad)
								}

							}

							// 技术联络人存在，且技术联络人与注册人、管理员不是同一人
							if (tech && tech.name != reg.name && tech.name != admin.name) {
								console.log('进入tech')
								var te = this.disposalData(tech, 'dnstech');

								if (tech.email) {
									te.plugin_id = tech.email;
								}
								this.contactUnique(arr,te);
								if(te.contact.length){
									arr.push(te)
								}

							}

						} else if (data.registryData && data.registryData.registrant) {
							console.log('data.registryData.registrant', data.registryData.registrant);
							//data.registrant数据没数据，但data.registryData.registrant数据
							var a = this.disposalData(data.registryData.registrant, 'dnsreg')

							if (data.registryData.registrant.email) {
								a.plugin_id = data.registryData.registrant.email;
							} else if (data.contactEmail) {
								a.contact.push({type: 'Email', info: data.contactEmail})
								a.plugin_id = data.contactEmail;
							}
							arr.push(a);
						}
					}

					var dataList = arr.map((val) => {
						var dataItem = new DataItem(val);
						dataItem.whoisData({
							whois_id: res.id, //whois唯一id
							whois_status: res.status, //状态 1正常数据，0垃圾数据
							unfold: res.status == 1, //内容是否展开显示
							domain: res.domain, //状态 1正常数据，2垃圾数据
						})
						return dataItem;
					});


					return addServerData(dataList);
				}).then((data) => {
					resolve(data)
				}).catch(reject)
			})
		},
		//删除联系人中重复的联系方式
		contactUnique(arr,info){

			arr.forEach((existInfo)=>{
				existInfo.contact.some((val)=>{

					if(info.contact.length===0){
						return true
					}

					info.contact.some((val1,index)=>{

						if(val.info===val1.info ){

							info.contact.splice(index,1);
							return true
						}
					})
				})
			})
		},

		disposalData(data, title) {

			var c = {
				contact_name: data.name || title,
				city: data.city || '',
				title: title ,
				company: data.organization || '',
				img: '',
				country: data.countryCode || '',
				state: data.state || '',
				address: data.street1 || '',
				detailed_address: '',
				contact: []
			};

			//创建地址容器，以数组方式保存，
			//因为英文地址，是从详细到国家排序的，所以数组也是这个顺序
			var address = [];
			if (data.street1) address.push(data.street1)
			if (data.city) address.push(data.city)
			if (data.state) address.push(data.state)
			if (data.postalCode) address.push(data.postalCode)
			if (data.country) address.push(data.country)

			//拼接联系人地址
			var add = this.stitchingAddress(address);

			c.detailed_address = add;

			data.email && c.contact.push({type: 'Email', info: data.email})
			data.telephone && c.contact.push({type: 'Phone', info: data.telephone})
			return c;
		},

		//拼接联系地址
		stitchingAddress(arr) {
			var address = ''
			arr.forEach((val, index) => {
				address += val;
				if (index !== arr.length - 1) {
					address += ', '
				}
			});
			var address = funs.arrayUnique(address.split(/, ?/)).join(', ')
			return address;
		}
	}
}