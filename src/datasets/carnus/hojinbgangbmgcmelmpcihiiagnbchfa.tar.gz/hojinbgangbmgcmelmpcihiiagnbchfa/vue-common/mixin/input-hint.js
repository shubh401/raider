function boldKey(str, key) {
	if (typeof str === 'string' && typeof key === 'string') {
		return str.replace(new RegExp('(' + key + ')', 'ig'), '<b style="color:rgb(77,200,107)">$1</b>')
	}
	else {
		return str;
	}

}

function timeoutPerform(time) {
	var timeoutId = 0;
	return function (cb) {
		return new Promise((resolve, reject) => {
			clearTimeout(timeoutId);
			if (typeof cb == 'function') {
				timeoutId = setTimeout(() => {
					var cbs = cb();
					//执行cb后可能有promise的返回值
					if (cbs instanceof Promise) {
						cbs.then(() => {
							resolve();
						}).catch(reject)
					} else {
						resolve();
					}

				}, time)
			}
		})

	}
}

export default {
	data() {
		return {
			hint: false,
			loading: false,
			content: '',
			timeoutPerformed: null,
			timeoutPromise: Promise.resolve(),
		};
	},
	created() {
		this.timeoutPerformed = timeoutPerform(400);
		this.content = this.value
	},
	props: {
		value: {
			type: String,
			default: ''
		},
		label: {
			type: String,
			default: '',
		},
		filterIds: {
			type: Array,
			default() {
				return []
			},
		},
		required: Boolean,
		focus: Boolean,
	},
	mounted() {
		this.hint = true;
		this.timeoutPromise = this.timeoutPerformed(() => {
			return this.getAjax(this.content);
		});

	},
	watch: {
		content(newValue, oldValue) {
			this.hint = true;
			this.timeoutPromise = this.timeoutPerformed(() => {
				return this.getAjax(newValue)
			})
		},
	},
	methods: {
		boldKey,
		input(val) {
			this.content = val;
			this.$emit('input', val)
		},
		enter(val) {
			if (val === -2) {
				this.$emit('select', {
					isAdd: true,
					value: this.content
				});
			}
		},
		select(index) {
			this.$emit('select', this.hint[index])
			var val2 = this.hint[index].value
			setTimeout(() => {
				if (this.$refs['iciinput']) {
					this.$refs['iciinput'].updateValue(val2);
					this.$emit('input', val2)
				}
			}, 0)

		}
	},
}
