import test from './test_functions'
import {checkContactStatus} from "../ajax/contact";
import DataItem from '../DataItem.class'
/*
* 是否是在谷歌扩展上运行
* */

var isChromeExtension = chrome.tabs ? true : false
var isChromeStorage = chrome.storage ? true : false
var vueApp = {}
if (isChromeExtension) {
	vueApp = chrome.extension.getBackgroundPage().vueApp;
}

/*
* 从content_script中获取数据列表
* */
export function getContentScriptData() {
	if (isChromeExtension) {
		return new Promise((resolve, reject) => {
			//当前活动标签
			var opt = {
				active: true,
				currentWindow: true
			};
			chrome.tabs.query(opt, function (tabs) {

				var tab = tabs[0];
				//与content_script进行通讯，并等待返回数据
				//建立长连接
				var port = chrome.tabs.connect(tab.id, {name: 'getList'});

				//发送数据
				port.postMessage();

				//监听回复
				port.onMessage.addListener(function (listData) {
					console.log('popup收到监听回复')
					if (typeof listData === 'string') {
						switch (listData) {
							case 'linkedin not log in':
								reject({code: 1101, msg: "linkedin not log in"});
								break;
							default:
								reject({code: 1000, msg: listData})
						}
					} else {
						resolve(listData)
					}

				});

				//监听断开
				port.onDisconnect.addListener(function () {
					console.log('popup收到监听错误回复');
					reject()
				});

			});
		})
	} else {
		return test.getContentScriptData();
	}
}

export function getBackgroundListData() {
	if (isChromeExtension) {
		return new Promise((resolve, reject) => {
			funs.getCurrentTab((e) => {
				chrome.tabs.sendMessage(e.id, {type: 'get-page-id'}, function (urlid) {
					if (vueApp.dataCenter[urlid]) {
						console.log('刚好有数据', vueApp.dataCenter[urlid])
						resolve({data: vueApp.dataCenter[urlid], urlId: urlid})
					}
					if (urlid) {
						var unwatch = vueApp.$watch('dataCenter', function () {
							console.log('经过watch的数据', vueApp.dataCenter[urlid])
							if (vueApp.dataCenter[urlid]) {
								resolve({data: vueApp.dataCenter[urlid], urlId: urlid});
								unwatch();
							}
						});
					} else {
						//没id拿当前页面地址作为ID
						funs.getCurrentTab((e) => {
							var domain = funs.getDomain(e.url);
							vueApp.onlyWhoisDataList(domain).then((data) => {
								resolve({data: data, urlId: domain})
							})
						})

					}
				});
			});
		})

	} else {
		var dataList = [{"md5_code":"f88e3a1e8926d1aef3bacadaf39ee5ee","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C5603AQH2fazFlZVIDQ/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=8gmowKI5idVcBiYpMPgz8ThUv1bOgmt_gB3HSJotAKA","contact_name":"Dell Valliere ©","title":"CEO","company":"Dellvalliere.com","first_name":"Dell","last_name":"Valliere ©","country":"kh","city":"Cambodia","plugin_id":"linkedin-dell-valliere-©-baa129103","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/dell-valliere-©-baa129103/"}],"status":1},"unique_id":"2cabdff1ccd70ef0283500c1358534ae","contact_id":0},{"md5_code":"","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"","contact_name":"Chan Chamroeun","title":"Web Developer","company":"Gigb Business Investment - Cambodia Co., Ltd.","first_name":"Chan","last_name":"Chamroeun","country":"kh","city":"Phnom Penh, Cambodia","plugin_id":"linkedin-chan-chamroeun-b5080840","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/chan-chamroeun-b5080840/"}],"status":1},"unique_id":"a95231058383a2d2fd18e712605cc20b","contact_id":0},{"md5_code":"3cf496c8f6288c9c161137cf1f0f0d18","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C4D03AQFTBbRP0tpu1A/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=BDNQXHbCXuFEyPH7rqxzOSgDJ1Ae4XU4TB92nbckQVU","contact_name":"Seak Leang Bun","title":"iOS Software Engineer","company":"Dmi (digital Management, Inc.)","first_name":"Seak Leang","last_name":"Bun","country":"kh","city":"Phnom Penh, Cambodia","plugin_id":"linkedin-seakleangbun","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/seakleangbun/"}],"status":1},"unique_id":"25e04d0bf70996f500be2b11ad624d73","contact_id":0},{"md5_code":"efe00953cbd2fe9c5282e115602fa7b7","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C5103AQEtkM_6KDOUOg/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=mgY6Bq-PVSkbtXlbZE_hE7zEmE7cXRB-NeRZX5ZIRuY","contact_name":"Buntha Kha","title":"IT Expert","company":"Palladium: Make It Possible","first_name":"Buntha","last_name":"Kha","country":"kh","city":"Cambodia","plugin_id":"linkedin-buntha","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/buntha/"},{"type":"Twitter","info":"https://twitter.com/bunthakha/"}],"birth_month":5,"birth_day":30,"status":1},"unique_id":"3861a3ee0e64952545e9d6be645c36cc","contact_id":0},{"md5_code":"7e4eb7cc1539d25b8cbeeb19d5e56f10","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C4D03AQGUCLvyPPVgTg/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=m3hIZ_uzJJ7fRfyFfaO5yLuWrX382j8skW2rpbcGRq8","contact_name":"Sengchheang Chhun","title":"Development Manager","company":"Web Essentials","first_name":"Sengchheang","last_name":"Chhun","country":"kh","city":"Phnom Penh","plugin_id":"linkedin-sengchheang","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/sengchheang/"}],"status":1},"unique_id":"88f4c84d6df4fc71031949831ce27a7f","contact_id":0},{"md5_code":"c4d54ca8737cca56e1b50694f05f84f6","updated":false,"whois":false,"serverData":"","someNames":[{"id":5637,"contact_name":"Phan Chanraksmey","first_name":"","last_name":"","contact_abbr":"PC","company_id":3195,"quit":0,"title":"Member of the Board,","state":"","city":"Phnom Penh, Cambodia","address":"","zip_code":0,"ici_cm":4,"remark":"Mr. PHAN CHANRAKSMEY used to work as Financial Assistant of CFIS Co., Ltd in 2008 in Cambodia. Mr. Raksmey, obtained Bachelor of Financial and Banking. He participated in training courses such Budget Planning, Internal Control and Audit, Risk Management, and Cambodia Tax System. He obtained his Master’s degree in Financial Management at Royal University of Laws and Economic Science in 2013","threshold":0,"status":1,"last_contact_time":1527236161,"create_time":1527236125,"contact_status":1,"birthday":0,"gender":1,"sort":4,"alias":"","from":0,"birth_year":0,"birth_month":0,"birth_day":0,"number":4,"position_id":"830","position_level":0,"company":"Samrithisak Microfinance Limited","header":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180525/201805251615438817.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568665&Signature=CIEHl9JwsgmgsACSlxzvP0cg26Y%3D","imgs":[{"id":5454,"contact_id":5637,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":4547,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180525/201805251615438817.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568665&Signature=CIEHl9JwsgmgsACSlxzvP0cg26Y%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180525/thumb_201805251615438817.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568665&Signature=zCbYtc3rOLU2UOjLWShOG1rJ29g%3D","md5_code":"30fa3a63883b724cf194c7c3c9dfd1cd"}],"info":[]}],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C5103AQHGfydaWa_vUg/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=cTg6zicBfQqsabR2L7A8nl1kGB4HOGAWGBYa48-YeIU","contact_name":"Phan Chanraksmey","title":"iOS Developer","company":"Cammob Co., Ltd","first_name":"Phan","last_name":"Chanraksmey","country":"kh","city":"Phnom Penh, Cambodia","plugin_id":"linkedin-phan-chanraksmey-17744356","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/phan-chanraksmey-17744356/"}],"birth_month":2,"birth_day":4,"status":1},"unique_id":"e79b0379b6a23f2fe2fe59d5c439c82f","contact_id":0},{"md5_code":"039b6f27358e714917340c8e46405198","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C4D03AQH3vZ5_jUz-iA/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=_rvCkqqCrV3L8Dh2WRFIH-XuVCN6KI2VKIaZpCXb4Pg","contact_name":"Yarin Nim","title":"Senior Web Developer","company":"Krawma Co., Ltd.","first_name":"Yarin","last_name":"Nim","country":"kh","city":"Phnom Penh","plugin_id":"linkedin-yarin-nim-01491215","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/yarin-nim-01491215/"},{"type":"Twitter","info":"https://twitter.com/yarin_nim/"}],"status":1},"unique_id":"5299a5c66af385bad7bb7a0f671f4dfe","contact_id":0},{"md5_code":"0392eb5c6c971797e8bc994973abace7","updated":false,"whois":false,"serverData":"","someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C4D03AQEMo3b1qc4CGQ/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=yJfmjwwSP_1B_gNPN7bnR1bcTfxULiXwsNDHbMDgB8s","contact_name":"Malin Chhan","title":"iOS Developer","company":"Gaeasys","first_name":"Malin","last_name":"Chhan","country":"kh","city":"Phnom Penh","plugin_id":"linkedin-malinchhan","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/malinchhan/"}],"birth_month":2,"birth_day":8,"status":1},"unique_id":"63563682444186c1f75456c4cba15c2a","contact_id":0},{"md5_code":"d226681f7bb8db8507d63c14939036d8","updated":false,"whois":false,"serverData":{"id":1585,"contact_name":"Sovichea Sou","first_name":"Sovichea","last_name":"Sou","contact_abbr":"SS","company_id":726,"quit":0,"title":"CEO","state":"","city":"Phnom Penh, Cambodia","address":"","zip_code":0,"ici_cm":4,"remark":"","threshold":0,"status":1,"last_contact_time":1526610524,"create_time":1523153605,"contact_status":1,"birthday":0,"gender":1,"sort":1,"alias":"","from":1,"birth_year":0,"birth_month":0,"birth_day":0,"number":1,"position_id":"358","position_level":0,"company":"Servier","imgs":[{"id":1400,"contact_id":1585,"is_face":1,"is_show":1,"type":0,"info":"","comment_id":0,"file_id":535,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180408/201804081013258658.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=0q9zOPsadYCgj1OytvlFoYGdDRI%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180408/thumb_201804081013258658.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=si8jsycLwAHO6eOdHt6rO34Nclg%3D","md5_code":"d226681f7bb8db8507d63c14939036d8"},{"id":6935,"contact_id":1585,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":6012,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180606/201806061026472414.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=BOhj%2BXipYjLW3uvkjmP0ZqckVv0%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180606/thumb_201806061026472414.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=bCfvUFcR4ffnObnB075gaO36DfE%3D","md5_code":"9a8d840f4820fd23d7565c97562e7394"},{"id":3861,"contact_id":1585,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":3086,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180518/201805181023029466.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=1XZX3rHllO8yVND6ordADDHCZ%2F0%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180518/thumb_201805181023029466.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=LmNLJUE0Vh2fJ5uS72ZcWBO2DZU%3D","md5_code":"9af3291b8ca8a8a9e286ade0c9c0b802"},{"id":1830,"contact_id":1585,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":1078,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180420/201804200912389597.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=oVdJRymv%2BnOTeuP4OhEwf8edR44%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180420/thumb_201804200912389597.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=zC6C7ahkmrwMZM7tMS61E4p41TA%3D","md5_code":"83a65f6a3ab8d3e151d70622ab218560"},{"id":1828,"contact_id":1585,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":1076,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180420/201804200904032867.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=61ZR8Z1RYOpaVxcGdWFCj0%2FSOGY%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180420/thumb_201804200904032867.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=CyvT5Hdzq3ZqKnx8T5SXURRqBm4%3D","md5_code":"391677867d3f3603ca9ec4c5691c18e6"},{"id":1525,"contact_id":1585,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":444,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180402/201804021826109626.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=nb1tziUJaVia7P1dbs5RKDWHuOA%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180402/thumb_201804021826109626.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568654&Signature=5Px1h7%2FFsjgUyfwCTon2tl3SoYo%3D","md5_code":"188c087fe09ee35366ab770919158cc3"}],"info":[{"id":18661,"contact_id":1585,"info":"https://twitter.com/titbbiz/","type":"Twitter","form":0,"iconfont":"","plugin_id":"twitter-titbbiz","update_time":1529565054,"create_time":0},{"id":18667,"contact_id":1585,"info":"sou.sovichea","type":"Skype","form":0,"iconfont":"","plugin_id":"Skype-sou.sovichea","update_time":1529565054,"create_time":0},{"id":18662,"contact_id":1585,"info":"85523306089","type":"Phone","form":0,"iconfont":"","plugin_id":"85523306089","update_time":1529565054,"create_time":0},{"id":18666,"contact_id":1585,"info":"023306089","type":"Phone","form":0,"iconfont":"","plugin_id":"023306089","update_time":1529565054,"create_time":0},{"id":18663,"contact_id":1585,"info":"https://www.linkedin.com/in/sovicheasou/","type":"Linkedin","form":0,"iconfont":"","plugin_id":"linkedin-sovicheasou","update_time":1529565054,"create_time":0},{"id":18664,"contact_id":1585,"info":"https://www.facebook.com/DeniseDuffieldThomas","type":"Facebook","form":0,"iconfont":"","plugin_id":"facebook-deniseduffieldthomas","update_time":1529565054,"create_time":0},{"id":18665,"contact_id":1585,"info":"sou.sovichea@gmail.com","type":"Email","form":0,"iconfont":"","plugin_id":"sou.sovichea@gmail.com","update_time":1529565054,"create_time":0},{"id":18668,"contact_id":1585,"info":"chhit@chhit.com","type":"Email","form":0,"iconfont":"","plugin_id":"chhit@chhit.com","update_time":1529565054,"create_time":0}]},"someNames":[],"directUpdate":false,"requestStatus":4,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C4D03AQGRnbB91YUZeQ/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=IiME1du2LUuP6sNvArlXNuRmtBWD4cWDrlMUsSzm5ls","contact_name":"Sovichea Sou","title":"CEO","company":"Trusted It Business","first_name":"Sovichea","last_name":"Sou","country":"kh","city":"Cambodia","plugin_id":"linkedin-sovicheasou","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/sovicheasou/"},{"type":"Twitter","info":"https://twitter.com/titbbiz/"},{"type":"Phone","info":"023306089"},{"type":"Skype","info":"sou.sovichea"},{"type":"Email","info":"chhit@chhit.com"}],"birth_year":1988,"birth_month":3,"birth_day":21,"status":1},"unique_id":"25b4ef0a063f5c670d33f12bc3b700bf","contact_id":1585},{"md5_code":"14a02628a708c9ebde7fc0c6117ecbbe","updated":false,"whois":false,"serverData":{"id":8611,"contact_name":"Vann Mardy","first_name":"Vann","last_name":"Mardy","contact_abbr":"VM","company_id":2653,"quit":0,"title":"General Manager","state":"","city":"Cambodia","address":"","zip_code":0,"ici_cm":1,"remark":"","threshold":0,"status":3,"last_contact_time":1529500037,"create_time":1529500037,"contact_status":1,"birthday":0,"gender":1,"sort":1,"alias":"","from":0,"birth_year":0,"birth_month":0,"birth_day":0,"number":1,"position_id":"903","position_level":0,"company":"Udaya Technology Co., Ltd.","imgs":[{"id":8595,"contact_id":8611,"is_face":1,"is_show":1,"type":0,"info":"","comment_id":0,"file_id":7722,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180620/201806202107068239.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568664&Signature=%2BNrMveSPMDG9PPa9vqYviLLmOdA%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180620/thumb_201806202107068239.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568664&Signature=Pf5WG%2Fm9uYrpJ3EdKf11mjFyuR0%3D","md5_code":"9715f396cde8f330db323638998650a0"},{"id":8818,"contact_id":8611,"is_face":1,"is_show":0,"type":0,"info":"","comment_id":0,"file_id":7954,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180621/201806211510545008.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568664&Signature=Bo2TthHGSenizD0%2BEYAx%2Fvspljk%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180621/thumb_201806211510545008.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568664&Signature=ltM%2F1EVivMuM41FRtNDHTakmWiM%3D","md5_code":"14a02628a708c9ebde7fc0c6117ecbbe"}],"info":[{"id":18142,"contact_id":8611,"info":"https://www.linkedin.com/in/vann-mardy-6443b99a/","type":"Linkedin","form":0,"iconfont":"","plugin_id":"linkedin-vann-mardy-6443b99a","update_time":1529500037,"create_time":0}]},"someNames":[],"directUpdate":false,"requestStatus":4,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C5103AQHR4PxprRMqtg/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=eYoPmGtnFxaF7i4VjL2txr8AVcxzvMWouTqINNzt2yg","contact_name":"Vann Mardy","title":"General Manager","company":"Udaya Technology Co., Ltd.","first_name":"Vann","last_name":"Mardy","country":"kh","city":"Cambodia","plugin_id":"linkedin-vann-mardy-6443b99a","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/vann-mardy-6443b99a/"}],"status":1},"unique_id":"bdb4122466e625351855de1383f005c6","contact_id":8611},{"md5_code":"ce1e7ecf2bd19681af229d091f89ac0c","updated":false,"whois":false,"serverData":{"id":2776,"contact_name":"Kong Mesa","first_name":"Kong","last_name":"Mesa","contact_abbr":"KM","company_id":1326,"quit":0,"title":"CEO(Chief Executive Officer),","state":"","city":"Phnom Penh, Cambodia","address":"","zip_code":0,"ici_cm":3,"remark":"","threshold":0,"status":1,"last_contact_time":0,"create_time":1525836418,"contact_status":1,"birthday":0,"gender":1,"sort":2,"alias":"","from":0,"birth_year":0,"birth_month":0,"birth_day":0,"number":2,"position_id":"","position_level":0,"company":"Atech Group Co., Ltd","imgs":[{"id":2800,"contact_id":2776,"is_face":1,"is_show":1,"type":0,"info":"","comment_id":0,"file_id":1952,"img":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180509/201805091127106351.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568653&Signature=yk8KKb3%2Fm16zy7hhod4Kbmaqyg4%3D","thumb_pic":"http://ici.oss-cn-hongkong.aliyuncs.com/uploads/contacts/20180509/thumb_201805091127106351.png?OSSAccessKeyId=LTAIOtrvqkIYauAq&Expires=1529568653&Signature=b9NbcSpJuduQtqtYgR%2BfebCQ6jg%3D","md5_code":"ce1e7ecf2bd19681af229d091f89ac0c"}],"info":[{"id":5751,"contact_id":2776,"info":"https://www.linkedin.com/in/kong-mesa-46459154/","type":"Linkedin","form":0,"iconfont":"","plugin_id":"linkedin-kong-mesa-46459154","update_time":1525836418,"create_time":0}],"plugin_id":"linkedin-kong-mesa-46459154"},"someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"img":"https://media.licdn.com/dms/image/C5103AQFPCD8068OM2g/profile-displayphoto-shrink_800_800/0?e=1534982400&v=beta&t=-Py1VQB4rcorutJKNeGPCd0C_7Qo3uoS5tlpxRqfZhw","contact_name":"Kong Mesa","title":"Chief Executive Officer","company":"Atech Group Co., Ltd.","first_name":"Kong","last_name":"Mesa","country":"kh","city":"VTrust Office Center, Parkway Square, 3/F, 113, Mao Tsetoung Blvd., PP, Cambodia","plugin_id":"linkedin-kong-mesa-46459154","contact":[{"type":"Linkedin","info":"https://www.linkedin.com/in/kong-mesa-46459154/"}],"status":1},"unique_id":"c802deaa9d353c99b0de33f8c7042166","contact_id":2776},{"md5_code":"","updated":false,"whois":{"whois_id":75,"whois_status":0,"unfold":false,"domain":"www.linkedin.com"},"serverData":{"id":5652,"contact_name":"Host Master","first_name":"","last_name":"Host Master","contact_abbr":"HM","company_id":2250,"quit":0,"title":"registrant,dnsreg","state":"CA","city":"Sunnyvale","address":"1000 W. Maude Ave,","zip_code":0,"ici_cm":4,"remark":"","threshold":0,"status":0,"last_contact_time":1527238706,"create_time":1527238706,"contact_status":1,"birthday":0,"gender":1,"sort":1,"alias":"","from":0,"birth_year":0,"birth_month":0,"birth_day":0,"number":1,"position_id":"403","position_level":0,"company":"Linkedin Corporation","imgs":[],"info":[{"id":14969,"contact_id":5652,"info":"16506873600","type":"Phone","form":0,"iconfont":"","plugin_id":"16506873600","update_time":1528275427,"create_time":0},{"id":14970,"contact_id":5652,"info":"hostmaster@linkedin.com","type":"Email","form":0,"iconfont":"","plugin_id":"hostmaster@linkedin.com","update_time":1528275427,"create_time":0}],"plugin_id":"hostmaster@linkedin.com"},"someNames":[],"directUpdate":false,"requestStatus":0,"msg":"","data":{"contact_name":"Host Master","city":"Sunnyvale","title":"dnsreg","company":"Linkedin Corporation","img":"","country":"US","state":"CA","address":"1000 W. Maude Ave,","detailed_address":"1000 W. Maude Ave, , Sunnyvale, CA, 94085, UNITED STATES","contact":[{"type":"Email","info":"hostmaster@linkedin.com"},{"type":"Phone","info":"16506873600"}],"plugin_id":"hostmaster@linkedin.com","status":1,"first_name":"","last_name":""},"contact_id":5652}]

		var list = dataList.map((item) => {
			return new DataItem().init(item)
		})
		return Promise.resolve({data: list, urlId: '1213123'})
	}
}

export function setWhoisData(dataList) {
	vueApp.setWhoisDataList(dataList)
}

export function indexToAddContacts(indexs, urlId) {
	if (isChromeExtension) {
		vueApp.indexToAddContact(indexs, urlId);
	}
}

export function getUserInfo() {
	return isChromeStorage ? funs.getUserInfo() : test.getUserInfo();
}

export function setUserInfo(userInfo) {
	return isChromeStorage ? funs.setUserInfo(userInfo) : test.setUserInfo(userInfo);
}

export function getPasteStatus() {
	return isChromeStorage ? funs.getStatus('pasteStatus') : Promise.resolve(true);
}

export function setPasteStatus(bool) {
	return isChromeStorage ? funs.setStatus('pasteStatus',bool) : Promise.resolve(false);
}

export function getSoundStatus() {
	return isChromeStorage ? funs.getStatus('soundStatus') : Promise.resolve(true);
}

export function setSoundStatus(bool) {
	return isChromeStorage ? funs.setStatus('soundStatus',bool) : Promise.resolve(false);
}

export function getLanguage() {
	return isChromeStorage ? funs.getLanguage() : test.getLanguage();
}

export function setLanguage(val) {
	return isChromeStorage ? funs.setLanguage(val) : test.setLanguage(val);
}

//首字母大字
export function capitalize(str) {
	if (typeof str === 'string') {
		return str.toLowerCase().split(/  ?/).map(function (v) {
			return v.charAt(0).toUpperCase() + v.slice(1)
		}).join(' ');
	} else {
		return str;
	}

};

/*
* 对比数据
* */
export function contactIsUpdate(data, serverData) {

	var isFirstNname = !data.first_name || data.first_name.toLowerCase() === serverData.first_name.toLowerCase();
	var isLastNname = !data.last_name || data.last_name.toLowerCase() === serverData.last_name.toLowerCase();

	serverData.company = serverData.company ? serverData.company : '';
	var bool2 = !data.company || ((data.company.toLowerCase() || 'none') === (serverData.company.toLowerCase() || 'none'));
	serverData.city = serverData.city ? serverData.city : ''
	var bool3 = !data.city || data.city.toLowerCase() === serverData.city.toLowerCase();
	serverData.title = serverData.title ? serverData.title : ''
	var bool4 = !data.title || data.title.toLowerCase() === serverData.title.toLowerCase();
	var bool5, bool6;

	//联系人对比
	if (serverData.info && serverData.info.length && data.contact && data.contact.length) {

		bool5 = data.contact.every(function (val) {
			return serverData.info.some(function (v) {
				return v.type.toLowerCase() == val.type.toLowerCase() && funs.pageUniqueId(v.info) == funs.pageUniqueId(val.info)
			});
		});

	} else if (serverData.info && serverData.info.length || data.contact && data.contact.length) {
		bool5 = false
	} else {
		bool5 = true;
	}

	//图片对比
	if (data.md5_code) {
		if (serverData.imgs && serverData.imgs.length) {

			bool6 = serverData.imgs.some((val) => {
				console.log(val.md5_code, data.md5_code)
				return val.md5_code === data.md5_code
			})
		} else {
			bool6 = false;
		}
	} else {
		bool6 = true;
	}

	console.log(data.contact_name, isFirstNname, isLastNname, bool2, bool3, bool4, bool5, bool6)
	if (isFirstNname && isLastNname && bool2 && bool3 && bool4 && bool5 && bool6) {
		return false;
	} else {
		return true;
	}
}

/*
*在dataList 里面添加md5
*
* @params {datalist} url datalist对象
* @return {promise} resolve(datalist for md5);
*
* */
export function dataListAddMd5(listData) {
	var promises = []

	listData.forEach((dataItem) => {
		promises.push(funs.contentScriptImgToBase64Md5(dataItem.data.img))
	});

	return Promise.all(promises).then(function (e) {

		listData.forEach((v, index) => {
			v.md5_code = e[index];
			v.unique_id = funs.itemDataUniqueId(v)
		});

		return Promise.resolve(listData)
	})
}


//为采集的数据添加id
export function addServerData(list) {

	return new Promise((resolve, reject) => {

		//生成plugin_id数组
		//通过plugin_id 可以查询到服务器是否存在该用户
		var pluginIds = list.map(val => val.data.plugin_id);

		if (!pluginIds.length) {
			return resolve(list)
		}

		//发出校验
		checkContactStatus({plugin_id: pluginIds}).then((res) => {

			list.forEach((dataItem, index) => {

				//在数据项目对象添加服务器数据
				dataItem.getServerData(res[index].contact);
			});
			resolve(list);

		}).catch((res) => {
			reject(res);
		})
	})
}
