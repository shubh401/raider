//国际化
import Vue from 'vue';
import VueI18n from 'vue-i18n'
Vue.use(VueI18n);

import zh_cn from './zh_cn'
import en from './en'
// setup locale info for root Vue instance
const i18n = new VueI18n({
	locale: 'en',
	messages: {
		cn: zh_cn,
		en: en
	}
})

export default i18n;
