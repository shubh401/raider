<template>
	<div class="wrap">
		<yd-layout class="fms-list">
			<yd-navbar slot="navbar" height="45px" color="#C01639" fontsize="16px">
				<a href="https://fieldflint.hydrophis.cn/" target="_blank" slot="left">
					<img src="../assets/fms_app_logo-1.png" alt="" height="18">
				</a>
				<div slot="center">
					<router-link to="/whois">
						<ici-icon name="icon-sousuo"></ici-icon>
						Search whois
					</router-link>
				</div>
				<router-link to="/user" slot="right">
					<ici-icon name="icon-yduigerenzhongxin" size="26px" color="#666"></ici-icon>
				</router-link>
			</yd-navbar>
			<yd-cell-group v-if="dataList">
				<template v-for="(item,index) of dataList">
					<list-item :s="status" :data-item="item" :index="index" v-model="checkedIndex" :key="index"/>
				</template>
			</yd-cell-group>

			<!--linkedin 未登录-->
			<div v-if="!linkedinLogin">
				<linkedinlogin></linkedinlogin>
			</div>

			<div v-else-if="!gathering && (!dataList || !dataList.length)">
				<nodata></nodata>
			</div>

			<div slot="tabbar">
				<batchAddContact @changeStatus="changeStatus" :status="status" v-model="checkedIndex" :data="dataList"/>
			</div>
		</yd-layout>
	</div>

</template>

<script>
	import nodata from '../components/nodata';
	import batchAddContact from '../components/batchAddContact';
	import linkedinlogin from '../components/linkedin-login'
	import {getBackgroundListData} from '../../vue-common/functions/functions'
	import fmsSearch from '../components/fms-search'
	import listItem from '../components/list-item.vue'
	import SearchWhois from '../../vue-common/mixin/search_whois.js'
	import {changeStatus} from '../../vue-common/ajax/contact'

	export default {
		name: "list",
		mixins: [SearchWhois],
		data() {
			return {
				//已选择的列表索引
				checkedIndex: [],

				//数据是否正在拉取
				gathering: false,
				linkedinLogin: true,
				search: '',
				status: 1,
			}
		},
		computed: {
			dataList() {
				return this.$store.state.dataList;
			},
		},
		created() {

			if (!this.dataList) {
				this.$icimsg.loading(this.$t('最长20秒等待'), 0, 'center');
				this.gathering = true;

				getBackgroundListData().then((dataList) => {

					this.$store.commit('setUrlId', dataList.urlId);
					this.$store.commit('initListData', dataList.data);

				}).catch((err) => {
					console.log('list err', err);

					if (err && err.code === 1101) {
						this.linkedinLogin = false;
					}

					this.$store.commit('initListData', []);

				}).finally(() => {
					this.$icimsg.close();
					this.gathering = false;
				});
			}
			var contactStatus = localStorage.getItem('contact_status');
			if (contactStatus) {
			 	this.status = ~~contactStatus
			}

		},


		methods: {
			changeStatus() {
				if (this.status === 1) {
					this.status = 3;

					var obj = {};
					var important = localStorage.getItem('contact_important_status');
					if (important) {
						var imp = JSON.parse(important);
						if (imp.timetamp + 3600000 > Date.now()) {
							obj.num = imp.num + 1;
							obj.timetamp = Date.now();
						} else {
							obj = {num: 1, timetamp: Date.now()}
						}
					} else {
						obj = {num: 1, timetamp: Date.now()}
					}


				} else {
					this.status = 1;
				}
			 localStorage.setItem('contact_status', String(this.status))
				this.doServerStatus();
			},
			doServerStatus() {
				if (this.dataList && this.dataList) {
					this.dataList.forEach((item) => {
						if (item.contact_id) {
							if(this.status ===item.serverData.status) return;
							changeStatus({status: this.status, id: item.contact_id}).then(() => {
								console.log(item)
						 		item.serverData.status = this.status;
								this.$dialog.notify({
									mes: this.$t('更改成功'),
									timeout: 1000,
								});
							}).catch((err) => {
								console.log(err)
								this.$dialog.notify({
									mes: err.msg,
									timeout: 1000,
								});
							}).finally(() => {
								this.$dialog.loading.close();
							})
						} else {
							item.data.status = this.status;
						}
					})
				}
				this.changeStatus
			},
			successMerge(index, contact_id) {
				this.dataList[index].contact_id = contact_id;
				this.dataList[index].isUpdate = false;
			},

			changeCheck(data) {
				this.checkedIndex = data;
			},
		},
		components: {
			nodata, batchAddContact, linkedinlogin, fmsSearch, listItem
		}
	}
</script>

<style scoped lang="less">

	.flip-list {
		transition: all 1s;
		opacity: 1;
	}

	.flip-list-move {
		transition: transform 1s;
	}
</style>
