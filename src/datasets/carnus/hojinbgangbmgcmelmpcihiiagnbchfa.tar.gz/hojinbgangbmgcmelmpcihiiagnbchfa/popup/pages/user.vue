<template>
	<yd-layout v-if="userInfo">
		<yd-navbar slot="navbar" :title="$t('我的')" height="45px" color="#C01639" fontsize="16px">
			<div to="#" @click="$router.go(-1)" slot="left">
				<ici-icon name="icon-yduifanhui" size="26px" color="#666"></ici-icon>
			</div>
		</yd-navbar>
		<div class="userinfo">
			<yd-cell-group>
				<yd-cell-item>
					<span slot="left">{{$t('用户名')}}</span>
					<span slot="right">{{userInfo.username}}</span>
				</yd-cell-item>
				<yd-cell-item>
					<span slot="left">code</span>
					<span slot="right">{{userInfo.code}}</span>
				</yd-cell-item>
			</yd-cell-group>

			<yd-cell-group :title="$t('设置')">
				<yd-cell-item arrow type="a" href="#" @click.native.stop.prevent="showSheet = true">
					<span slot="left">{{$t('语言')}}</span>
					<div slot="right">
						<span @click="">{{language=='en'?'English':'中文简体'}} </span>
					</div>

				</yd-cell-item>
				<yd-cell-item>
					<span slot="left">{{$t('图片粘贴')}}</span>
					<div slot="right">
						<yd-switch v-model="openPaste" @click.native="setPasteStatus"></yd-switch>
					</div>
				</yd-cell-item>
				<yd-cell-item>
					<span slot="left">{{$t('完成提示音')}}</span>
					<div slot="right">
						<yd-switch v-model="sound" @click.native="setSoundStatus"></yd-switch>
					</div>
				</yd-cell-item>
			</yd-cell-group>
		</div>
		<div class="btn">
			<yd-button type="danger" size="large" @click.native="logout">{{$t('退出登录')}}</yd-button>
		</div>
		<yd-actionsheet :items="languageList" v-model="showSheet" cancel="取消"></yd-actionsheet>
	</yd-layout>
</template>

<script>
	import {changeLang} from '../../vue-common/ajax/user'
	import {getPasteStatus, setPasteStatus, getSoundStatus, setSoundStatus} from '../../vue-common/functions/functions'

	export default {
		name: "user",
		data() {
			return {
				showSheet: false,
				openPaste: true,
				sound: true,
				languageList:
					[
						{
							label: 'English',
							callback: () => {
								this.changeLanguage('en')
							},

						},
						{
							label: '中文简体',
							callback: () => {
								this.changeLanguage('cn')
							}
						},
					]
			}
		},
		created() {
			getPasteStatus().then((bool) => {
				console.log('获取状态成功 PasteStatus', bool)
				this.openPaste = bool;
			})
		  getSoundStatus().then((bool) => {
			  console.log('获取状态成功 sound', bool)
			  this.sound = bool;
		  })
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo
			},
			language() {
				return this.$store.state.language;
			}
		},
		methods: {
			setPasteStatus() {
				setPasteStatus(!this.openPaste).then((bool) => {
					console.log('修改状态成功 PasteStatus', bool);
					this.openPaste = bool;
					if (chrome.tabs) {
						chrome.tabs.query({}, (tabs) => {
							tabs.forEach((tab) => {
								chrome.tabs.sendMessage(tab.id, {type: 'set-paste-status', status: bool})
							})
						});
					}

				})
			},
			setSoundStatus() {
				setSoundStatus(!this.sound).then((bool) => {
					console.log('修改状态成功 sound', bool);
					this.sound = bool;
					if (chrome.tabs) {
						chrome.tabs.query({}, (tabs) => {
							tabs.forEach((tab) => {
								chrome.tabs.sendMessage(tab.id, {type: 'set-sound-status', status: bool})
							})
						});
					}

				})
			},
			logout() {
				this.$store.commit('logout')
			},
			changeLanguage(val) {
				if (val !== this.language) {
					this.$store.commit('changeLang', val);
					changeLang(val).then(() => {
						this.$store.commit('changeLang', val);
					}).catch((err) => {
						this.$dialog.alert({mes: err.msg})
					})
				}

			}
		}
	}
</script>

<style scoped>
	.userinfo {
		padding-top: 50px;
	}

	.btn {
		padding: 15px;
	}
</style>
