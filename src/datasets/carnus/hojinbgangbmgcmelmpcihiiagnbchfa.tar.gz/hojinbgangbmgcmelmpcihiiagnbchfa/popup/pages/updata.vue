<template>
	<yd-layout class="bg-fff">
		<yd-navbar slot="navbar" :title="$t('更新')+' '+$t('联系人')" height="45px" fontsize="16px">
			<div slot="left" @click="$router.go(-1)">
				<yd-navbar-back-icon></yd-navbar-back-icon>
			</div>
			<a class="pointer" slot="right" @click="init">
				{{$t('重置')}}
			</a>
		</yd-navbar>
		<edit-contact ref="editcontact" v-if="dataList && index !== undefined"
						  :active-data="dataList[index]"
						  :server-data="dataList[index].serverData" @success="successMerge"></edit-contact>
	</yd-layout>
</template>

<script>
	import editContact from '../components/editContact';

	export default {
		name: "updata",
		data() {
			return {
				index: undefined,
			};
		},
		computed: {
			dataList() {
				return this.$store.state.dataList;
			}
		},

		watch: {
			'$route'(to, from) {
				// 对路由变化作出响应...
				this.index = to.params.index;
			}
		},

		mounted() {
			this.index = this.$route.params.index;

		},
		beforeDestroy() {

		},
		methods: {
			init() {
				this.index = undefined;
				setTimeout(() => {
					this.index = this.$route.params.index;
				}, 0)

			},
			successMerge(contact_id) {
				console.log('成功')
				//更新数据
				this.$store.commit('contactUpdated', {index: this.index, contact_id: contact_id})
				this.$router.go(-1)
			},
		},
		components: {"edit-contact": editContact}
	}
</script>

<style scoped>

</style>