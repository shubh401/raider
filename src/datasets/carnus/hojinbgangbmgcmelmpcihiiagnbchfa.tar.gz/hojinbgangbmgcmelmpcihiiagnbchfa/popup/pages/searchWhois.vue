<template>
	<yd-layout class="fms-list">
		<yd-navbar slot="navbar" height="45px" color="#C01639" fontsize="16px">
			<div slot="left" @click="$router.go(-1)">
				<yd-navbar-back-icon></yd-navbar-back-icon>
			</div>
			<div slot="center">
				<fms-search v-model="search" @success="searchSuccess"></fms-search>
			</div>
			<a href="javascript:;" slot="right" @click="allTabs">
				<ici-icon name="icon-quanbu"></ici-icon>
				AllTabs
			</a>
		</yd-navbar>
		<yd-cell-group v-if="whoisData && whoisData.length">
			<template v-for="(item,index) of whoisData">
				<list-item :show="show" :data-item="item" :index="index" v-model="checkedIndex" v-show="isShow(item)"
							  :key="item.name">
				</list-item>
			</template>
		</yd-cell-group>

		<div v-if="!gathering && whoisData && !whoisData.length">
			<nodata></nodata>
		</div>

		<div slot="tabbar">
			<batchAddContact :show.sync="show" v-model="checkedIndex" :data="whoisData" haswhois></batchAddContact>
		</div>
	</yd-layout>
</template>

<script>
	import nodata from '../components/nodata';
	import fmsSearch from '../components/fms-search'
	import batchAddContact from '../components/batchAddContact';
	import listItem from '../components/list-item.vue'
	import searchWhois from '../../vue-common/mixin/search_whois.js'
	import {setWhoisData} from '../../vue-common/functions/functions.js'

	export default {
		name: "searchWhois",
		mixins: [searchWhois],
		data() {
			return {
				show: 'All',
				whoisData: null,
				checkedIndex: [],
				gathering: false,
				search: '',
			};
		},
		mounted() {
			this.allTabs()
		},
		methods: {
			//是否显示
			isShow(dataItem) {
				var b;
				switch (this.show) {
					case "All":
						b = true;
						break;
					case "New":
						if (!dataItem.contact_id) {
							b = true
						} else {
							b = false;
						}
						break;
					case "Added":
						if (dataItem.serverData && dataItem.contact_id) {
							b = true
						} else {
							b = false;
						}
						break;
				}
				return b;
			},

			allTabs() {

				this.whoisData = [];

				funs.getOpenDomain().then((val) => {
					this.checkedIndex = [];
					if (val.length) {
						this.$dialog.loading.open(this.$t('稍等'));
						this.getWhoIs(val, 0)
					} else {
						this.$dialog.toast({
							mes: 'No data found',
							timeout: 1500,
						})
					}
				});
			},
			getWhoIs(val, index) {

				if (val.length <= index) {
					setWhoisData(this.whoisData);
					this.$dialog.loading.close();
					return;
				}

				this.searchSubmit(val[index]).then((data) => {
					console.log('获取到的whois信息', data)
					this.whoisData.push(...data);
					this.getWhoIs(val, index + 1)
				}).catch(() => {
					this.getWhoIs(val, index + 1)
				})
			},

			searchSuccess(e) {
				if (!e.length) {
					return;
				}
				this.checkedIndex = [];
				this.whoisData = e;
				setWhoisData(this.whoisData);
			},

		},
		components: {nodata, fmsSearch, batchAddContact, listItem}
	}
</script>

<style scoped>
	.icon-quanbu {
		padding-right: 3px;
	}
</style>