<template>
	<div>

		<div class="login-img">
			<img src="../assets/fms_app_logo-1.png" alt="">
		</div>
		<div class="language">
			<a href="#" :class="{active:language=='en'}" @click="changeLang('en')">English</a>
			<a href="#" :class="{active:language=='cn'}" @click="changeLang('cn')">中文简体</a>
		</div>

		<yd-cell-group>
			<yd-cell-item>
				<yd-input slot="right" required v-model="formData.username" max="20" :placeholder="$t('请输入用户名')"></yd-input>
			</yd-cell-item>
			<yd-cell-item>
				<yd-input slot="right" type="password" v-model="formData.password" :placeholder="$t('请输入密码')"
							 @keyup.native.enter="onSubmit"></yd-input>
			</yd-cell-item>
		</yd-cell-group>
		<div class="buttons">
			<yd-button size="large" type="danger" @click.native="onSubmit">{{$t('登录')}}</yd-button>
		</div>
	</div>
</template>


<script>
	import {login, changeLang} from '../../vue-common/ajax/user'

	export default {
		name: "login",
		data() {
			return {
				formData: {
					username: '',
					password: ''
				}
			}
		},
		created() {
		},
		computed: {
			language() {
				return this.$store.state.language;
			}
		},
		methods: {
			onSubmit() {
				this.$dialog.loading.open(this.$t('正在登录'));
				login(this.formData).then((res) => {


					this.$dialog.loading.close();
					this.$store.commit('setUserInfo', res);

					//php切换语言
					changeLang(this.language).then(() => {
						console.log('php切换语言成功')
					}).catch((err) => {

						this.$dialog.alert({mes: err.msg})
					})

					this.$router.replace({name: 'list'});

				}).catch((err) => {
					this.$dialog.loading.close();
					this.$dialog.notify({mes: err.msg, timeout: 1000});
				})
			},
			changeLang(val) {
				this.$store.commit('changeLang', val)
			}
		}
	}
</script>

<style scoped lang="less">
	.login-img {
		text-align: center;
		padding: 30px;
	}

	.language {
		text-align: center;
		padding: 10px;
		a {
			display: inline-block;
			width: 100px;
			color: #999;
			&:first-child {
				border-right: 1px solid #aaa;
			}
			&.active {
				font-weight: 800;
				color: #C01639;
			}
		}
	}

	.buttons {
		padding: 0 15px;
	}
</style>
