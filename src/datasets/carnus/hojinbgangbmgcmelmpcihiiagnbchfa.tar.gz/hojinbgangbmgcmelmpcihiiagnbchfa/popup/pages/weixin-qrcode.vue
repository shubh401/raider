<template>
	<yd-layout>
		<yd-navbar slot="navbar" title="QR code" height="45px" color="#C01639" fontsize="16px">
			<div to="#" @click="$router.go(-1)" slot="left">
				<ici-icon name="icon-yduifanhui" size="26px" color="#666"></ici-icon>
			</div>
		</yd-navbar>
		<div class="qr-code-wrap ">
			<canvas class="qr-code" v-qrcode="_self"></canvas>
			<div class="qr-code-text">{{$t('请使用微信扫一扫')}}</div>
		</div>
	</yd-layout>
</template>

<script>
	import QRcode from 'qrcode';

	export default {
		name: "weixin-qrcode",
		data() {
			return {
				canvas:null
			};
		},
		watch: {
			'$route'(to, from) {
				 this.createQRcode()
			}
		},
		directives: {
			qrcode: {
				// 指令的定义
			 inserted: function (el, binding) {
			  binding.value.canvas = el;
				}
			}
		},
		mounted() {
			console.log(this.$route.params.url);
		  this.createQRcode()
		},
		beforeDestroy() {
		},
		methods: {
			createQRcode(){
				if(this.$route.params.url){
					QRcode.toCanvas(this.canvas, this.$route.params.url, {width: 250, height: 250})
				}
			}
		},
		components: {}
	}
</script>

<style scoped>
	.qr-code-wrap {
		background: #333;
		height: 95%;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.qr-code {
		border: 1px solid #aaa;
		width: 250px;
		height: 250px;
	}
	.qr-code-text{
		color:#aaa;
		font-size:1.2em;
		margin-top:10px;
	}
</style>