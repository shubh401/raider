import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router);

import list from '../pages/List'
import user from '../pages/user'
import updata from '../pages/updata'
import searchWhois from '../pages/searchWhois.vue'
import weiXinQrCode from '../pages/weixin-qrcode.vue'

export default new Router({
	routes: [
		{
			path: '/',
			name: 'list',
			component: list
		},
		{
			path: '/user',
			name: 'user',
			component: user
		},
		{
			path: '/whois',
			name: 'searchwhois',
			component: searchWhois
		},
		{
			path: '/updata/:index',
			name: 'updata',
			component: updata
		},
		{
			path: '/weiXinqrcode/:url',
			name: 'weiXinqrcode',
			component: weiXinQrCode
		}
	]
})
