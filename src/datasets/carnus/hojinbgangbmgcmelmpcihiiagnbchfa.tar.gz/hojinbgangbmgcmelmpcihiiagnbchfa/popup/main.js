import Vue from 'vue'
import App from './App.vue'
import store from '../vue-common/store'
import router from './router'


//加载YDUI组件
import YDUI from 'vue-ydui'
import 'vue-ydui/dist/ydui.px.css'

//加载ici-ui组件
import IciUi from 'ici-ui'
import 'ici-ui/lib/ici-ui.min.css'
Vue.use(IciUi)

Vue.use(YDUI);

//国际化
import i18n from '../vue-common/i18n/index'


//通用css
import './assets/css/common.css'
import 'element-ui/lib/theme-chalk/index.css';

// iconfont图标组件
import {Tooltip} from 'element-ui'

//注册图标组件

Vue.component(Tooltip.name, Tooltip);


//注册过滤器
Vue.filter('typeToIcon', funs.typeToIcon);
Vue.filter('typeToColor', funs.typeToColor);
Vue.filter('typeToPrefix', funs.typeToPrefix);
Vue.filter('shortUrl', funs.shortUrl);

router.beforeEach((to, from, next) => {
	next();
});

router.afterEach(() => {
	window.scrollTo(0, 0);
});

window.vueApp = new Vue({
	router,
	store,
	i18n,
	el: '#app',
	render: h => h(App)
});
