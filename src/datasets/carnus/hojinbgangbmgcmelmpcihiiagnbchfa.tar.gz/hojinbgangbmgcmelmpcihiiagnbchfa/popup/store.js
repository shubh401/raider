
//插件弹出状态管理
export default {
	state: {
		viewTransition: 'slide',//页面切换动画
		dataList: null, //当前页面数据
		urlId:'',
	},
	mutations: {
		setUrlId(state, urlid){
			state.urlId = urlid;
		},
		//初始化listData数据
		initListData(state, listData) {
			state.dataList = listData;
			console.log(state.dataList)
		},

		//更新listData数据
		contactUpdated(state, datas) {
			state.dataList[datas.index].contact_id = datas.contact_id;
			state.dataList[datas.index].isUpdate = false;
		},

	}
}
