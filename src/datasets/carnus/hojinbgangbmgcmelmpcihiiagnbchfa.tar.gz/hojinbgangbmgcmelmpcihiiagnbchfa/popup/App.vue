<template>
	<div id="app">
		<Login v-if="!userInfo"></Login>
		<transition :name="transitions">
			<keep-alive>
				<router-view class="routerView" v-if="userInfo"></router-view>
			</keep-alive>
		</transition>
	</div>
</template>

<script>
	import Login from './pages/Login'
	import List from './pages/List'
	import {getUserInfo} from "../vue-common/functions/functions";

	export default {
		name: 'app',
		data() {
			return {}
		},
		created() {
			//获取用户信息
			getUserInfo().then((data) => {
				console.log('拿到用户信息', data);
				this.$store.commit('setUserInfo', data);
			});
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo;
			},
			transitions() {
				return this.$store.state.viewTransition;
			}
		},
		components: {
			Login, List
		}
	}
</script>

<style>

	#app {
		position: relative;
		margin: 0 auto;
		width: 400px;
		height: 600px;
		font: 14px/1.5 "Helvetica Neue", Helvetica, Arial, "Microsoft Yahei", "Hiragino Sans GB", "Heiti SC", "WenQuanYi Micro Hei", sans-serif;
		overflow: hidden;
	}

	.routerView {
		position: relative;
		width: 100%;
		height: 100%;

	}

	.slide-enter-active, .slide-leave-active, .reslide-enter-active, .reslide-leave-active {
		transition: margin-left .3s ;
	}

	.slide-enter-to, .slide-leave, .reslide-enter-to, .reslide-leave {
		position: absolute;
		top: 0;
		margin-left: 0%;
	}

	.slide-enter, .reslide-leave-to {
		margin-left: 100%;
	}

	.slide-leave-to, .reslide-enter {
		margin-left: -100%;
	}
</style>
