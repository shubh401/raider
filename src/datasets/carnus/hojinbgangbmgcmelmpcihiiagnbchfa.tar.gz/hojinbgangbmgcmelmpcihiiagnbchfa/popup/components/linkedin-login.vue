<template>
	<div class="nodata">

		<div class="nodata-text">{{$t('请先去登录 Linkedin')}}～～</div>
		<yd-button type="primary" @click.native="loginLinkedin">{{$t('去登录')}}</yd-button>
	</div>
</template>

<script>
	var w = window;
	export default {
		name: "nodata",
		 methods:{
		   loginLinkedin(){
		   	w.open('https://www.linkedin.com/uas/login','_blank')
			}
		 }
	}
</script>

<style scoped>
	.nodata{
		text-align: center;
		padding:100px 50px 0;
	}
	.nodata-text{
		color:#aaa;
		font-size:1.15em;
	}
</style>
