<template>
	<div class="fms-search">
		<input :class="{active:isCentent}" :value="value" @input="$emit('input',$event.target.value)"
				 type="text" @keyup.enter="doSearch">
		<ici-icon class="iconfont" :class="{active:isCentent}" size="18px" name="icon-sousuo"></ici-icon>
		<label :class="{active:isCentent}" @click="doSearch">Whois</label>
	</div>
</template>

<script>
	import searchWhois from '../../vue-common/mixin/search_whois.js'
	/*
	* @v-model String 搜索的内容
	* @event success {function(data)} 搜索成功的事件
	*
	* */
	export default {
		name: "fms-search",
		mixins: [searchWhois],
		data() {
			return {};
		},
		computed: {
			isCentent() {
				if (funs.trim(this.value)) {
					return true;
				} else {
					return false;
				}
			}
		},
		props: {
			value: String,
		},
		methods: {
			doSearch() {
				this.$dialog.loading.open(this.$t('稍等') + '...');
				this.searchSubmit(this.value).then((data) => {
					this.$emit('success', data);
				}).catch((res) => {
					this.$dialog.toast({
						mes: res.msg,
						timeout: 1500,
						icon: 'error',
					})
				}).finally(() => {
					this.$dialog.loading.close()
				})
			}
		},
	}
</script>

<style scoped lang="less">
	.fms-search {
		position: relative;
		input {
			display: block;
			width: 100%;
			box-sizing: border-box;
			padding-left: 30px;
			outline: none;
			border: 1px solid transparent;
			line-height: 26px;
			transition: all .3s;
			&:focus, &.active {
				border: 1px solid #888;
				border-radius: 14px;
				box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.3);
			}

		}

		input:focus + .iconfont, .iconfont.active {
			left: 6px;
			color: #888 !important;
		}

		input:focus ~ label, label.active {
			top: 0px !important;
			display: block;
			height: 28px;
			line-height: 28px;
			right: 0px;
			color: #fff;
			border-radius: 0px 14px 14px 0;
			font-size: .8em;
			padding: 0 5px;
			background: #888;
			pointer-events: auto;
			cursor: pointer;
			user-select: none;
		}

		.iconfont {
			transition: all .2s;
			position: absolute;
			top: 0px;
			left: 63px;
			pointer-events: none;
		}

		label {
			transition: all .2s;
			position: absolute;
			top: 2px;
			font-family: sans-serif;
			font-size: 16px;
			right: 65px;
			pointer-events: none;
			&:active {
				background: #333;
			}
		}
	}
</style>