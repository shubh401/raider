<template>
	<yd-popup class="editcontact-popups-wrap" :masker-opacity=".12" :value="value" @input="input" position="center"
				 width="90%">
		<div class="popups" v-if="value">
			<div class="popup-icon bg-icon" :style="`background-image:url(${imageProcessing(dataItem.data.img)})`"></div>
			<yd-flexbox class="info-list">
				<ici-icon name="icon-renxiang" color="#999" style="align-self:flex-start"></ici-icon>
				<yd-flexbox-item align="top">
					<yd-flexbox class="info-list">
						<yd-flexbox-item>
							<ici-input :label="$t('联系人')" v-model="dataItem.data.contact_name" required></ici-input>
						</yd-flexbox-item>
					</yd-flexbox>
					<yd-flexbox class="info-list">
						<yd-flexbox-item>
							<ici-input :label="$t('名')" v-model="dataItem.data.first_name"></ici-input>
						</yd-flexbox-item>
						<yd-flexbox-item>
							<ici-input :label="$t('姓')" v-model="dataItem.data.last_name"></ici-input>
						</yd-flexbox-item>
					</yd-flexbox>
				</yd-flexbox-item>
			</yd-flexbox>
			<yd-flexbox class="info-list">
				<ici-icon name="icon-gongsixinxi1" color="#999"></ici-icon>
				<yd-flexbox-item>
					<ici-input style="padding-right:10px;" :label="$t('职位')" v-model="dataItem.data.title"></ici-input>
				</yd-flexbox-item>
				<yd-flexbox-item>
					<ici-input :label="$t('公司')" v-model="dataItem.data.company"></ici-input>
				</yd-flexbox-item>
			</yd-flexbox>
			<yd-flexbox class="info-list">
				<ici-icon name="icon-weizhi" color="#999"></ici-icon>
				<yd-flexbox-item>
					<ici-input :label="$t('工作城市')" v-model="dataItem.data.city"></ici-input>
				</yd-flexbox-item>
			</yd-flexbox>
			<yd-flexbox class="info-list" v-for="(item,index) of dataItem.data.contact" :key="index">
				<ici-icon :name="item.type|typeToIcon" :color="item.type|typeToColor"></ici-icon>
				<yd-flexbox-item>
					<ici-input :label="item.type" :prefix="typeToPrefix(item.type)" :filter="typeToFilter(item.type)"
								  v-model="item.info"></ici-input>

				</yd-flexbox-item>
				<router-link style="padding-left:10px;" v-if="item.type==='Wechat'" :to="{name:'weiXinqrcode',params:{url:item.info}}">
					<ici-icon  name="icon-erweima"></ici-icon>
				</router-link>

			</yd-flexbox>
			<p style="text-align: center;">
				<ici-button type="default" @click="$emit('input',false)" class="text-center" shape="circle">
					<ici-icon name="icon-shanchudelete30"></ici-icon>
				</ici-button>
			</p>
		</div>
	</yd-popup>
</template>

<script>
	export default {
		name: "popup-edit-contact",
		data() {
			return {};
		},
		props: {
			value: Boolean,
			dataItem: {
				type: Object,
				default() {
					return {}
				}
			}
		},

		methods: {
			typeToPrefix(type) {
				var obj = false;
				switch (type) {
					case 'LinkedIn':
					case 'Linkedin':
						obj = {
							content: 'linkedin.com/in/',
							value: 'https://www.linkedin.com/in/',
						};
						break;

					case 'Facebook':
						obj = {
							content: 'facebook.com/',
							value: 'https://www.facebook.com/',
						};
						break;
					case 'Twitter':
						obj = {
							content: 'twitter.com/',
							value: 'https://twitter.com/',
						};
						break;
					case 'Skype':
						break;
					case 'Wechat':
						break;
					case 'Email':
						break;
					case 'Phone':
						break;
					case 'Google Plu':
						break;
				}
				return obj;
			},
			typeToFilter(type) {
				var reg = false;
				switch (type) {
					case 'LinkedIn':
					case 'Linkedin':
						reg = /(https?:\/\/)?(\w+\.)?linkedin.com\/in\//
						break;

					case 'Facebook':
						reg = /(https?:\/\/)?(\w+\.)?facebook.com\//
						break;
					case 'Twitter':
						reg = /(https?:\/\/)?(\w+\.)?twitter.com\//

						break;
					case 'Skype':
						break;
					case 'Wechat':
						break;
					case 'Email':
						break;
					case 'Phone':
						break;
					case 'Google Plu':
						break;
				}
				return reg;
			},
			//头像处理
			imageProcessing(img) {
				if (img) {
					return img
				} else if (this.dataItem.whois) {
					return '../imgs/whois.svg'
				} else {
					return '../imgs/default_icon.jpg'
				}
			},
			input(val) {
				this.$emit('input', val)
			}
		},
		components: {}
	}
</script>

<style scoped lang="less">

	.popup-icon {
		margin: auto;
		transition: all .6s;
		border-radius: 50%;
		flex: none;
		width: 60px;
		height: 60px;
	}

	.popups {
		padding: 15px;
		border-radius: 5px;
		overflow: hidden;
		background: #fff;
	}

	.info-list {
		padding: 10px 0;
		> :first-child {
			color: #999;
			padding-right: 10px;
		}
	}
</style>