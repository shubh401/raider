<template>
	<div class="item-wrap">
		<!--whois-->
		<yd-cell-item :class="['cellitem',{recycle:dataItem.whois && dataItem.whois.whois_status==0},{unfold:isUnfold}]"
						  type="checkbox">
			<div class="item-top" slot="icon">
				<div @click.prevent.stop="editMore=true" class="icon bg-icon"
					  :style="`background-image:url(${imageProcessing(dataItem.data.img)})`"></div>
				<div class="select-color">
					<div class="color-blue" :class="{active:status===3}" @click.prevent="setStatus(3)">
						<div></div>
					</div>
					<div class="color-green" :class="{active:status===1}" @click.prevent="setStatus(1)">
						<div></div>
					</div>
					<div class="color-yellow" :class="{active:status===0}" @click.prevent="setStatus(0)">
						<div></div>
					</div>
				</div>
			</div>
			<!--doUnfold展开关闭事件，只对whois有效-->
			<div slot="left" class="userinfo item-top" @click="doUnfold">
				<div class="line-clamp line-clamp-1 domain" v-if="dataItem.whois">
					<a target="_blank" :href="`http://${dataItem.whois.domain}`">{{dataItem.whois.domain}}</a>
				</div>
				<h3 v-if="!contactEdit || editField!=='contact_name'" class="line-clamp line-clamp-1 contact_name"
					 @click.stop.prevent="editContact('contact_name')">
					{{dataItem.data.contact_name}}
				</h3>
				<ici-input v-else class="iciinput" :value="dataItem.data.contact_name"
							  @input="inputContact('contact_name',$event)"
							  @select="selectHint" :focus="contactEdit && editField=='contact_name'" required
							  @blur="contactEdit=false" :hint="hint" @keyup-enter="contactEdit=false">
					<a slot="title">
						<ici-icon name="icon-tianjia"></ici-icon>
						{{$t('添加')}}
					</a>
					<template slot-scope="list">
						<div class="fms-input-hint-icon"
							  :style="list.item.header?'background-image:url('+list.item.header+')':''"></div>
						<div class="fms-input-hint-name  nowrap">
							<span
								v-html="list.item.contact_name.replace(new RegExp('('+dataItem.data.contact_name+')','ig'),'<b style=color:red>$1</b>')"></span>
							<div v-if="list.item.company || list.item.title">
								<small>{{list.item.title || list.item.company}}</small>
							</div>
						</div>
					</template>
				</ici-input>

				<p v-if="!contactEdit || editField!=='title'" class="small title line-clamp line-clamp-1">
					<span class="click" @click.stop.prevent="editContact('title')">
						<span v-if="dataItem.data.title">{{dataItem.data.title}}</span>
						<span v-else-if="!this.dataItem.contact_id && this.dataItem.requestStatus!=1" style="color:#eec638;">
							<ici-icon name="icon-dianji"></ici-icon> {{$t('点击添加职称')}}
						</span>
					</span>
				</p>
				<ici-input v-else class="iciinput smallinput" :value="dataItem.data.title" @blur="contactEdit=false"
							  @input="inputContact('title',$event)" @keyup-enter="contactEdit=false"
							  :focus="contactEdit && editField=='title'"></ici-input>

				<p v-if="!contactEdit || editField!=='company'" class="small text-999 line-clamp line-clamp-2">
					<span class="click" @click.stop.prevent="editContact('company')">
						<span v-if="dataItem.data.company">{{dataItem.data.company}}</span>
						<span v-else-if="!this.dataItem.contact_id && this.dataItem.requestStatus!=1" style="color:#eec638">
							<ici-icon name="icon-dianji"></ici-icon> {{$t('点击添加单位')}}
						</span>
					</span>
				</p>
				<ici-input v-else class="iciinput smallinput" :value="dataItem.data.company" @blur="contactEdit=false"
							  @input="inputContact('company',$event)" :hint="companyHint" @select="selectCompanyHint"
							  @keyup-enter="contactEdit=false" :focus="contactEdit && editField=='company'">
					<div slot-scope="list" class="newline"
						  v-html="list.item.name.replace(new RegExp('('+dataItem.data.company+')','ig'),'<b style=color:red;>$1</b>')">
					</div>
				</ici-input>

				<p v-if="dataItem.data.detailed_address" class="address small text-999">
					<a :href="'https://www.google.com/maps/search/'+dataItem.data.detailed_address" target="_blank">
						<ici-icon name="icon-weizhi"></ici-icon>
					</a>
					{{dataItem.data.detailed_address}}
				</p>
				<p v-if="dataItem.requestStatus==3" class="small" style="color: #f00"
					:title="dataItem.msg+', '+$t('请重试')">
					<ici-icon name="icon-gengxin" size="16px" color="#f00"></ici-icon>
					{{dataItem.msg+', '+$t('请重试')}}
				</p>
				<div class="web-logo">
					<a v-for="i of dataItem.data.contact" target="_blank" :href="i|toUrl" :title="i.info"
						:class="{block:typeToIsBlock(i.type)}">
						<ici-icon style="vertical-align: -3px" :name="i.type|typeToIcon" :color="i.type|typeToColor"
									 @click.native="clickIcon(i,$event)"
									 size="22px"></ici-icon>
						<span v-if="typeToIsBlock(i.type)" :style="{color:typeToColor(i.type)}">{{i.info|shortUrl}}</span>
					</a>
				</div>
			</div>
			<template v-if="dataItem.requestStatus==0 || dataItem.requestStatus==4 || dataItem.requestStatus==3">
				<div v-if="dataItem.whois && isUnfold" slot="right">
					<!--whois内容, 显示删除按钮或还原按钮-->
					<ici-icon v-if="dataItem.whois.whois_status" class="set-whois-status" size="20px" name="icon-huishouzhan"
								 @click.native.stop.prevent="setWhoisStatus(dataItem.whois.whois_id,0)"></ici-icon>
					<ici-icon v-else class="set-whois-status" size="20px" name="icon-huifu"
								 @click.native.stop.prevent="setWhoisStatus(dataItem.whois.whois_id,1)"></ici-icon>
				</div>
				<input v-if="dataItem.contact_id==0"
						 class="item-top" slot="right" type="checkbox" :value="index" v-model="checkedIndex"/>
				<div v-else slot="right">
					<ici-icon v-if="dataItem.isUpdate" class="pointer" name="icon-Versionupdaterule-copy"
								 @click="update()"
								 size="20px" color="rgb(255,150,0)" :title="$t('更新')">
					</ici-icon>
					<ici-icon v-else name="icon-yduigouxuan" size="20px" color="#04be02"></ici-icon>
				</div>
			</template>
		</yd-cell-item>
		<div class="item-more" v-if="!dataItem.contact_id && dataItem.someNames.length">
			<div class="flex flex-center somename" v-if="dataItem.someNames.length">
				<div class="flex-none text-666 text-right small">
					<ici-icon size="20px" color="#C01639" name="icon-icon-test" :title="$t('重名')"></ici-icon>
				</div>
				<div class="flex-auto">
					<el-tooltip v-for="(item,index) of dataItem.someNames" :key="item.id" effect="dark" placement="top"
									:content="item.title +(item.title && item.company?' at ':'')+item.company">
						<div @click.prevent.stop="selelctSomeName(index)" class="somename-icon bg-icon"
							  :style="`background-image:url(${imageProcessing(item.header)})`"></div>
					</el-tooltip>
				</div>
			</div>
		</div>
		<div v-if="dataItem.requestStatus==1" class="requestLoading" key="loading">
			<ici-loading size="small" disabled></ici-loading>
		</div>
		<merge v-if="dataItem.serverData" :ref="'merge'+index" :data-item="dataItem" @success="successMerge"></merge>
		<!--编辑采集内容详细-->
		<popup-edit-contact v-model="editMore" :data-item="dataItem"></popup-edit-contact>
	</div>
</template>

<script>
	import {setWhoisStatus, findContact, companySearch, changeStatus} from '../../vue-common/ajax/contact'
	import merge from '../components/merge'
	import popupEditContact from '../components/popup-edit-contact.vue'
	import {indexToAddContacts} from '../../vue-common/functions/functions'

	var findContactCache = funs.cachedPromise(findContact)
	var companySearchCache = funs.cachedPromise(companySearch)

	export default {
		name: "list-item",
		data() {
			return {
				hint: false, //提示文字，false无提示，true等待提示,[数组]提示列表；
				companyHint: false,//提示文字，false无提示，true等待提示,[数组]提示列表；
				someNames: [],
				timeoutId: 0,
				contactEdit: false,
				editField: 'contact_name',
				editMore: false,
				checkedIndex: [],
				status: 1,
				whois: null
			}
		},

		props: {
			s: Number,
			dataItem: Object,
			index: Number,
			value: Array,
		},

		created() {

			if (this.dataItem.contact_id) {
				this.status = this.dataItem.serverData.status;
			} else {
				this.status = this.s;
				this.$set(this.dataItem.data, 'status', this.s);
			}

			console.log(this.dataItem)
			if (this.dataItem.whois) {
				this.whois = this.dataItem.whois

			}
		},
		watch: {

			s() {
			  this.status = this.s;
			},
			value() {
				this.checkedIndex = this.value;
			},
			checkedIndex() {
				this.$emit('input', this.checkedIndex);
			}
		},
		mounted() {
			this.checkedIndex = this.value;
		},
		computed: {
			//是否展开
			isUnfold() {
				if (this.whois && this.whois.whois_status == 0 && !this.whois.unfold) {
					return false;
				} else {
					return true;
				}
			},
		},

		filters: {

			toUrl(val) {
				var url = val.info;
				switch (val.type) {
					case 'Email':
						url = 'mailto:' + val.info;
						break;
					case 'Phone':
						url = 'tel:' + val.info;
						break;
				}
				return url;
			}
		},

		methods: {
			setStatus(val) {
				if (this.dataItem.contact_id) {
					this.$dialog.loading.open(this.$t('稍等') + '...');
					changeStatus({status: val, id: this.dataItem.contact_id}).then(() => {
						this.$dialog.loading.close();
						this.status = val;
						this.dataItem.serverData.status = val;
						this.$dialog.notify({
							mes: this.$t('更改成功'),
							timeout: 1000,
						});
					}).catch((err) => {
						this.$dialog.notify({
							mes: err.msg,
							timeout: 1000,
						});
					}).finally(() => {
						this.$dialog.loading.close();
					})

				} else {
					this.status = val
					this.$set(this.dataItem.data, 'status', val);
				}


			},
			clickIcon(e, event) {
				if (e.type == "Wechat") {
					event.stopPropagation()
					event.preventDefault()
					this.$router.push({name: 'weiXinqrcode', params: {url: e.info}})
				}
			},
			selelctSomeName(index) {
				this.dataItem.getServerData(this.dataItem.someNames[index], true);
				this.$nextTick(() => {
					this.update();
				})
			},
			inputContact(name, value) {
				console.log(name, value);
				this.dataItem.data[name] = value;

				if (name === 'contact_name') {
					this.findContactName()
				} else if (name === 'company') {
					this.findCompanyName();
				}
			},

			selectHint(index) {
				console.log('index', index)
				if (index !== -1) {
					console.log(this.hint[index])
					this.dataItem.getServerData(this.hint[index], true);
					this.$nextTick(() => {
						this.update();
					});
				} else {

					indexToAddContacts([this.index], this.$store.state.urlId);
				}
			},
			selectCompanyHint(index) {

				if (index > -1) {
					var name = this.companyHint[index].name;
					this.$nextTick(() => {
						this.dataItem.data.company = name
					})
				}


			},
			editContact(name) {
				if (!this.dataItem.contact_id && this.dataItem.requestStatus !== 1) {
					this.contactEdit = true;
					this.editField = name;
					if (this.editField === 'contact_name') {
						this.findContactName()
					}
				}
			},
			findContactName() {
				clearTimeout(this.timeoutId);
				this.hint = false;
				if (this.dataItem.data.contact_name.length > 1) {
					this.hint = true;
					this.timeoutId = setTimeout(() => {
						findContactCache(this.dataItem.data.contact_name).then((data) => {
							data = data.sort((val1, val2) => {
								return val1.contact_name.toLowerCase().indexOf(this.dataItem.data.contact_name.toLowerCase())
									> val2.contact_name.toLowerCase().indexOf(this.dataItem.data.contact_name.toLowerCase())
							});
							this.hint = data;
						}).catch((err) => {
							console.log(err)
						})
					}, 400)
				}
			},

			findCompanyName() {
				clearTimeout(this.timeoutId);
				this.companyHint = false;
				if (this.dataItem.data.company.length > 1) {
					this.companyHint = true;
					this.timeoutId = setTimeout(() => {
						companySearchCache(this.dataItem.data.company).then((data) => {
							data.data = data.data.sort((val1, val2) => {
								return val1.name.toLowerCase().indexOf(this.dataItem.data.company.toLowerCase())
									> val2.name.toLowerCase().indexOf(this.dataItem.data.company.toLowerCase())
							});
							this.companyHint = data.data || [];
						}).catch((err) => {
							console.log(err)
						})
					}, 400)
				}
			},

			update() {
				this.$refs['merge' + this.index].showLoading = true
			},

			successMerge(contact_id) {
				this.dataItem.requestSuccess(contact_id)
				this.dataItem.updated = true;
			},
			doUnfold() {
				if (this.dataItem.whois) {
					this.dataItem.whois.unfold = !this.dataItem.whois.unfold;
				}
			},
			//头像处理
			imageProcessing(img) {
				if (img) {
					return img
				} else if (this.dataItem.whois) {
					return '../imgs/whois.svg'
				} else {
					return '../imgs/default_icon.jpg'
				}
			},
			typeToColor: funs.typeToColor,
			typeToIsBlock(type) {
				var isBlock = false;
				switch (type) {
					case 'Email':
						isBlock = true;
						break;
					case 'Phone':
						isBlock = true;
						break;
				}
				return isBlock;
			},
			//修改whois状态
			setWhoisStatus(id, val) {
				setWhoisStatus({id: id, status: val}).then(() => {
					this.dataItem.whois.unfold = false,
						this.dataItem.whois.whois_status = val;
				})
			},
		},
		components: {merge, popupEditContact}
	}
</script>

<style scoped lang="less">
	.select-color {
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 5px 0;
		> div {
			padding: 5px;
			cursor: pointer;
			transition: all .3s;
			> div {
				width: 10px;
				height: 10px;
			}
			&:hover {
				background: #e9e9e9;
			}
			&.active {
				background: #e6e6e6;
			}
		}
		.color-blue > div {
			background: #286aaf;
		}
		.color-green > div {
			background: #1eaf5c;
		}
		.color-yellow > div {
			background: #dad55e;
		}
	}

	.item-wrap {
		margin-top: 7px;
		box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, .1);
		.item-more {
			background: #f7f7f7;
			padding: 7px 10px 3px;
			z-index: 1;
		}
		.somename {

			> :first-child {
				padding-right: 10px;
				width: 70px;
			}
			> :last-child {

				.somename-icon {
					display: inline-block;
					margin-left: 10px;
					width: 36px;
					height: 36px;
					border-radius: 50%;
					cursor: pointer;
					box-shadow: 0 0 0px 4px #fff;
					transition: all 0.1s;
					&:hover {
						box-shadow: 0 0 0px 4px #eee;
					}
				}
			}
		}
	}

	.item-wrap {
		position: relative;
	}

	.title {
		-webkit-line-clamp: 1 !important;
	}

	.click {
		cursor: pointer;
		&:hover {
			border-radius: 5px;
			background: #eee;
		}
	}

	.line-clamp {
		overflow: hidden;
		white-space: normal;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		padding-left: 5px;
		margin-bottom: 5px;
		line-height: 1.4em;
	}

	.userinfo {
		transition: all .6s;
		flex: auto;
		min-height: 60px;
		padding: 5px 0;
		width: 245px;
		.iciinput {
			font-weight: 700 !important;
			padding-top: 0px !important;
			padding-left: 5px;
			margin-bottom: 5px;
			line-height: 1.4em;
			&.smallinput {
				margin-top: -6px;
				margin-bottom: 3px;
			}
		}
		> line-clamp-1 {
			.line-clamp;
			-webkit-line-clamp: 1;
		}
		> line-clamp-2 {
			.line-clamp;
			-webkit-line-clamp: 2;
		}
		> .web-logo {
			padding-left: 5px;
			white-space: pre-wrap;
			a.block {
				max-width: 100%;
				white-space: nowrap;
				display: inline-block;
				margin-right: 5px;
			}
		}
		.address {
			text-overflow: initial !important;
			overflow: visible !important;
			-webkit-box-orient: initial !important;
			word-wrap: break-word;
			word-break: break-all;
			white-space: normal !important;
		}
	}

	.contact_name {
		display: inline-block !important;
		padding: 2px 2px 2px 5px;
		margin-bottom: 0px !important;
		transition: all .1s;
		&:hover {
			border-radius: 5px;
			cursor: pointer;
			background: #eee
		}
	}

	.item-top {
		padding-top: 10px;
		height: 100%;
		.icon {
			border-radius: 50%;
			cursor: pointer;
			transition: all 0.1s;
			&:hover {
				box-shadow: 0 0 0px 7px #eee;
			}
		}
	}

	.retry {
		cursor: pointer;
	}

	.requestLoading {
		position: absolute;
		top: 20px;
		right: 12px;
	}

	.yd-cell-right {
		align-items: flex-start;
	}

	.wrap {
		height: 100%;
	}

	.newline {
		font-weight: normal !important;
		font-size: .8em;
		white-space: normal;
		text-overflow: ellipsis;
		word-wrap: break-word;
		word-break: break-all;
	}

	.set-whois-status {
		cursor: pointer;
		display: block;
		margin-top: -15px;
		margin-bottom: 5px;
		color: #aaa !important;
		&:hover {
			color: #ff0000 !important;
		}
	}

	.cellitem {
		&::after {
			border-bottom-width: 0px;
		}
		transition: all .3s linear;
		max-height: 600px;
		.yd-cell-right {
			align-items: flex-start;
		}

		&.recycle {
			background: #fff4f0 !important;
			max-height: 35px;
			overflow: hidden;
			&:before {
				content: 'useless';
				position: absolute;
				bottom: 0px;
				right: 0px;
				padding: 2px 5px;
				color: #fff !important;
				font-size: 9px;
				border-radius: 10px 0 0 0;
				background: #ff6b23;
			}
			.domain {
				line-height: .9em !important;
			}
			.userinfo {
				min-height: 35px;
			}
			.icon {
				border-radius: 0;
				border: none;
				box-shadow: none;
				height: 15px;
				background-color: transparent;
			}
			&.unfold {
				overflow: visible;
				max-height: 600px;
				.icon {
					.item-top .icon;
					height: 60px;
				}
				.domain {
					line-height: 1.5em !important;
				}
				.userinfo {
					min-height: 60px;
				}
			}
		}
	}

	.icon {
		transition: all .6s;
		flex: none;
		width: 60px;
		height: 60px;
		margin-right: 2px;
	}

</style>
