<style scoped lang="less">
	.pop-inner {
		padding: 15px;
	}

	.handle {
		background: #eee;
		display: flex;
		justify-content: space-between;
	}

	.handle > div:first-child {
		padding: 12px 10px;
	}

	.handle > div:last-child {
		text-align: right;
		padding: 8px 10px;
	}

	.handle > div {
		&:first-child {
			flex: auto;
		}
		&:last-child {
			flex: none;
		}
	}

	.btn {
		width: 100px;
	}

	.req-list {
		display: flex;
		margin-top: 10px;
		.bg-icon {
			flex: none;
			border-radius: 5px;
			vertical-align: -3px;
			margin-right: 5px;
			display: inline-block;
			width: 24px;
			height: 24px
		}

		.contactname {
			flex: none;
			display: inline-block;
			padding-right: 6px;
			width: 120px;
		}
		.msg {
			flex: auto;
		}
	}

	.req-list-wrap > li {
		&.success {
			.contactname {
				color: #049e02;
			}
			.msg {
				color: #049e02;
			}
		}
		&.wraning, &.merge {
			.contactname {
				color: #d89806;
			}
			.msg {
				color: #d89806;
			}
		}
		&.waiting {
			.contactname {
				color: #999;
			}
			.msg {
				color: #999;
			}
		}
		&.loading, &.requesting {
			.contactname {
				color: #C01639;
			}
			.msg {
				color: #C01639;
			}
		}
	}

	.btn-item {
		font-size: .7em;
		margin-bottom: 5px;
		padding: 0 5px;
		height: 25px;
	}

	.all-status {
		width: 20px;
		height: 20px;
		cursor: pointer;
		&.color-blue {
			background: #286aaf;
		}
		&.color-green {
			background: #1eaf5c;
		}
		&.color-yellow {
			background: #dad55e;
		}
	}

</style>
<template>
	<div>
		<div class="handle">
			<div class="flex">
				<div class="all-status" :class="{'color-blue':status===3,'color-green':status===1}"
					  @click="$emit('changeStatus')"></div>
			</div>
			<div>
				<ici-button type="ici" relievo shape="pill" size="small" :disabled="value.length==0" @click="request">
					<ici-icon name="icon-tianjia" size="12px"></ici-icon>
					{{$t('添加')}}
				</ici-button>
				&nbsp;&nbsp;
				<yd-checkbox class="flex-none" shape="circle" color="#F00" v-model="checkAll" @click.native="selectAll">
					&nbsp;
				</yd-checkbox>
			</div>
		</div>
	</div>
</template>

<script>
	import {indexToAddContacts} from '../../vue-common/functions/functions'

	export default {
		name: "batch-add-contact",
		data() {
			return {
				//是否已全选
				checkAll: false,
				allIndex: [], //所有可添加的数据的Index数组
			}
		},

		props: {
			status: {
				type: Number,
				default: 1
			},
			//是否是whois数据
			haswhois: Boolean,
			//选中的索引
			value: {
				type: Array,
				default() {
					return []
				}
			},
			data: {
				type: Array,
				default() {
					return []
				}
			}
		},
		watch: {
			value() {
				if (this.value.length == this.allIndex.length) {
					this.checkAll = true;
				} else {
					this.checkAll = false;
				}
			},
			data: {
				handler() {
					this.initData()
				},
				deep: true
			},
		},
		methods: {

			initData() {
				if (this.data) {
					var indexs = []
					this.data.forEach((val, index) => {
						if (val.contact_id == 0 && val.unfold !== false && val.requestStatus == 0) {
							indexs.push(index);
						}
					})
					this.allIndex = indexs;
				} else {
					this.allIndex = [];
				}

				if (localStorage.getItem('checkAll')) {
					this.$emit('input', JSON.parse(JSON.stringify(this.allIndex)))
				}
			},
			//全选操作
			selectAll() {

				if (!this.checkAll) {
					this.$emit('input', JSON.parse(JSON.stringify(this.allIndex)))
					localStorage.setItem('checkAll', '5')
				} else {
					localStorage.removeItem('checkAll')
					this.$emit('input', [])
				}

			},

			//请求中
			request() {
				if (this.haswhois) {
					indexToAddContacts(this.value, 'haswhois');
				} else {
					indexToAddContacts(this.value, this.$store.state.urlId);
				}

				this.$emit('input', [])
			},
			showChange(val) {
				this.$emit('update:show', val)
			}
		},
	}
</script>
