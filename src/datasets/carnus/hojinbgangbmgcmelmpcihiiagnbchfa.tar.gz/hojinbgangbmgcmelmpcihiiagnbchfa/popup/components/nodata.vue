<template>
    <div class="nodata">
      <ici-icon name="icon-wushuju" size="60px" color="#ddd"></ici-icon>
      <br>
      <div class="nodata-text">{{$t('没有找到数据')}}～～</div>
    </div>
</template>

<script>
	export default {
		name: "nodata"
	}
</script>

<style scoped>
  .nodata{
    text-align: center;
    padding:100px 50px 0;
  }
  .nodata-text{
    color:#aaa;
    font-size:1.15em;
  }
</style>
