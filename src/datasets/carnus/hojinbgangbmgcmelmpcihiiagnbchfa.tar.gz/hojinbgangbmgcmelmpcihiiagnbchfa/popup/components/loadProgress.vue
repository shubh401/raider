<template>
  <div class="loadpro">
    <div>
      <div class="prsinner" >
        <yd-progressbar :progress="progress" trail-width="2" stroke-width="4"
                        stroke-color="#eee" trail-color="#FE5D51">
          {{text}}
        </yd-progressbar>
      </div>
    </div>
  </div>
</template>

<script>
	export default {
		name: "load-progress",
    props:{
      text:{
        type:String,
        default:'',
      },
      progress:{
        type:Number,
        default:0.2,
      }
    }
	}
</script>

<style scoped>
  .loadpro{
    position: absolute;
    display: flex;
    flex-direction: column;
    justify-content:center;
    background:#fff;
    left:0;
    right:0;
    bottom:0;
    top:0;
    z-index: 9999;
  }
  .prsinner{
    width:150px;
    height:150px;
    margin:auto;
  }
</style>
