<template>
	<yd-popup v-model="showLoading" position="right" width="400px">
		<div>
			<yd-navbar :title="($t('更新'))+' '+$t('联系人')" height="45px" fontsize="16px">
				<div slot="left" @click="showLoading = false">
					<yd-navbar-back-icon></yd-navbar-back-icon>
				</div>
				<a href="#" slot="right" @click="reset">
					{{$t('重置')}}
				</a>
			</yd-navbar>
		</div>
		<edit-contact v-if="dataItem && !isReset && showLoading" :dataItem="dataItem" @success="successMerge"></edit-contact>
	</yd-popup>
</template>

<script>
	import editContact from '../components/editContact'
	//合并联系人
	export default {
		name: "merge",
		data() {
			return {
				showLoading: false,
				isReset: false, //重置
			}
		},
		props: {
			dataItem: {
				type: Object,
				default() {
					return {}
				}
			},
		},
		methods: {
			reset() {
				this.isReset = true;
				setTimeout(() => {
					this.isReset = false;
				}, 0)
			},
			successMerge(contact_id) {
				//更新数据
				this.$emit('success', contact_id)
				this.showLoading = false;
			},
		},
		components: {editContact}
	}
</script>

<style scoped lang="less">
	.userinfo {
		padding: 15px;
	}

	.userinfo-item {
		padding: 5px 0;
		border-bottom: 1px solid #eee;
		label {
			display: inline-block;
			width: 80px;
			padding: 7px 15px 7px 0;
		}
		.options {
			flex: auto;
			font-size: .8em;

		}

	}

	.delete {
		padding: 5px;
		cursor: pointer;
		color: #eee !important;
		&:hover {
			color: #ff0000 !important;
		}
	}

	.pic {
		white-space: normal !important;
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 5px;
		.pic-inner {
			overflow: hidden;
			position: relative;
			margin: 5px 5px 0 0;
			width: 81px;
			height: 81px;
			&:nth-child(4n) {
				margin-right: 0px;
			}
			&:hover {
				.pic-handle {
					bottom: 0 !important;
				}
			}
			.pic-handle {
				position: absolute;
				bottom: -60px;
				width: 100%;
				font-size: .8em;
				line-height: 2em;
				background: rgba(0, 0, 0, .5);
				text-align: center;
				-webkit-transition: all .1s;
				-moz-transition: all .1s;
				-ms-transition: all .1s;
				-o-transition: all .1s;
				transition: all .1s;
				a {

					color: #fff !important;
					&:last-child {
						color: #ff0000 !important;
					}
				}

			}

		}
	}


</style>