<template>
	<div>
		<div v-if="active && server" class="userinfo">
			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('联系人')}}</label>
				<div class="options">
					<radioField required :values="[server.contact_name,active.contact_name]"
									v-model="newData.contact_name"></radioField>
				</div>
			</div>
			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('名')}}</label>
				<div class="options">
					<radioField required :values="[server.first_name,active.first_name]"
									v-model="newData.first_name"></radioField>
				</div>
			</div>
			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('姓')}}</label>
				<div class="options">
					<radioField required :values="[server.last_name,active.last_name]"
									v-model="newData.last_name"></radioField>
				</div>
			</div>

			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('职位')}}</label>
				<div class="flex-auto options">
					<multipleField :values="[server.title,active.title]" v-model="newData.title"></multipleField>
				</div>
			</div>

			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('公司')}}</label>
				<div class="flex-auto options">
					<radioField :values="[server.company,active.company]" v-model="newData.company"></radioField>
				</div>
			</div>
			<div class="userinfo-item flex">
				<label class="flex-none text-right">{{$t('工作城市')}}</label>
				<div class="flex-auto options">
					<radioField :values="[server.city,active.city]" v-model="newData.city"></radioField>
				</div>
			</div>
			<br>
			<yd-cell-group :title="$t('联系方式')">
				<yd-cell-item v-for="(item,index) of server.info" :key="'info' + index">
					<ici-icon slot="icon" :name="item.type|typeToIcon" :color="item.type|typeToColor"
								 size="20px"></ici-icon>
					<a target="_blank" :href="item.info" slot="left">
						<span class="main-color contact_content">{{item.info|shortUrl}}</span>
					</a>
					<ici-icon slot="right" name="icon-shanchudelete30" class="delete" size="16px"
								 @click.native="delContactWay(index,server.info)"></ici-icon>
				</yd-cell-item>

				<yd-cell-item v-for="(item,index) of active.contact" :key="'contact'+index">
					<ici-icon slot="icon" :name="item.type|typeToIcon" :color="item.type|typeToColor"
								 size="20px"></ici-icon>
					<a target="_blank" :href="item.info" slot="left">
						<span style="display: inline-block;max-width:250px;">{{item.info|shortUrl}}</span>
						<yd-badge type="primary">{{$t('新增')}}</yd-badge>
					</a>
					<ici-icon slot="right" name="icon-shanchudelete30" class="delete" size="16px"
								 @click.native="delContactWay(index,active.contact)"></ici-icon>
				</yd-cell-item>
			</yd-cell-group>

			<yd-cell-group :title="$t('相片')" v-if="server.imgs.length || active.img">
				<yd-cell-item>
					<div slot="left" class="pic">
						<div v-if="active.img" class="pic-inner bg-icon"
							  :style="`background-image:url(${active.img})`">
							<yd-badge v-if="active.is_show" type="danger" class="pointer">{{$t('默认')}}</yd-badge>
							<yd-badge type="primary" class="pointer">{{$t('新增')}}</yd-badge>
							<div class="pic-handle">
								<a v-if="!active.is_show" class="pointer" @click="setNewIcon">{{$t('设为头像')}}</a>
								<a @click="active.img='',newData.img=''" class="pointer">{{$t('删除')}}</a>
							</div>
						</div>
						<div v-for="(img,index) of server.imgs" :key="index" class="pic-inner bg-icon"
							  :style="`background-image:url(${img.img})`">
							<yd-badge v-if="img.is_show" type="danger">{{$t('默认')}}</yd-badge>
							<div class="pic-handle">
								<a v-if="!img.is_show" class="pointer" @click="setIcon(index)">{{$t('设为头像')}}</a>
								<a @click="delContactImg(index)" class="pointer">{{$t('删除')}}</a>
							</div>
						</div>
					</div>
				</yd-cell-item>
			</yd-cell-group>
			<yd-button size="large" type="primary" @click.native="submit">{{$t('更新')}}</yd-button>
		</div>
	</div>
</template>

<script>
	import {delImg, setDefaultImg, EditContact} from '../../vue-common/ajax/contact';
	import radioField from '../components/radio_field';
	import multipleField from '../components/multiple_field'

	export default {
		name: "edit_contact",
		data() {
			return {
				showLoading: false,
				newData: {},
				active: null,
				server: null,
			}
		},
		watch: {
			dataItem() {
				this.initNewData();
			},

		},
		created() {
			this.initNewData();
		},
		props: {
			dataItem: {
				type: Object,
				default() {
					return {}
				}
			},
		},
		methods: {
			//选择操作
			select(field, index) {
				var value = '';
				if (index == 0) {
					value = this.server[field]
				} else if (index == 1) {
					value = this.active[field]
				}
				this.newData[field] = value;
			},

			//初始化数据
			initNewData() {
				var datas = this.dataItem.mergeInit();

				this.server = datas.serverData;
				this.active = datas.data;
				this.newData = datas.newData;
			},

			submit() {
				this.$dialog.loading.open(this.$t('正在合并'));
				funs.imgUrlToBase64(this.newData.img).then((val) => {
					return EditContact({...this.newData, title: this.newData.title.toString(), img: val});
				}).then(() => {
					console.log('合并成功');
					this.showLoading = false;
					this.$emit('success', this.newData.contact_id);
					this.$dialog.loading.close();
				}).catch((err) => {
					console.log('合并失败');
					this.$dialog.loading.close();
					this.$dialog.alert({mes: err.msg})
				})

			},
			//删除联系方式
			delContactWay(index, obj) {
				this.newData.contact.some((val, i) => {
					if (val.info === obj[index].info) {
						this.newData.contact.splice(i, 1);
						return true;
					}
				})
				obj.splice(index, 1)
			},

			//删除图片
			delContactImg(index) {
				setTimeout(() => {
					this.$dialog.confirm({
						title: this.$t('删除警告'),
						mes: this.$t('删除该图片将无法重置恢复，确定删除吗？'),
						opts: () => {

							var imgs = this.server.imgs
							this.$dialog.loading.open(this.$t('稍等'));
							delImg(imgs[index].id).then(() => {
								this.dataItem.serverData.imgs.splice(index,1)
								imgs.splice(index, 1)
								this.$dialog.loading.close();
							}).catch((err) => {
								this.$dialog.alert({mes: err.msg})
								this.$dialog.loading.close();
							})
						}
					});
				}, 0)
			},
			change(val, field) {
				this.newData[field] = val
			},

			//设置新图片为默认头像
			setNewIcon() {
				this.$set(this.active, 'is_show', 1)
				this.$set(this.newData, 'is_show', 1)
				this.server.imgs.forEach((val, index) => {
					console.log('val', this.server.info[index])
					this.server.imgs[index].is_show = 0;
				})
			},

			//设置默认头像
			setIcon(index) {
				var img = this.server.imgs[index]
				this.$dialog.loading.open(this.$t('稍等'));

				setDefaultImg({id: img.id, contact_id: img.contact_id}).then(() => {
					this.server.imgs[index].is_show = 1;

					this.server.imgs.some((val, i) => {
						if (i != index && val.is_show == 1) {
							val.is_show = 0
							return true
						}
					})

					this.$set(this.active, 'is_show', 0)
					this.$set(this.newData, 'is_show', 0)
					this.$dialog.loading.close();
				}).catch((res) => {
					this.$dialog.alert({mes: res.msg})
					this.$dialog.loading.close();
				})
			}
		},
		components: {radioField, multipleField}
	}
</script>

<style scoped lang="less">
	.userinfo {
		padding: 15px;
	}

	.userinfo-item {
		padding: 5px 0;
		border-bottom: 1px solid #eee;

		label {
			display: inline-block;
			width: 80px;
			font-size: .9em;
			padding: 7px 15px 7px 0;
		}
		.options {
			flex: auto;
			font-size: .8em;
			text-align: left !important;
		}

	}

	.contact_content {
		display: inline-block;
		max-width: 270px;
		vertical-align: middle;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.delete {
		padding: 5px;
		cursor: pointer;
		color: #eee !important;
		&:hover {
			color: #ff0000 !important;
		}
	}

	.pic {
		white-space: normal !important;
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 5px;
		.pic-inner {
			overflow: hidden;
			position: relative;
			margin: 5px 5px 0 0;
			width: 81px;
			height: 81px;
			&:nth-child(4n) {
				margin-right: 0px;
			}
			&:hover {
				.pic-handle {
					bottom: 0 !important;
				}
			}
			.pic-handle {
				position: absolute;
				bottom: -60px;
				width: 100%;
				font-size: .8em;
				line-height: 2em;
				background: rgba(0, 0, 0, .5);
				text-align: center;
				-webkit-transition: all .1s;
				-moz-transition: all .1s;
				-ms-transition: all .1s;
				-o-transition: all .1s;
				transition: all .1s;
				a {

					color: #fff !important;
					&:last-child {
						color: #ff0000 !important;
					}
				}
			}
		}
	}

	.dataTime {
		width:auto;
		display: inline-block;
		cursor: pointer;
		position: relative;
		display: inline-block;
		margin: 5px 5px 5px 0;
		padding: 5px 15px;
		color: #aaa;
		border: 1px solid #ddd;
		border-radius: 5px;
		transition: all 0.3s;
		background: #C01639;
		color: #fff;
		border: 1px solid #C01639;
	}

</style>