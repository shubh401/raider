<template>
	<span v-if="obj[field]" :class="{'read-write':isEdit,'new':fresh,'active':selected}" @blur="blur" @input="input"
			@keydown.stop.prevent.enter="blur"
			@dblclick="dblclick" @click="$emit('click',field,obj)">{{obj[field]}}</span>
</template>

<script>
	export default {
		name: "editablespan",
		data() {
			return {
				isEdit: false,
			}
		},
		created() {

		},
		props: {
			field: {
				type: String,
				default: ''
			},
			obj: {
				type: Object,
				default() {
					return {}
				}
			},
			selected: Boolean, //是否已选中
			fresh: Boolean, //是否是新的
		},
		methods: {
			blur(e) {
				console.log('blur')
				this.isEdit = false
				this.obj[this.field] = e.target.innerText;
			},
			input(e) {
				this.$emit('change', e.target.innerText, this.field)
			},
			enter() {
				this.isEdit = false
				this.obj[this.field] = e.target.innerText;
			},
			dblclick(e) {
				console.log(e)
				setTimeout(() => {
					e.target.focus()
				}, 0)
				this.isEdit = true
			}
		}
	}
</script>

<style scoped lang="less">
	span {
		cursor: pointer;
		position: relative;
		display: inline-block;
		margin: 5px 5px 5px 0;
		padding: 5px 15px;
		color: #aaa;
		border: 1px solid #ddd;
		border-radius: 5px;
		&.active {
			background: #C01639;
			color: #fff;
			border: 1px solid #C01639;
			&.new {
				background: #0bb20c;
				color: #fff;
				border: 1px solid #0bb20c;
				&:after {
					color: #fff !important;
				}
			}
		}

		&.new:after {
			font-family: "iconfont" !important;
			font-style: normal;
			-webkit-font-smoothing: antialiased;
			-moz-osx-font-smoothing: grayscale;
			position: absolute;
			content: '\e673';
			color: #aaa;
			font-size: 23px;
			line-height: 23px;
			top: -1px;
			left: -1px;
		}
	}

	.read-write {
		background: #fff !important;
		color: #666 !important;
		box-shadow: inset 0 0 10px 0 rgba(0, 0, 0, .5);
		-webkit-user-modify: read-write-plaintext-only;
	}

	.read-write:after {
		text-shadow: 1px 1px 5px #999;
	}


</style>