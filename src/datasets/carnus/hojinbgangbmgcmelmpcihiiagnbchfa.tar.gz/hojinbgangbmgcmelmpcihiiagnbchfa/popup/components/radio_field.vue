<template>
	<div class="radio_field" v-if="values && values.length" :key="Math.random()">
		<div class="radio_field" v-for="(item,index) of newValue" :key="`radio_field${item.index}${item.value}`">
			<span :class="{'read-write':editIndex===item.index,'new':item.index>0,'active':item.value==value}"
					@blur="blur(item.index,$event)" @keydown.stop.prevent.enter="blur(item.index,$event)"
					@dblclick="editIndex = item.index" @longtap="editIndex = item.index"
					@click="select(item.value,$event)" v-focus="editIndex===item.index" @tap.stop.prevent="select(item.value,$event)">{{item.value}}</span>
		</div>
		<label v-if="!newValue.length">
		<yd-button type="hollow" v-if="editIndex==-2" @click.native="add">
			<ici-icon class="pointer" color="#0bb20c" name="icon-tianjia"></ici-icon>
		</yd-button>
		<span v-if="editIndex==-1" v-focus class="addspan new active" :class="{'read-write':editIndex==-1}"
				@blur.stop.prevent="addblur($event)" @keydown.stop.prevent.enter="addblur($event)"></span>
		</label>
	</div>
</template>

<script>
	export default {
		name: "radio_field",
		data() {
			return {
				editIndex: -2,
				copyValues: [],
			}
		},

		created() {
			this.copyValues = JSON.parse(JSON.stringify(this.values))
		},
		computed: {
			newValue() {
				var arr = [];
				if (this.copyValues instanceof Array) {
					this.copyValues.forEach((val, index) => {
						if (!arr.some(val2 => val == val2.value)) {
							if (val) {
								arr.push({
									value: val,
									index: index,
								})
							}
						}
					});
				}
				return arr;
			}
		},
		props: {
			values: {
				type: Array,
				default() {
					return []
				}
			},
			value: {
				type: String,
				default: ''
			},
			required: Boolean,
		},
		directives: {
			focus: {
				// 指令的定义
				inserted: function (el) {
					el.focus()
				},
				update: function (el, binding) {
					if (binding.value == true && binding.oldValue == false) {
						el.focus()
					}
				}
			},
		},
		methods: {

			select(val) {
				this.$emit('input', val);
			},
			blur(index, e) {
				//如果不是在编辑状态下切换过来的，结束
				if (this.editIndex == -2) {
					return;
				}

				if (!funs.trim(e.target.innerText)) {
					if (this.required && this.copyValues.length === 1) {
						this.$dialog.toast({
							mes: '不能删除必选！',
							timeout: 1500
						});
						this.editIndex = -2;
						return
					} else {
						this.$delete(this.copyValues, index)
					}

				} else {
					this.$set(this.copyValues, index, e.target.innerText)
				}
				this.editIndex = -2;
				this.$emit('input', e.target.innerText);
			},
			add() {
				this.editIndex = -1
			},
			addblur(e) {
				if (e.target.innerText && this.editIndex >= -1) {
					this.blur(this.copyValues.length, e)
				} else {
					this.editIndex = -2;
				}


			},
			dblclick(index, e) {
				this.editIndex = index;
			}
		}
	}
</script>

<style scoped lang="less">
	span {
		&.addspan {
			min-width: 70px;
		}
		cursor: pointer;
		position: relative;
		display: inline-block;
		margin: 5px 5px 5px 0;
		padding: 5px 15px;
		color: #aaa;
		border: 1px solid #ddd;
		border-radius: 5px;
		&.active {
			background: #C01639;
			color: #fff;
			border: 1px solid #C01639;
			&.new {
				background: #0bb20c;
				color: #fff;
				border: 1px solid #0bb20c;
				&:after {
					color: #fff !important;
				}
			}
		}

		&.new:after {
			font-family: "iconfont" !important;
			font-style: normal;
			-webkit-font-smoothing: antialiased;
			-moz-osx-font-smoothing: grayscale;
			position: absolute;
			content: '\e673';
			color: #aaa;
			font-size: 23px;
			line-height: 23px;
			top: -1px;
			left: -1px;
		}
	}

	.read-write {
		background: #fff !important;
		color: #666 !important;
		box-shadow: inset 0 0 10px 0 rgba(0, 0, 0, .5);
		-webkit-user-modify: read-write-plaintext-only;
	}

	.read-write:after {
		text-shadow: 1px 1px 5px #999;
	}

	.radio_field {
		display: inline-block;
	}

</style>