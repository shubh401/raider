//数据中心，处理来自content_script内容
import Vue from 'vue';
import {addContact, EditContact, findContact, faceplusMatch, faceplusSetNoFile} from '../vue-common/ajax/contact'
import SearchWhois from '../vue-common/mixin/search_whois.js'
import DataItem from '../vue-common/DataItem.class.js'

var EditContactCache = funs.cachedPromise(EditContact);

window.vueApp = new Vue({
	mixins: [SearchWhois],
	data() {
		return {
			dataCenter: {},
			whoisData: [],
			num: 0
		}
	},
	methods: {

		//修改whois数据列表的值
		setWhoisDataList(dataList) {
			this.whoisData = dataList;
		},

		//添加contact操作
		//@param indexs {Array} dataList列表索引数组
		//@param urlId {String} 页面的URLID
		indexToAddContact(indexs, urlId) {

			var dataList;
			if (urlId == 'haswhois') {
				dataList = this.whoisData;
			} else {
				dataList = this.dataCenter[urlId];
			}

			indexs.forEach((val) => {
				dataList[val].requesting();
			});

			if (!dataList || !indexs.length) return false

			this.num++;
			var errorMsg = {  //保存错误的对象
				urlId: urlId + this.num,
				datas: [], //[Object ] 对象格式{title: '', message:  ''}
			}

			this.addContact(0, indexs, dataList, errorMsg);

		},

		/*
		* 添加contact
		* @param {Number} index 列表的索引
		* */
		addContact(index, indexs, dataList, errorData) {

			var progress = ~~((index) / indexs.length * 100);

			var opt = {
				title: 'Adding',
				message: `${index + 1}/${indexs.length}`,
				progress: progress,
				type: 'progress'
			};

			if (index === 0) {
				opt.message = opt.message + ' Start adding';
				funs.createInform({
					title: 'Adding',
					message: `${index}/${indexs.length}`,
					progress: progress,
					type: 'progress'
				}, errorData.urlId);
			}

			if (index >= indexs.length) {
				if (errorData.datas.length) {
					funs.updateInform({
						iconUrl: '/imgs/error.png',
						type: 'list',
						title: 'The following contact was not added successfully',
						items: errorData.datas,
					}, errorData.urlId);
				} else {
					setTimeout(() => {
						funs.updateInform({
							iconUrl: '/imgs/yes.png',
							title: 'Successfully',
							message: 'All added successfully',
							type: "basic"
						}, errorData.urlId);
					}, 500)
				}
				return;
			}

			var dataItem = dataList[indexs[index]];

			//把img转成base64
			funs.imgUrlToBase64(dataItem.data.img).then((val) => {
				return addContact({...dataItem.data, img: val})

			}).then((res) => {
				opt.message = opt.message + ' ' + dataItem.data.contact_name + ' ✔';
				funs.updateInform(opt, errorData.urlId)
				dataItem.requestSuccess(res.contact_id);
				this.successSpanListData(dataItem.unique_id,res.contact_id)
			}).catch((res) => {
				if (res.code == 201 || res.code == 202) {
					dataItem.requestSuccess(res.data.contact_id, res.data[0]);
					this.successSpanListData(dataItem.unique_id,res.data.contact_id, res.data[0])
				} else {
					opt.message = opt.message + ' ' + dataItem.data.contact_name + ' ✘';
					funs.updateInform(opt, errorData.urlId)
					errorData.datas.push({title: dataItem.data.contact_name, message: dataItem.data.company})
					dataItem.requestError(res.msg);
					console.log(res);
				}
			}).finally(() => {
				this.addContact(index + 1, indexs, dataList, errorData);
			});

		},
		//只是索引的数据列表
		onlyWhoisDataList(domain) {
			if (!domain) {
				return Promise.resolve([]);
			}
			if (this.dataCenter[domain]) {
				return Promise.resolve(this.dataCenter[domain]);
			}

			return new Promise((resolve, reject) => {
				this.searchSubmit(domain).then((data) => {
					this.$set(this.dataCenter, domain, data);
					resolve(this.dataCenter[domain])
				}).catch(() => {
					resolve([]);
				});
			})
		},

		//自动合并
		autoMerge(DataList) {
			var obj = []
			var reg = (index) => {
				if (index >= DataList.length) {
					if (obj.length) {
						funs.createInform({
							iconUrl: '/imgs/yes.png',
							type: 'list',
							title: 'The following contact has been automatically updated for you',
							items: obj,
						})
					}
					//查找重名的方法
					this.getSomeName(DataList);
					return;
				}
				var dataItem = DataList[index];
				if (dataItem.directUpdate) {
					funs.imgUrlToBase64(dataItem.directUpdate.img).then((val) => {
						if (val) {
							return EditContact({...dataItem.directUpdate, img: val});
						} else {
							return EditContact(dataItem.directUpdate);
						}

					}).then((data) => {

						obj.push({title: dataItem.data.contact_name, message: '✔'});
						dataItem.requestSuccess(dataItem.directUpdate.contact_id, data);
						this.successSpanListData(dataItem.unique_id, dataItem.directUpdate.contact_id, data)
					}).catch((res) => {
						dataItem.requestError(res.msg);
					}).finally(() => {
						reg(index + 1)
					})
				} else {
					reg(index + 1)
				}
			}

			if (DataList.length && DataList.some(v => !!v.directUpdate)) {
				DataList.forEach((v) => {
					if (v.directUpdate) {
						v.requesting()
					}
				});
				reg(0)
			} else {
				this.getSomeName(DataList);
			}

		},


		//获取重名
		getSomeName(dataList) {
			var findContactCecha = funs.cachedPromise(function (name) {
				return findContact(name, 1)
			});

			var res = (index) => {
				var itemData = dataList[index];
				if (itemData && !itemData.contact_id) {
					var someData = [];
					findContactCecha(itemData.data.contact_name).then((someNames) => {
						someData = someNames;
					}).catch((res) => {
						console.log('获取同名catch', res)
					}).finally(() => {

						itemData.initSomeName(someData);

						if (someData.length && itemData.data.img) {
							//有同名并且数据里有图片，作图片对比
							this.faceContrast(itemData)
						}

						res(index + 1);
					});
				}
			}
			res(0);
		},

		//人脸对比
		faceContrast(itemData){
			var imgBase64 = '', file_url = '', confidence = 0, face_token;
			//人脸对比
			funs.imgUrlToBase64(itemData.data.img).then((val) => {
				if (val) {
					imgBase64 = val
					return faceplusMatch({contact_name: itemData.data.contact_name, file: imgBase64})
				} else return Promise.reject([]);

			}).then((data) => {
				console.log(data);
				if (data && data.matchs && data.matchs[0]) {

					confidence = data.matchs[0].confidence; //相似度
					file_url = data.matchs[0].file_url;		//相似的img_url
					face_token = data.matchs[0].face_token; //相似的图片唯一id

					if (confidence >= 90) {
						//对比超过90时，自动合并
						itemData.getServerData(data.contact_info);
					} else {
						//第二个参数为true,不添加id
						itemData.getServerData(data.contact_info, true);
					}

					var boolArray = itemData.contactIsUpdate();

					if (boolArray) {
						itemData.directUpdate = itemData.getDirectUpdate(boolArray);
						console.log(itemData.directUpdate);
					}

					//有合并内容
					if (itemData.directUpdate) {

						//相似度大于80自动合并
						if (data.matchs[0].confidence >= 90) {
							itemData.requesting();
							if (imgBase64 && itemData.directUpdate.img) {
								return EditContactCache({...itemData.directUpdate, img: imgBase64});
							} else {
								return EditContactCache(itemData.directUpdate);
							}

						} else {

							//不超过时，提示
							console.log('低于90', data.matchs[0].confidence);
							var informId = 'face-' + face_token;
							funs.imgUrlToBase64(file_url).then((val) => {

								var base = {
									type: 'image',
									iconUrl: imgBase64,
									imageUrl: val,
									title: 'Is the same person on the left and right? - FMS Ext',
									message: 'Contacts: ' + itemData.data.contact_name,
									contextMessage: 'confidence:' + confidence + '%',
									buttons: [{title: 'YES', iconUrl: '/imgs/yes.png'}, {
										title: 'NO',
										iconUrl: '/imgs/error.png'
									}],
								}

								funs.createInform(base, informId);

							});
							chrome.notifications.onButtonClicked.addListener(function (id, index) {
								if (id !== informId) {
									return
								}
								if (index === 0) {
									itemData.requesting();
									var pro
									if (imgBase64 && itemData.directUpdate.img) {
										pro = EditContactCache({...itemData.directUpdate, img: imgBase64});
									} else {
										pro = EditContactCache(itemData.directUpdate);
									}

									pro.then((data) => {
										itemData.requestSuccess(itemData.directUpdate.contact_id, data);
										this.successSpanListData(itemData.unique_id, itemData.directUpdate.contact_id, data)
										funs.createInform({
											iconUrl: '/imgs/yes.png',
											title: 'Merger success',
											message: itemData.data.contact_name + ' ✔'
										}, informId)
									}).catch((err) => {
										funs.createInform({
											iconUrl: '/imgs/error.png',
											title: itemData.data.contact_name + ' Merger failure',
											message: err.msg
										}, informId)
									});

								} else {
									// 过滤掉
									faceplusSetNoFile({
										contact_id: data.contact_info.id,
										md5_code: data.md5_code
									}).then(() => {
										console.log('设置图片与指定联系人无关成功')
									})
								}

								//关闭弹窗
								chrome.notifications.clear(informId);
							});

							return Promise.reject('低于80，提前结束')
						}
					} else {
						itemData.getServerData(data.contact_info, true);
						return Promise.reject('无合并内容，无法自动合并')
					}

				} else {
					return Promise.reject('没有返回对比数据，提前结束')
				}

				console.log('对比结果', data);

			}).then((data) => {

				itemData.requestSuccess(itemData.directUpdate.contact_id, data);
				this.successSpanListData(itemData.unique_id,itemData.directUpdate.contact_id, data)
				var informId = 'face-' + face_token;
				funs.imgUrlToBase64(file_url).then((val) => {

					var base = {
						type: 'image',
						iconUrl: imgBase64,
						imageUrl: '',
						title: 'Face similarity exceeds 90% automatically merges',
						message: 'Contacts: ' + itemData.data.contact_name,
						contextMessage: 'confidence: ' + confidence + '%',
					}

					if (val) {
						base.imageUrl = val;
						funs.createInform(base, informId);
					} else {
						base.type = 'basic'
						delete base.imageUrl;
						funs.createInform(base, informId);
					}

				});

			}).catch((res) => {
				console.log('对比错误', res);
				itemData.requestError()
			});
		},
		successSpanListData(unique_id,contact_id,serverData=null){
			for(var i in this.dataCenter){
				this.dataCenter[i].forEach(item=>{
					console.log(item.unique_id)
					if(item.unique_id == unique_id){
						item.requestSuccess(contact_id,serverData)
					}
				})
			}
		}
	}
});


// 监听来自content-script的消息
// 获取首页发来的 dataList 数据
chrome.runtime.onMessage.addListener(function (request, sender, callback) {

	//需要满足条件
	if (request.type == 'get-content-datalist') {
		console.log(request, sender)
		console.log('收到来自content-script采集数据');
		var dataList = request.dataList.map((item) => {
			return new DataItem().init(item);
		});

		//获取当前页面whois信息
		window.vueApp.searchSubmit(funs.getDomain(sender.url)).then((data) => {
			if (data && data.length && data[0].contact_id) {
				dataList = [...dataList, ...data];
			} else {
				dataList = [...data, ...dataList];
			}

			window.vueApp.$set(window.vueApp.dataCenter, request.urlId, dataList);

			//自动合并方法
			window.vueApp.autoMerge(window.vueApp.dataCenter[request.urlId]);

		});

	} else if (request.type == 'del-content-datalist') {

		window.vueApp.$delete(window.vueApp.dataCenter, request.urlId);

	}

});
