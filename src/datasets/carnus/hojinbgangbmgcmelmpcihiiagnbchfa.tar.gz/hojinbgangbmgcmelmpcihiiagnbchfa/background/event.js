console.log('我是background.js');

//设置badge的背景颜色
chrome.browserAction.setBadgeBackgroundColor({color: [192, 22, 57, 255]});

//数据容器

window.nums = {};
//当前所在页面的唯一ID
window.currentUniqueId = '';

//event
// 监听来自content-script的消息
chrome.runtime.onMessage.addListener(function (request, sender, callback) {

	if (request.type !== 'set-datalist-amount') return;

	console.log('content修改Badge操作：');
	var num = request.num;
	var uniqueId = request.uniqueId;

	// 把数据存入容器
	console.log('num', num)
	window.nums[uniqueId] = String(num);
	console.log(window.currentUniqueId, uniqueId)

	if (window.currentUniqueId === uniqueId) {
		//修改图标上的badge
		chrome.browserAction.setBadgeText({text: window.nums[uniqueId]});
	}
});

//event
//监听活动标签
chrome.tabs.onActivated.addListener(function (e) {
	chrome.tabs.get(e.tabId, function (c) {


		var uniqueId = funs.pageUniqueId(c.url)
		//该页面是否有数据
		if (window.nums[uniqueId]) {
			chrome.browserAction.setBadgeText({text: String(window.nums[uniqueId])});
		} else {
			chrome.browserAction.setBadgeText({text: ''});
		}
	})
})

//event
//页面被更新时，改变当前的url
chrome.tabs.onUpdated.addListener(function (e, changeInfo, tab) {

	if (tab.status === "complete") {
		console.log('页面被更新时，改变当前的url', tab);
		funs.addHistorys({url: tab.url, title: tab.title, icon: tab.favIconUrl || ''})
	}
	var uniqueId = funs.pageUniqueId(tab.url)
	window.currentUniqueId = funs.pageUniqueId(tab.url);
	//该页面是否有数据
	if (window.nums[uniqueId]) {
		chrome.browserAction.setBadgeText({text: String(window.nums[uniqueId])});
	} else {
		chrome.browserAction.setBadgeText({text: ''});
	}
});

chrome.runtime.onConnect.addListener((prot) => {
	if (prot.name === 'imgUrlToBase64') {
		prot.onMessage.addListener((url) => {
			funs.imgUrlToBase64(url).then((dataURL) => {
				prot.postMessage(dataURL);
			})
		})
	} else if (prot.name === 'imgUrlToBase64Md5') {
		prot.onMessage.addListener((url) => {
			funs.imgUrlToBase64Md5(url).then((dataURL) => {
				prot.postMessage(dataURL);
			})
		})
	} else if(prot.name === 'printscreen'){
		prot.onMessage.addListener(() => {
			chrome.tabs.captureVisibleTab(uri => {
				if (chrome.runtime.lastError)
					console.log(`Error getting screenshot`,chrome.runtime.lastError);
				else
					prot.postMessage(uri);
			});
		})

	}
})


