
//rocketreach_contacts所需的网络请求
chrome.webRequest.onBeforeRequest.addListener(function (e) {

	var fms = funs.getParam('fms', e.url);

	console.log('rocketreach_contacts所需的网络请求', e.url)

	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-rocketreach-data-contacts', url: e.url});
	}

}, {urls: ["https://rocketreach.co/v1/profileList/allProfiles?*", "https://rocketreach.co/v1/profileList/*/profiles*limit=20*"]});

//rocketreach_search所需的网络请求
chrome.webRequest.onBeforeRequest.addListener(function (e) {

	var fms = funs.getParam('fms', e.url);
	console.log('rocketreach_search所需的网络请求', e.url)


	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-rocketreach-data-search', url: e.url});
	}

}, {urls: ["https://rocketreach.co/v2/services/customSearch"]});

//facebook所需的网络请求，个人首页
chrome.webRequest.onCompleted.addListener(function (e) {
	var fms = funs.getParam('fms', e.url);

	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-facebook-data-contact', url: e.url});
	}

}, {urls: ["*://*.facebook.com/profile.php?id=*","*://*.facebook.com/ajax/browse/null_state.php*","*://*.facebook.com/*?dpr=1&ajaxpipe=1&ajaxpipe_token=*"]});


//linkedin 首页
var preve = {
	tabId:0,
	timeStamp:0,
	urlId:'',
	type:'',
}
chrome.webRequest.onCompleted.addListener(function (e) {

	var urlId = ''
	if(e.type==='xmlhttprequest'){
		var reg1 = /profiles\/(.+?)\/promoVisibility/.exec(e.url);
		urlId = reg1[1];
	}else{
		var reg2 = /linkedin.com\/in\/(.+?)\//.exec(e.url);
		urlId = reg2[1];
	}

	if(preve.tabId ===e.tabId && preve.type==='main_frame' && e.type==='xmlhttprequest' && urlId===preve.urlId){
		console.log('重复请求')
		return
	}

	preve = {
		tabId:e.tabId,
		timeStamp:e.timeStamp,
		urlId:urlId,
		type:e.type,
	}

	var fms = funs.getParam('fms', e.url);

	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-data-contact', url: e.url});
	}

}, {urls: ['*://*.linkedin.com/voyager/api/identity/profiles/*/promoVisibility?*','*://*.linkedin.com/in/*/*']});

//linkedin 搜索 所需网络请求
chrome.webRequest.onCompleted.addListener(function (e) {
	var fms = funs.getParam('fms', e.url);

	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-search-data-contact', url: e.url});
	}

}, {urls: ["*://*.linkedin.com/voyager/api/search/cluster?*","*://*.linkedin.com/voyager/api/search/blended?*"]});

//linkedin sales/people 所需网络请求
chrome.webRequest.onCompleted.addListener(function (e) {

	if (e.type !== 'main_frame') {
		return
	}
	var fms = funs.getParam('fms', e.url);
	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-sales-profile-contact', url: e.url});
	}

}, {urls: ["*://*.linkedin.com/sales/people/*,*"]});

//linkedin sales/profile 所需网络请求
chrome.webRequest.onCompleted.addListener(function (e) {

	if (e.type !== 'main_frame') {
		return
	}
	var fms = funs.getParam('fms', e.url);
	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-sales-profile-contact', url: e.url});
	}

}, {urls: ["*://*.linkedin.com/sales/profile*,*"]});


//linkedin sales/search 所需网络请求1
chrome.webRequest.onCompleted.addListener(function (e) {
	console.log('来这里看看')
	var fms = funs.getParam('fms', e.url);
	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-sales-search-contact', url: e.url});
	}

}, {urls: ["*://*.linkedin.com/sales-api/salesApiPeopleSearch?*"]});

//linkedin sales/search 所需网络请求,获取html内容
chrome.webRequest.onCompleted.addListener(function (e) {

	var fms = funs.getParam('fms', e.url);
	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-sales-search-contact-html', url: e.url});
	}

}, {urls: ["*://*.linkedin.com/sales/search/people?*"]});

//linkedin /mynetwork 所需网络请求
chrome.webRequest.onCompleted.addListener(function (e) {

	var fms = funs.getParam('fms', e.url);
	var url = e.url
	if (e.url.indexOf('start=0') >= 0) {
		url = e.url.replace('count=10', 'count=13');
	} else if (e.url.indexOf('start=3') >= 0) {
		url = e.url.replace('count=10', 'count=13');
		url = url.replace('start=3', 'start=0');
	}

	if (!fms && e.tabId > 0) {
		chrome.tabs.sendMessage(e.tabId, {type: 'get-linkedin-mynetwork-contact', url: url});
	}

}, {urls: ["*://*.linkedin.com/voyager/api/relationships/peopleYouMayKnow?*"]});

//twitter所需的网络请求
chrome.webRequest.onCompleted.addListener(function (e) {
	var fms = funs.getParam('fms', e.url);

	var reg = [/\.js/, /\/i\//, /\/who_to_follow\//, /\/hashtag\//, /\/search\?/, /\/account\//, /\/na\//,
		/\.html/, /\/settings\//, /\/company\//, /\/privacy/, /\/help\//];

	var bool = reg.some(function (val) {
		return val.test(e.url)
	});

	if (!fms && e.tabId > 0 && !bool && e.url !== 'https://twitter.com/') {
		console.log('通过的url', e.url);
		console.log(e);
		var re = function (e) {
			var arg = arguments
			chrome.tabs.sendMessage(e.tabId, {type: 'get-twitter-data', url: e.url}, function () {
				if (chrome.runtime.lastError && chrome.runtime.lastError.message == 'Could not establish connection. Receiving end does not exist.') {
					setTimeout(function () {
						arg.callee(e)
					}, 1000)
				}

			});
		}

		re(e)

	}

}, {urls: ["https://www.twitter.com/*", "https://twitter.com/*"]});

// setInterval(function(){
// 	console.log('lastError',chrome.runtime.lastError)
// },1000)

//linkedin 登录成功处理
chrome.webRequest.onCompleted.addListener(function (e) {
	console.log('facebook页面更新')

	chrome.cookies.get({url: 'https://www.linkedin.com', name: 'JSESSIONID'}, function (res) {

		funs.setLinkedInToken(res.value.replace(/"/g, '')).then(function () {
			chrome.tabs.query({}, function (e) {
				e.forEach(function (tab) {
					console.log(tab.url)
					if (funs.isLinkedin(tab.url) || /www\.google\.\w+(\.\w+)?\/search/.test(tab.url)) {
						console.log('刷新: ' + tab.url)
						chrome.tabs.reload(tab.id)
					}
				})
			})
		});
	})
}, {urls: ["*://www.linkedin.com/uas/login-submit"]});


chrome.contextMenus.create({
		type: 'normal',
		title: 'up to FMS',
		contexts: ['image'],
		onclick: function (e) {
			console.log(e);
			funs.getCurrentTab(function (tab) {
				chrome.tabs.sendMessage(tab.id, {type: 'menu-select-img', content: e.srcUrl}, function () {
				});
			})
		}
	},
	function (e) {

	});


// chrome.contextMenus.create({
// 	type: 'normal',
// 	title: 'up to FMS',
// 	contexts: ['selection'],
// 	onclick: function (e) {
// 		console.log(e)
// 		funs.getCurrentTab(function (tab) {
// 			chrome.tabs.sendMessage(tab.id, {type: 'menu-select-text', content: e.selectionText}, function () {
// 			});
// 		})
// 	}
// }, function (e) {
// 	console.log(e);
// });

