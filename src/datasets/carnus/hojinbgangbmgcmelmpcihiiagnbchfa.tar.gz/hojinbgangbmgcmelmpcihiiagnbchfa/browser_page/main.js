import Vue from 'vue';
import store from '../vue-common/store.js'
import './content_script/index'

//国际化
import i18n from '../vue-common/i18n/index'
import App from './App.vue'

import IciUi from 'ici-ui'

Vue.use(IciUi);

import fmsInputGroup from './components/fms-input-group.vue'
Vue.component('fms-input-group', fmsInputGroup);




//fmsButton
import fmsButton from './components/fms-button.vue'
Vue.component('fms-button', fmsButton);

//注册过滤器
Vue.filter('typeToIcon', funs.typeToIcon);
Vue.filter('typeToColor', funs.typeToColor);
Vue.filter('shortUrl', funs.shortUrl);

var fmsDom = document.createElement('div');
fmsDom.setAttribute('id', 'fms-inject');

var vm = new Vue({
	store,
	i18n,
	el: fmsDom,
	render: h => h(App),
});
store.state.appDom = vm.$el
document.addEventListener('DOMContentLoaded', () => {
	document.body.appendChild(vm.$el)
});


chrome.runtime.onMessage.addListener((res) => {
	if (res.type == 'menu-select-img' || res.type == 'menu-select-text') {
		//嵌入的元素有可能被当前网页删除
		//如果元素不存在，重新嵌入
		if (!document.getElementById('fms-inject')) {
			document.body.appendChild(vm.$el)
		}

		store.commit('openInject', res)
	}
});