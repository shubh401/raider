
//注入内容状态管理
export default {
	state: {
		injectCustom: {
			show: false,//是否要显示注入内容
			type: '', //显示类型 menu-select-img右键选择图片
			content: '',
			callback: null,
		},
		//采集进度
		progress: {
			show: false,
			total: 0,
			current: 0,
			message: ''
		},
		//背景音乐对象
		bgmusic:null,
		googleMap:false, //公司数据
		appDom:null,
	},
	mutations: {
		hasGoogleMap(state){
			state.googleMap = true;
		},
		//初始化bgmusic
		initbgMusic(state,obj){
			state.bgmusic = obj;
		},

		//播放bgmusic
		playbg(state){
			if(state.bgmusic){
				state.bgmusic.play()
			}
		},

		//关闭注入
		closeInject(state) {
			state.injectCustom.show = false;
			state.injectCustom.type = '';
			state.injectCustom.content = '';
			state.injectCustom.callback = null;
		},

		openInject(state, obj) {
			state.injectCustom.show = false;
			setTimeout(()=>{
				state.injectCustom.show = true;
			},50)
			state.injectCustom.type = obj ? obj.type : '';
			state.injectCustom.content = obj ? obj.content : '';
		},

		openLogin(state, cb) {
			state.injectCustom.show = true;
			state.injectCustom.callback = cb;
		},

		//开始
		progressStart(state, total) {
			state.progress.show = true;
			state.progress.current = 0;
			if (typeof total === 'number') {
				state.progress.total = total + 2;
				state.progress.message = '';
			} else if (typeof total === "object") {
				state.progress.total = total.total + 2;
				state.progress.message = total.message
			}


			//在采集完成之后，还需要对数据的图片转换md5和与服务器数据对比，所以对total添加两项；
		},

		//下一个进度
		progressNext(state) {
			state.progress.current++
		},

		progressError(state) {
			state.progress.total = -1
		}
	}
}