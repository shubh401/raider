import {urlsToContacts} from "./linkedin";
import store from "../../../vue-common/store";
import * as Cookies from "js-cookie";


export function linkedinSalesProfile(url) {

	funs.createVersion()
	var ajaxToken = Cookies.get('JSESSIONID');
	if (ajaxToken) {
		funs.setLinkedInToken(ajaxToken);
	}

	return new Promise((resolve, reject) => {
		var connectionUrl = '', urlIds = [], salesContact = [];

		//获取sales 有用信息
		store.commit('progressStart', {total: 100, message: 'Analyzing'});
		salesGetContact(url, ajaxToken, funs.getVersion()).then((data) => {
			//data = {urlId:'',connectionsUrl:''}

			// 2) 获取会员还看了，urlids
			console.log('seles 第一步', data);
			connectionUrl = data.connectionsUrl;

			if (data.urlId) {
				urlIds.push(data.urlId);
			} else {
				if (!funs.isEmptyObject(data.data)) {
					salesContact.push(data.data);
				}
			}
			return getConnectionsUrlIdOrInfo(data.pavUrl, ajaxToken, funs.getVersion()); //有可能返回不是ID，可能就是contactInfo

		}).then(function (data) {

			data.forEach((val) => {
				if (typeof val === 'string') {
					urlIds.push(val);
				} else if (typeof val === "object" && !funs.isEmptyObject(val)) {
					salesContact.push(val)
				}
			});

			console.log('seles 第二步', data);
			return getConnectionsUrlIdOrInfo(connectionUrl, ajaxToken, funs.getVersion())
		}).then(function (data) {

			data.forEach((val) => {
				if (typeof val === 'string') {
					urlIds.push(val);
				} else if (typeof val === "object" && !funs.isEmptyObject(val)) {
					salesContact.push(data.data);
				}
			})

			console.log('seles 第三步', data);
			console.log('最后数据', urlIds, salesContact)
			store.commit('progressStart', {total: urlIds.length, message: 'Get in'});
			// progress.setTotal(ids.length);

			//通知后台，一共有几个用户
			funs.contentSendMessage(urlIds.length + salesContact.length);

			//跟据urlid查询用户内容
			return urlsToContacts(urlIds, ajaxToken, funs.getVersion());

		}).then((data) => {
			resolve([...data, ...salesContact]);
		}).catch((err) => {
			store.commit('progressError');
			return Promise.reject(err)
		})
	})
}

function pubUrlTOInUrl(pubUrl, ajaxToken) {
	if (!pubUrl) {
		return Promise.reject('没传pubUrl')
	}
	console.log('pubUrl', pubUrl)
	pubUrl = pubUrl.replace(/https?:\/\/(.*?)\.linkedin/, 'https://www.linkedin');
	return new Promise((resolve, reject) => {
		funs.getTemp(pubUrl, 'puburl').then((data) => {
			if (data) {
				console.log('pubUrlTOInUrl有缓存呢')
				return resolve(data)
			}

			var time = funs.scopeRandom(200, 500);
			setTimeout(() => {
				$.ajax({
					type: 'get',
					url: pubUrl,
					timeout: 12000,
					headers: {
						'csrf-token': ajaxToken,
						"x-restli-protocol-version": "2.0.0"
					},
					success: function (data) {
						var reg = /\/voyager\/api\/identity\/profiles\/(.*?)\/privacySettings/.exec(data);
						if (reg && reg[1]) {
							return resolve(reg[1]);
							if (reg[1]) {
								funs.saveTemp(pubUrl, 'puburl', reg[1]);
							}
						} else {
							return reject('')
						}

					},
					error(e) {
						console.log('linkedinSalesProfile error', e)
						return reject('');

					}
				})
			}, time)

		})
	})

}

//获取contact 个人首页地址
/*
* @param url {string} contact seles.people地址
* @param ajacToken {string} 请求用到的token
* @promise {urlId:urlId,connectionsUrl:url} urlId:个人首页地址ID，connectionsUrl常联系请求地址
* */
function salesGetContact_back(url, ajaxToken, vs) {

	url = url.replace('http://', 'https://');

	return new Promise((resolve, reject) => {
		funs.getTemp(url, 'salesUrlId', 24).then((data) => {
			if (vs !== funs.getVersion()) return
			if (data) {
				console.log('salesGetContact使用本地')
				return resolve(data);
			}

			var time = funs.scopeRandom(300, 1000);
			console.log('salesGetContact使用在线')
			setTimeout(() => {
				$.ajax({
					type: 'get',
					url: url,
					timeout: 12000,
					data: {fms: 1},
					headers: {
						'csrf-token': ajaxToken,
						"x-restli-protocol-version": "2.0.0"
					},
					success: function (data) {
							console.log('data111',data)
						if (vs !== funs.getVersion()) return
						data = data.replace(/\u2028/g, "").replace(/\u2029/g, "");

						var reg = /<code id="streamed-content-content"><!--(.*?)--><\/code>/.exec(data);

						var datas = JSON.parse(reg[1])
						console.log('salesGetContact使用在线拿到数据', datas);
						var profile = datas.profile;

						//获取connections 请求地址
						var connectionsUrl = `https://www.linkedin.com/sales/profile/${profile.memberId},${profile.authToken},${profile.authType}/connections?_=${Date.now()}`
						var pavUrl = `https://www.linkedin.com/sales/profile/${profile.memberId},${profile.authToken},${profile.authType}/pav?_=${Date.now()}`
						//是否有个人首页地址
						if (profile.publicLink) {

							pubUrlTOInUrl(profile.publicLink).then((urlId) => {

								var data = {urlId: urlId, connectionsUrl: connectionsUrl, pavUrl: pavUrl};
								if (urlId && connectionsUrl) {
									funs.saveTemp(url, 'salesUrlId', data);
								}
								if (vs !== funs.getVersion()) return
								return resolve(data);

							}).catch(() => {


								//没有个人首页时，拿当前的数据
								var contact = salesCurrent(datas);
								var d = {data: contact, connectionsUrl: connectionsUrl, pavUrl: pavUrl};
								if (d.data.contact_name) {
									funs.saveTemp(url, 'salesUrlId', d);
								}

								if (vs !== funs.getVersion()) return
								return resolve(data);

							});
						} else {
							//没有个人首页时，拿当前的数据
							var contact = salesCurrent(datas);
							var d = {data: contact, connectionsUrl: connectionsUrl, pavUrl: pavUrl};

							if (d.data.contact_name) {
								funs.saveTemp(url, 'salesUrlId', d);
							}
							if (vs !== funs.getVersion()) return

							return resolve(d);


						}
					},
					error(e) {
						if (vs !== funs.getVersion()) return;
						console.log('salesGetContact使用在线错误', e)
						if (e.status === 999 || e.status === 401) {

							return reject('linkedin not log in')


						} else {

							return reject(e.responseText)

						}
					}
				})
			}, time)

		})
	})

}

//获取contact 个人首页地址
/*
* @param url {string} contact seles.people地址
* @param ajacToken {string} 请求用到的token
* @promise {urlId:urlId,connectionsUrl:url} urlId:个人首页地址ID，connectionsUrl常联系请求地址
* */
function salesGetContact(url, ajaxToken, vs) {

	url = url.replace('http://', 'https://');

	return new Promise((resolve, reject) => {
		funs.getTemp(url, 'salesUrlId', 24).then((data) => {
			if (vs !== funs.getVersion()) return
			if (data) {
				console.log('salesGetContact使用本地')
				return resolve(data);
			}

			var time = funs.scopeRandom(300, 1000);
			console.log('salesGetContact使用在线')
			setTimeout(() => {
				$.ajax({
					type: 'get',
					url: url,
					timeout: 12000,
					data: {fms: 1},
					headers: {
						'csrf-token': ajaxToken,
						"x-restli-protocol-version": "2.0.0"
					},
					success: function (data) {

						if (vs !== funs.getVersion()) return

						var urlId;
						var id = /https?:\/\/www\.linkedin\.com\/in\/(.+?)&quot;/.exec(data);
							console.log(id)
						if(id){
							urlId = id[1]
						}else{
							return
						}

						//获取connections 请求地址
						var connectionsUrl = ''
						var pavUrl = ''
						//是否有个人首页地址

						var data = {urlId: urlId, connectionsUrl: connectionsUrl, pavUrl: pavUrl};
						return resolve(data);
					},
					error(e) {
						if (vs !== funs.getVersion()) return;
						console.log('salesGetContact使用在线错误', e)
						if (e.status === 999 || e.status === 401) {
							return reject('linkedin not log in')

						} else {
							return reject(e.responseText)

						}
					}
				})
			}, time)

		})
	})

}

function salesCurrent(datas) {

	var work = {}
	if (datas.currentPosition && datas.currentPosition.position) {
		var pos = datas.currentPosition.position;
		work.company = pos.companyName;
		work.title = pos.title;
		work.location = pos.location;
	}

	// console.log(JSON.stringify(datas));
	var profile = datas.profile;

	var signature = profile.headline
	var company = work.company, title = work.title;

	if (signature) {
		var label = funs.labelTreatment(signature);
		company = label[0] ? funs.trim(label[0].replace(work.title, ''), ' ,的') : work.company;
		title = label[1] ? funs.trim(label[1].replace(work.company, ''), ',的') : work.title;
	}

	var contactInfo = {
		img: datas.profileImageUris.imageUri,
		contact_name: funs.trim(profile.fullName),
		title: funs.trim(title),
		company: funs.trim(company),
		first_name: funs.trim(profile.firstName),
		last_name: funs.trim(profile.lastName),
		country: funs.trim(work.company) || '',
		city: funs.trim(work.location) || funs.trim(profile.location),
		plugin_id: '',
		contact: []
	};
	if (!contactInfo.contact_name) {
		return {}
	}

	//email
	if (profile.contactInfo && profile.contactInfo.emails && profile.contactInfo.emails.length) {
		profile.contactInfo.emails.forEach((val) => {
			if (!contactInfo.plugin_id) {
				contactInfo.plugin_id = val
			}
			contactInfo.contact.push({
				type: 'Email',
				info: val
			})
		})
	}

	//phones
	if (profile.contactInfo && profile.contactInfo.phones && profile.contactInfo.phones.length) {
		profile.contactInfo.phones.forEach((val) => {

			if (/(\d+) ?\/ ?(\d+)$/.test(val)) {

				//分解 85589777097 / 85599696769 格式的电话
				var reg = /(\d+) ?\/ ?(\d+)$/.exec(val)
				contactInfo.contact.push({type: 'Phone', info: reg[1]})
				contactInfo.contact.push({type: 'Phone', info: reg[2]})
				if (!contactInfo.plugin_id) {
					contactInfo.plugin_id = reg[1]
				}
			} else {
				contactInfo.contact.push({type: 'Phone', info: val})
				if (!contactInfo.plugin_id) {
					contactInfo.plugin_id = val
				}
			}

		})

	}

	return contactInfo
}

//获取用户常联系的urlId
function getConnectionsUrlIdOrInfo(url, ajaxToken, vs) {

	if (!url) {
		return Promise.resolve([])
	}
	return new Promise((resolve, reject) => {
		$.ajax({
			type: 'get',
			url: url,
			data: {fms: 1},
			headers: {
				'csrf-token': ajaxToken,
				"x-restli-protocol-version": "2.0.0"
			},
			success: function (data) {
				if (vs !== funs.getVersion()) return
				if (data.connections && data.connections.members && data.connections.members.length) {
					var members = data.connections.members
					var urlIds = [];
					console.log('members', members)

					reg(0, members);
				} else if (data.profiles && data.profiles.length) {
					var profiles = data.profiles
					var urlIds = [];

					reg(0, profiles);
				} else {
					resolve([])
				}

				function reg(index, members) {
					if (index === members.length) {
						return resolve(urlIds)
					}
					salesGetContact(members[index].profileUrl, ajaxToken,funs.getVersion()).then((data) => {
						if (vs !== funs.getVersion()) return

						if (data.urlId) {
							urlIds.push(data.urlId);
						} else {
							urlIds.push(data.data);
						}

					}).catch((err) => {
						if (vs !== funs.getVersion()) return
						console.log('salesGetContact Error', err)
					}).finally(() => {
						if (vs !== funs.getVersion()) return
						store.commit('progressNext');
						reg(index + 1, members)

					})
				}

			},
			error(e) {
				if (vs !== funs.getVersion()) return
				if (e.status === 999 || e.status === 401) {
					return reject('linkedin not log in')
				} else {
					reject(e.responseText)
				}

			}
		})
	})

}
export function linkedinSalesSearchHtml() {
	return new Promise((resolve, reject) => {

		document.addEventListener('DOMContentLoaded', searchHtml)

		function searchHtml(e){
			document.removeEventListener('DOMContentLoaded',searchHtml);
			var codes = document.querySelectorAll('code');
			var requestUrl = ''
			codes.forEach((v)=>{
				if(v.innerText.indexOf('{"request":"/sales-api/salesApiPeopleSearch?')>-1){
					requestUrl = JSON.parse(v.innerText)
				}
			})
			if(requestUrl && requestUrl.request){
				linkedinSalesSearch(requestUrl.request).then(resolve).catch(reject)
			}else{
				resolve([])
			}
		}
	})

}
export function linkedinSalesSearch(url) {
	console.log('到这了没')
	funs.createVersion()
	var ajaxToken = Cookies.get('JSESSIONID');
	if (ajaxToken) {
		funs.setLinkedInToken(ajaxToken);
	}

	var vs = funs.getVersion();
	return new Promise((resolve, reject) => {
		store.commit('progressStart', {total: 100, message: 'Analyzing'});
		var salesUrls = [], urlIds = [], salesContact = [];
		$.ajax({
			type: 'get',
			url: url,
			data: {fms: 1},
			headers: {
				'csrf-token': ajaxToken,
				'x-restli-protocol-version': '2.0.0',
			},
			success: one,
			error(e) {
				if (e.status === 999 || e.status === 401) {
					return reject('linkedin not log in')
				} else {
					reject(e.responseText);
				}
			}
		})

		function one(data) {

			if(vs !== funs.getVersion()) return;
			if (data && data.elements) {
				data.elements.forEach((val) => {
					if (val.entityUrn) {
						var reg = /urn:li:fs_salesProfile:\((.*?)\)/;
						if(reg.test(val.entityUrn)){
							var ex = reg.exec(val.entityUrn)[1]
							salesUrls.push(`https://www.linkedin.com/sales/people/${ex}`)
						}
					}
				});
				if (salesUrls) {
					two(0, salesUrls)
			}
			} else {
				//什么都没有
				console.log('什么都没有')
				resolve([])
			}
		}

		function two(index, salesUrls) {

			if (index === salesUrls.length) {
				three()
				return
			}
			salesGetContact(salesUrls[index], ajaxToken,vs).then((data) => {

				if(vs !== funs.getVersion()) return;
				if (data.urlId) {
					urlIds.push(data.urlId);
				} else {
					if (!funs.isEmptyObject(data.data)) {
						salesContact.push(data.data);
					}
				}

			}).catch((err) => {
				if(vs !== funs.getVersion()) return;
				console.log('linkedinSalesSearch Error', err)
			}).finally(() => {
				store.commit('progressNext');
				two(index + 1, salesUrls)
			})
		}

		function three() {

			store.commit('progressStart', {total: urlIds.length, message: 'Get in'});

			//通知后台，一共有几个用户
			funs.contentSendMessage(urlIds.length + salesContact.length);

			//跟据urlid查询用户内容
			urlsToContacts(urlIds, ajaxToken, vs).then((data) => {
				resolve([...salesContact, ...data])
			}).catch((err) => {
				store.commit('progressError');
				return Promise.reject(err)
			})
		}

	})

}
