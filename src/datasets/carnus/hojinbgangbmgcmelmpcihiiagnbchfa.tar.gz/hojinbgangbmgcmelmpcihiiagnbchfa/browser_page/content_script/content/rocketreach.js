import * as Cookies from 'js-cookie'
import store from '../../../vue-common/store.js';
/*
* 搜索联系人
* @param {string} queryTerms 搜索参数
* @param {number} startNumber 从第几条开始查看
* */
export function contacts(url) {
	var CSRFToken = Cookies.get('validation_token');
	store.commit('progressStart',1)
	return new Promise(function (resolve, reject) {
		$.ajax({
			type: 'get',
			url: url,
			data: {fms: 1},
			headers: {
				'X-CSRFToken': CSRFToken,
				'accept': 'application/json, text/plain, */*',
				'X-RR-For': '46d5323b36b523ec9ccb4901b843102b'
			},
			success: function (data) {
				if (data.records && data.records.length > 0) {
					var data = data.records.map(function (val) {
						var img = /ZqA5dNniI6Y6T-xgofmzKg02be8j/.test(val.profile_pic) ? '' : val.profile_pic;
						var contact_name = val.name;
						var company = val.current_employer;
						var title = val.current_title;
						var city = val.city ? val.city : val.location;
						var contact = []

						if (val.linkedin_url) {
							contact.push({
								type: 'Linkedin',
								info: 'https://www.linkedin.com/in/' + funs.getLinkedinUrlId(val.linkedin_url) + '/'
							})
						}

						if (val.links.facebook) {
							contact.push({
								type: 'Facebook',
								info: val.links.facebook
							})
						}

						if (val.links.twitter) {
							contact.push({
								type: 'Twitter',
								info: val.links.twitter
							})
						}
						if (val.verified_emails && val.verified_emails.length) {
							val.verified_emails.forEach(function (v) {
								contact.push({
									type: 'Email',
									info: v.email
								})
							})
						}
						if(val.phones && val.phones.length){
							val.phones.forEach(function (v) {
								contact.push({
									type: 'Phone',
									info: v
								})
							})
						}

						return {
							img: img,
							contact_name: contact_name,
							company: company,
							title: title,
							plugin_id: 'linkedin-' + funs.getLinkedinUrlId(val.linkedin_url),
							city: city,
							contact: contact
						}
					})
					store.commit('progressNext')
					resolve(data)
					//content-script主动发消息给后台
					funs.contentSendMessage(data.length)
				}
			},

			error: function () {
				reject('获取个人信息失败');
			}
		})

	})
}

/*
* 搜索联系人
* @param {string} queryTerms 搜索参数
* @param {number} startNumber 从第几条开始查看
* */
export function search(url) {
	var CSRFToken = Cookies.get('validation_token');
	var href = location.href;
	var mode = funs.getParam('mode');
	var start = funs.getParam('start');
	var pageSize = funs.getParam('page_size');
	var terms = funs.getRocketReachTags();

	return new Promise(function (resolve, reject) {
		store.commit('progressStart',1)
		$.ajax({
			type: 'POST',
			url: 'https://rocketreach.co/v2/services/customSearch?fms=1',
			data: JSON.stringify({mode:mode,pageSize:pageSize,start:start,terms:terms}),
			dataType:"json",
			contentType: 'application/json;charset=UTF-8',
			headers: {
				'X-CSRFToken': CSRFToken,
				'accept': 'application/json, text/plain, */*',
				'X-RR-For': '46d5323b36b523ec9ccb4901b843102b'
			},
			success: function (data) {

				if (data.profiles && data.profiles.length > 0) {
					console.log(data.profiles)
					var data = data.profiles.map(function (val) {
						var img = /ZqA5dNniI6Y6T-xgofmzKg02be8j/.test(val.profile_pic) ? '' : val.profile_pic;
						var contact_name = val.name || '';
						var company = val.current_employer || '';
						var title = val.current_title || '';
						var city = val.city ? val.city : val.location || '';
						var contact = []

						if (val.links.linkedin) {
							contact.push({
								type: 'Linkedin',
								info: val.links.linkedin
							})
						}

						if (val.links.facebook) {
							contact.push({
								type: 'Facebook',
								info: val.links.facebook
							})
						}

						if (val.links.twitter) {
							contact.push({
								type: 'Twitter',
								info: val.links.twitter
							})
						}

						return {
							img: img,
							contact_name: contact_name,
							company: company,
							title: title,
							plugin_id: 'linkedin-' + funs.getLinkedinUrlId(val.linkedin_url),
							city: city,
							contact: contact
						}
					});
					store.commit('progressNext')
					resolve(data)
					//content-script主动发消息给后台
					funs.contentSendMessage(data.length)
				}
			},

			error: function () {
				reject('获取个人信息失败');
			}
		})
	})
}



