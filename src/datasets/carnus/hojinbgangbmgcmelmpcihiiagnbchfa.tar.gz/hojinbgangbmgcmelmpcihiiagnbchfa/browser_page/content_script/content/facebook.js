import store from '../../../vue-common/store.js';


export function contact() {
	return new Promise(function (resolve) {

		var h1 = $('h1._2nlv').find('a');
		if (!h1.length) {
			return resolve([])
		}
		store.commit('progressStart', 1);

		var urlid = funs.getFacebookUrlId(h1.attr('href'));
		var data = {
			img: $('.profilePicThumb img').attr('src'),
			contact_name: h1.text(),
			title: '',
			company: '',
			city: '',
			plugin_id: 'facebook-' + urlid,
			contact: [{
				type: 'Facebook',
				info: 'https://www.facebook.com/' + urlid,
			}]
		};
		var info = getContactInfo()
		data = Object.assign(data,info)
		resolve([data])
		//通知后台，数据已经整理完成
		funs.contentSendMessage(1);
		store.commit('progressNext')


	})
}
function getContactInfo(){

		var title = '', company = '', city = '';
		var box = $('.uiList._3-8x');

		if (!box.length) {
			return {};
		}

		var companys = $(box.find('.sx_3a6889+div')[0]);

		//是否有公司职位
		if (companys.length) {
			company = companys.find('._50f3').text();

			var arr = funs.labelTreatment(company);
			company = arr[0];
			title = arr[1];
		}

		var citys = box.find('.sx_5966d9+div');

		//是否有所在地
		if (citys.length) {
			city = citys.find('.profileLink').text();
		} else {
			var citys2 = box.find('.sp_KNcgF_xMEgJ.sx_3cb0bb+div');
			if (citys2.length) {
				city = companys.find('.profileLink').text();
			}
		}

	return {title:title,company:company,city:city}
}


export function project() {
	return new Promise(function (resolve) {

		var h1 = $('#seo_h1_tag').find('a');

		if (!h1.length) {
			return resolve([])
		}
		store.commit('progressStart', 1)
		var data = {
			img: $('#u_0_u img').attr('src'),
			contact_name: h1.text(),
			title: '',
			company: '',
			city: '',
			plugin_id: 'facebook-' + funs.getFacebookUrlId(h1.attr('href')),
			contact: [{
				type: 'Facebook',
				info: h1.attr('href'),
			}]
		};

		resolve([data])
		//通知后台，数据已经整理完成
		funs.contentSendMessage(1);
		store.commit('progressNext');
	})
}






