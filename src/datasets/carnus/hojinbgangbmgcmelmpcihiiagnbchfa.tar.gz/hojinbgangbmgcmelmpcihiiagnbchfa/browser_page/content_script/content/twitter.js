import store from '../../../vue-common/store.js';

//根据urlid获取联系人数据
function getContact(urlId) {
	return new Promise(function (resolve, reject) {
		funs.getContactInfo(urlId).then(function (d) {
			if (d) {
				resolve(d)
				console.log('使用本地')
			} else {
				console.log('使用请求');
				var url = 'https://twitter.com/' + urlId
				var time = funs.scopeRandom(300, 1000)

				setTimeout(function () {
					$.ajax({
						type: 'get',
						url: url,
						data: {fms: 1},
						headers: {
							"accept": "application/json, text/javascript, */*; q=0.01",
							"x-push-state-request": "true",
							"x-twitter-active-user": "yes"
						},
						dataType: 'json',

						success: function (data) {

							if (!data.init_data) {
								return reject(null);
							}

							var users = data.init_data.profile_user;

							//当前联系人的信息
							var contact = {
								img: $(data.page).find('.ProfileAvatar-container').attr('href'),
								contact_name: users.name,
								title: '',
								company: '',
								city: users.location,
								plugin_id: 'twitter-' + users.screen_name,
								profile_id: users.id,
								contact: [
									{
										type: 'Twitter',
										info: 'https://twitter.com/' + users.screen_name + '/'
									},
								]
							};

							funs.saveContactInfo(urlId, contact);
							resolve(contact);
						},

						error: function () {
							reject('获取历史记录失败')
						}
					})
				}, time)
			}
		})
	})
}

//获取可能喜欢的用户urlIds
function getLikeUrlIds(userId) {
	return new Promise(function (resolve, reject) {
		var url = 'https://twitter.com/i/related_users/' + userId;
		var excluded = localStorage.getItem('__excluded_related_users__:excluded_' + userId);
		var data = {}

		if (excluded) {
			data = {excluded: JSON.parse(excluded).join(',')}
		}

		$.ajax({
			type: 'get',
			url: url,
			data: data,
			dataType: 'json',
			headers: {'accept': 'text/plain, */*; q=0.01'},
			success: function (data) {
				if (data && data.related_users_html) {
					var urlIds = $(data.related_users_html).filter('.UserSmallListItem').map(function (index, obj) {
						return $(obj).find('.username>b').text()
					})
					resolve(urlIds)
				} else {
					resolve([])
				}
			},

			error: function () {
				resolve([])
			}
		})
	})
}

//获取推荐的用户urlIds
function getRecommendationsUrlIds(userId) {
	return new Promise(function (resolve, reject) {
		var url = 'https://twitter.com/i/users/recommendations';
		var excluded = localStorage.getItem('__excluded_wtf_recs__:excluded');
		var data = {}

		if (excluded) {
			data = {
				connections:true,
				dismissable:true,
				display_location:'profile-sidebar',
				excluded: JSON.parse(excluded).join(','),
				initialResults:true,
				limit:3,
				oldest_unread_id: 0,
				pc:false,
				'scribeContext[component]':'user_recommendations',
				similar_to_user_id:userId
			}
		}

		$.ajax({
			type: 'get',
			url: url,
			data: data,
			dataType: 'json',
			headers: {
				'accept': 'application/json, text/javascript, */*; q=0.01',
				'x-twitter-active-user': 'yes',
			},
			success: function (data) {
				if(data.inner){
					var html = $(data.inner.user_recommendations_html).find('.user-actions.not-following.not-muting');
					var urls = []
					html.each(function(index){
						urls.push($(this).data('screen-name'))
					});
					resolve(urls)
				}
			},

			error: function () {
				resolve([])
			}
		})
	})
}

function urlIdsToContact(urlIds,vs) {

	return new Promise(function (resolve, reject) {
		var likeInfo = [];

		var re = function (index) {

			getContact(urlIds[index]).then((data) => {
				store.commit('progressNext')
				// progress.setprogress()
				likeInfo.push(data);
				funs.saveContactInfo(urlIds[index], data);
				console.log(vs, funs.getVersion())
				if (index == urlIds.length - 1 || vs != funs.getVersion()) {
					return resolve(likeInfo);
				}

				re(index + 1);

			}).catch(function () {
				// progress.setprogress()
				store.commit('progressNext')
				console.log(vs, funs.getVersion())
				if (index == urlIds.length - 1 || vs != funs.getVersion()) {
					return resolve(likeInfo);
				}
				re(index + 1);
			})
		}

		if (urlIds.length) {
			re(0)
		} else {
			resolve(history)
		}
	})
}

export default function (url) {

	return new Promise(function (resolve, reject) {
		var urlId = funs.getTwtterUrlId(url)
		var contact;
		funs.createVersion()
		getContact(urlId).then(function (data) {
			var id = data.profile_id;
			contact = data;
			return getLikeUrlIds(id);
		}).then(function (urlIds) {
			store.commit('progressStart',urlIds.length + 1);

			//通知后台，数据已经整理完成
			funs.contentSendMessage(urlIds.length + 1);
			store.commit('progressNext')
			// progress.setprogress();
			return urlIdsToContact(urlIds,funs.getVersion());
		}).then(function (data) {
			console.log(data);
			data.unshift(contact)
			resolve(data);
		}).catch(function () {
			if (contact) {
				resolve([contact])
			}
		})
	})

}
