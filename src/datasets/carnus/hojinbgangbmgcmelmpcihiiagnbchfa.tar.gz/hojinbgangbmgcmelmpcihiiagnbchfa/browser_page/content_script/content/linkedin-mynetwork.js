import * as Cookies from "js-cookie";
import {urlsToContacts} from "./linkedin";
import store from "../../../vue-common/store";

var urlIds = []
export default function linkedinMyNetwork(url) {

	var ajaxToken = Cookies.get('JSESSIONID');
	if (ajaxToken) {
		funs.setLinkedInToken(ajaxToken);
	}

	funs.createVersion();
	var vs = funs.getVersion();
	return new Promise((resolve, reject) => {
		$.ajax({
			type: 'get',
			url: url,
			data: {fms: 1},
			headers: {
				'csrf-token': ajaxToken,
			},
			success: function (data) {
				if (vs !== funs.getVersion()) return;

				if (url.indexOf('start=0') >= 0) {
					urlIds = [];
				}
				data.elements.forEach((val) => {
					var key = 'com.linkedin.voyager.identity.shared.MiniProfile';
					if (val.entity && val.entity[key] && val.entity[key].publicIdentifier) {
						urlIds.push(val.entity[key].publicIdentifier)
					}
				});
				store.commit('progressStart', urlIds.length);
				funs.contentSendMessage(urlIds.length);
				urlsToContacts(urlIds, ajaxToken, vs).then((data) => {
					resolve(data);
				}).catch((err) => {
					store.commit('progressError');
					return Promise.reject(err);
				})
				console.log(urlIds);
			},
			error(e) {
				if (e.status === 999 || e.status === 401) {
					return reject('linkedin not log in')
				} else {
					reject(e.responseText)
				}
			}
		})
	})

}