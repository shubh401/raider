import * as Cookies from "js-cookie";
import store from '../../../vue-common/store.js';

//获取用户信息
//@param {string} urlId 获取浏览记录的url
//@param {string} ajaxToken
//@return {Promise} then(Array) 返回浏览记录列表
export var contactInfo = (urlId, ajaxToken) => {

	return new Promise((resolve, reject) => {

		//查本地数据库，是否有值
		funs.getContactInfo(urlId).then((d) => {

			if (d) {
				//有值
				console.log('contact 有缓存')
				return resolve(d);
			}

			//无值，网络请求
			var url = 'https://www.linkedin.com/voyager/api/identity/profiles/' + urlId + '/profileView';
			var time = funs.scopeRandom(300, 1500) //请求随机延迟

			setTimeout(() => {
				console.log('contact 在线')
				$.ajax({
					type: 'get',
					url: url,
					headers: {
						'csrf-token': ajaxToken,
						// 'accept': 'application/vnd.linkedin.normalized+json'
					},
					success(data) {

						// var contactData = getCurrentInfo(data, urlId)
						var contactData = getCurrentProfile(data, urlId)

						//获取联系人twitter
						getCurrentContactInfo(urlId, ajaxToken).then(function (contactInfo) {
							if (contactInfo.length) {
								contactInfo.forEach((val) => {
									contactData.contact.push(val);
								});
							}

							funs.saveContactInfo(urlId, contactData);
							resolve(contactData)
						}).catch(reject)

					},
					error(e) {
						if (e.status === 999 || e.status === 401) {
							return reject('linkedin not log in')
						} else {
							reject(e.responseText)
						}
					}
				})
			}, time)

		}).catch((e) => {
			console.log('linkedin错错', e)
			reject('linkedin错错')
		});
	})
}

//获取用户联系方式
//@param {string} urlId 获取浏览记录的url
//@param {string} ajaxToken
//@return {Promise} then(Array) 返回twitter账号数组，如果没有，返回数组
export var getCurrentContactInfo = (urlId, ajaxToken) => {
	return new Promise((resolve, reject) => {
		var url = 'https://www.linkedin.com/voyager/api/identity/profiles/' + urlId + '/profileContactInfo'
		$.ajax({
			type: 'get',
			url: url,
			headers: {
				'csrf-token': ajaxToken,
			},
			success(data) {
				var arr = [];
				console.log('data', data)
				//twitter
				if (data.twitterHandles && data.twitterHandles.length > 0) {
					data.twitterHandles.forEach((val) => {
						arr.push({
							type: 'Twitter',
							info: `https://twitter.com/${val.name}/`
						})
					})

				}
				//phone
				if (data.phoneNumbers && data.phoneNumbers.length > 0) {
					data.phoneNumbers.forEach((val) => {
						arr.push({
							type: 'Phone',
							info: val.number
						})
					})
				}
				//Skype
				if (data.ims && data.ims.length > 0) {
					data.ims.forEach((val) => {
						if (val.provider === "SKYPE") {
							arr.push({
								type: 'Skype',
								info: val.id
							})
						}

					})
				}
				//Wechat
				if (data.weChatContactInfo && data.weChatContactInfo.qr) {
					arr.push({
						type: 'Wechat',
						info: data.weChatContactInfo.qr
					})
				}

				//Email
				if (data.emailAddress) {
					arr.push({
						type: 'Email',
						info: data.emailAddress
					})
				}

				resolve(arr)
			},
			error(e) {
				if (e.status === 999 | e.status === 401) {
					return reject('linkedin not log in')
				} else {
					console.log('linkedin 获取用户数据错误', e)
					resolve([])
				}
			}
		})
	})
}


//获取浏览记录
//@param {string} urlId 获取浏览记录的url
//@param {string} ajaxToken
//@return {Promise} then(Array) 返回浏览记录列表
export var getHistoryUrlIds = (urlId, ajaxToken) => {

	return new Promise((resolve, reject) => {

		funs.getTemp(urlId, 'history', 24).then((ids) => {

			if (ids) {
				console.log('History', '使用本地')
				resolve(ids)
				return;
			}

			var time = funs.scopeRandom(300, 1000);
			setTimeout(() => {
				var url = 'https://www.linkedin.com/voyager/api/identity/profiles/' + urlId + '/browsemapWithDistance'
				$.ajax({
					type: 'get',
					url: url,
					headers: {
						'csrf-token': ajaxToken,
					},
					success(data) {
						var urlIds = data.elements.map((val) => {
							return val.miniProfile.publicIdentifier
						});
						console.log('History', '使用在线')
						funs.saveTemp(urlId, 'history', urlIds)

						resolve(urlIds)
					},

					error(e) {
						reject(e.responseText)
					}
				})
			}, time)

		})
	})

}

export var urlsToContacts = (urlIds, ajaxToken, vs) => {

	if (!urlIds) {
		return Promise.resolve([]);
	}

	return new Promise((resolve, reject) => {
		var history = [];

		var re = (index) => {

			contactInfo(urlIds[index], ajaxToken).then((data) => {
				console.log(vs , funs.getVersion())
				if (vs !== funs.getVersion()) return
				store.commit('progressNext');
				if (data.contact_name) {
					history.push(data);
				}

				//数组最后一位或版本不一样

				if (index == urlIds.length - 1 || vs !== funs.getVersion()) {
					console.log('版本不一样或完成', vs, funs.getVersion())
					resolve(history)
					return;
				}

				re(index + 1);

			}).catch((e) => {
				if (vs !== funs.getVersion()) return

				if (e === 'linkedin not log in') {
					return reject('linkedin not log in')
				}

				//数组最后一位或版本不一样
				if (index == urlIds.length - 1) {
					return resolve(history);
				}

				store.commit('progressNext')
				re(index + 1);

			})
		}

		if (urlIds.length) {
			re(0)
		} else {
			if (vs !== funs.getVersion()) return
			resolve(history)
		}

	})

}
//采集个人首页信息
export var getCurrentProfile = (code_active, urlId) => {

	if (!code_active || !code_active.profile) {
		//included数据为空时，停止处理
		return false;
	}


	//获取工作经历的数据
	var work = ((code_active) => {
		var data = {}
		if (code_active.positionView && code_active.positionView.elements && code_active.positionView.elements.length) {
			var newWork = code_active.positionView.elements[0];
			data = {
				title: newWork.title || '',
				company: newWork.companyName || '',
				city: newWork.locationName || '',
				description: newWork.description || ''
			}
		}

		return data;
	})(code_active);

	var profile = code_active.profile;
	//联系人姓名
	var firstName = profile.firstName,
		lastName = profile.lastName,
		name = /[A-Za-z]+/.test(lastName) ? firstName + ' ' + lastName : lastName + '' + firstName,
		locationName = profile.locationName || '';

	//国家
	var country = '';
	if (profile.location && profile.location.basicLocation) {
		country = profile.location.basicLocation.countryCode || '';
	}


	//获取头像
	var icon = ((profile) => {
		var rootUrl = '', img = '', url = '';
		if (profile.miniProfile.picture && profile.miniProfile.picture['com.linkedin.common.VectorImage'] &&
			profile.miniProfile.picture['com.linkedin.common.VectorImage'].artifacts) {
			var imgs = profile.miniProfile.picture['com.linkedin.common.VectorImage'].artifacts;
			rootUrl = profile.miniProfile.picture['com.linkedin.common.VectorImage'].rootUrl || '';
			img = imgs[imgs.length - 1].fileIdentifyingUrlPathSegment || '';
			url = rootUrl + img
		}
		return url;

	})(profile);

	var signature = profile.miniProfile.occupation || '';

	var company = work.company, title = work.title;

	if (signature) {
		var label = funs.labelTreatment(signature);
		if (!company) company = label[0] ? funs.trim(label[0], ' ,的') : work.company;
		if (!title) title = label[1] ? funs.trim(label[1], ',的') : work.title;
	}

	//当前联系人的信息
	var contactInfo = {
		img: icon,
		contact_name: funs.trim(name),
		title: funs.trim(title),
		company: funs.trim(company),
		first_name: funs.trim(firstName),
		last_name: funs.trim(lastName),
		country: funs.trim(country),
		city: funs.trim(work.city) || funs.trim(locationName),
		plugin_id: 'linkedin-' + urlId,
		contact: [
			{
				type: 'Linkedin',
				info: 'https://www.linkedin.com/in/' + urlId + '/'
			},
		]
	};

	if (profile.birthDate) {
		if (profile.birthDate.year) contactInfo.birth_year = profile.birthDate.year;
		if (profile.birthDate.month) contactInfo.birth_month = profile.birthDate.month;
		if (profile.birthDate.day) contactInfo.birth_day = profile.birthDate.day;
	}

	return contactInfo;
}

//采集个人首页信息
export var getCurrentInfoBack = (code_active, urlId) => {
	if (!code_active.included || code_active.included.length === 0) {
		//included数据为空时，停止处理
		return false;
	}

	// console.log(JSON.stringify(code_active))

	//获取工作经历的数据
	var work = ((code_active) => {

		//职业视图id
		var positionView = code_active.data.positionView;

		var position_id, data = {};

		code_active.included.some((val) => {
			if (val.entityUrn === positionView) {

				//工作经历越靠前越新，所以拿第一个
				position_id = val.elements ? val.elements[0] : '';
			}
		});


		if (position_id) {
			code_active.included.some((val) => {
				if (val.entityUrn === position_id) {
					data = {
						title: val.title || '',
						company: val.companyName || '',
						city: val.locationName || '',
						description: val.description || ''
					}
					return true;
				}
			});
		}
		return data;
	})(code_active);


	//联系人
	var name = '',
		locationName = '',
		vectorImage = '', //头像位置
		firstName = '',
		lastName = '',
		birthDate = '',
		defaultLocale = '';

	code_active.included.some((profile) => {
		if (profile.$type == 'com.linkedin.voyager.identity.profile.Profile') {
			firstName = profile.firstName;
			lastName = profile.lastName;
			name = /[A-Za-z]+/.test(lastName) ? firstName + ' ' + lastName : lastName + '' + firstName
			defaultLocale = profile.location + ',basicLocation';
			locationName = profile.locationName || '';
			birthDate = profile.birthDate || '';
			vectorImage = profile.miniProfile + ',picture,com.linkedin.common.VectorImage'
			return true;
		}
	});

	//国家
	var country = '';
	code_active.included.some((profile) => {
		if (profile.$id == defaultLocale) {
			country = profile.countryCode || '';
			return true;
		}
	});

	//获取头像
	var icon = ((code_active, vectorImage) => {
		var rootUrl = '', imgId = '', img = '', url = '';

		code_active.included.some((val) => {

			if (val.$id == vectorImage) {
				rootUrl = val.rootUrl || '';
				imgId = val.artifacts[val.artifacts.length - 1]
				return true;
			}

		});

		code_active.included.some((val) => {
			if (val.$id == imgId) {
				img = val.fileIdentifyingUrlPathSegment;
				return true;
			}
		});

		if (img) {
			url = rootUrl + img;
		}

		return url;

	})(code_active, vectorImage);

	var signature = '';
	code_active.included.some((profile) => {
		if (profile.$type == 'com.linkedin.voyager.identity.shared.MiniProfile') {
			signature = profile.occupation
		}
	});

	var company = work.company, title = work.title;
	if (signature) {
		var label = funs.labelTreatment(signature)
		company = label[0] ? funs.trim(label[0].replace(work.title, ''), ' ,的') : work.company;
		title = label[1] ? funs.trim(label[1].replace(work.company, ''), ',的') : work.title;
	}

	//当前联系人的信息
	var contactInfo = {
		img: icon,
		contact_name: funs.trim(name),
		title: funs.trim(title),
		company: funs.trim(company),
		first_name: funs.trim(firstName),
		last_name: funs.trim(lastName),
		country: funs.trim(country),
		city: funs.trim(work.city) || funs.trim(locationName),
		plugin_id: 'linkedin-' + urlId,
		contact: [
			{
				type: 'Linkedin',
				info: 'https://www.linkedin.com/in/' + urlId + '/'
			},
		]
	};

	if (birthDate) {
		code_active.included.some((birth) => {
			if (birth.$id == birthDate) {
				if (birth.year) contactInfo.birth_year = birth.year;
				if (birth.month) contactInfo.birth_month = birth.month;
				if (birth.day) contactInfo.birth_day = birth.day;
			}
		});
	}

	return contactInfo;
}


export default function init(url) {

	funs.createVersion();
	return new Promise(function (resolve, reject) {
		//获取数据思路，先拿到所有需要获取的用户的url
		//再跟据url获取用户数据

		//获取ajax请求的token,ajax请求中必须用到
		var ajaxToken = Cookies.get('JSESSIONID');
		if (ajaxToken) {
			funs.setLinkedInToken(ajaxToken);
		}


		// 1) 个人页面的ID
		//在ajax请求时，或在拼接个人页面时用到
		var urlId = funs.getLinkedinUrlId(url);

		//urlID不存在
		if (!urlId) {
			return resolve([]);
		}

		// var progress = funs.progress();

		// 2) 获取会员还看了，urlids
		getHistoryUrlIds(urlId, ajaxToken).then(function (ids) {

			ids.unshift(urlId);

			store.commit('progressStart', ids.length);
			// progress.setTotal(ids.length);

			//通知后台，一共有几个用户
			funs.contentSendMessage(ids.length);

			//跟据urlid查询用户内容
			return urlsToContacts(ids, ajaxToken, funs.getVersion());

		}).then(resolve).catch((err) => {
			reject(err);
			store.commit('progressError');
		})
	})
}

export function linkedinSearch(url) {
	console.log('1111111111111')
	funs.createVersion()
	var ajaxToken = Cookies.get('JSESSIONID');
	if (ajaxToken) {
		funs.setLinkedInToken(ajaxToken);
	}

	return new Promise((resolve, reject) => {
		$.ajax({
			type: 'get',
			url: url,
			data: {fms: 1},
			headers: {
				'csrf-token': ajaxToken,
				"x-li-track": '{"clientVersion":"1.2.985","osName":"web","timezoneOffset":8,"deviceFormFactor":"DESKTOP","mpName":"voyager-web"}',
				"x-restli-protocol-version": "2.0.0"
			},
			success(data) {
				console.log('resolveresolveresolveresolve', data)
				if (data.elements[0]) {
					var ids = [];
					//获取用户id
					data.elements.forEach(el=>{
						if(el.elements){
							el.elements.forEach((val) => {
								if (val.publicIdentifier ) {
									var publicIdentifier = val.publicIdentifier
									//unknown为不可查看地
									if (publicIdentifier !== 'UNKNOWN') {
										ids.push(publicIdentifier)
									}

								}
							});
						}
					})


					//通知后台，一共有几个用户
					store.commit('progressStart', ids.length);
					funs.contentSendMessage(ids.length);

					//跟据urlid查询用户内容
					urlsToContacts(ids, ajaxToken, funs.getVersion()).then(resolve).catch((err) => {
						reject(err);
						store.commit('progressError');
					})

				} else {
					resolve([])
				}

			},
			error(e) {
				if (e.status === 999 || e.status === 401) {
					return reject('linkedin not log in')
				} else {
					reject(e.responseText)
				}
			}
		})
	})

}

