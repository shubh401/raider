import * as linkedin from './linkedin'
import store from '../../../vue-common/store.js';
import {checkStatus} from '../../../vue-common/ajax/contact.js'
function getCompany() {
	var comp = $('#rhs_block').find('.ifM9O');
	var compHeader = comp.find('.kp-header');
	var loglanHref = compHeader.find('.luib>.luibr').find('a').attr('href');
	var outside = compHeader.find('.luib>div>.luibli').find('a').attr('href') || "";
	if(outside){
		outside = location.origin+outside;
	}
	console.log(outside);
	if (loglanHref && /\@(.*?),(.*?),/.test(loglanHref)) {

		var original = compHeader.find('.kno-ecr-pt').text();
		var website = compHeader.find('.ab_button').eq(0).attr('href');

		var latitude = '', //纬度
			longitude = '', //经度
			domain = [], //主页
			tels = [], //电话
			country = '', //国家
			address = ''

		if (/^http/.test(website)) {
			domain = [{domain:website}];
		}

		var reg = /\@(.*?),(.*?),/.exec(loglanHref);
		if (reg[1]) {
			latitude = reg[1];
			longitude = reg[2];
		}

		// console.log(original)
		// console.log(domain)
		//
		// console.log(latitude, longitude)

		var li1 = $('.SALvLe>.i4J0ge').find('.mod .kno-fb-ctx');
		var li2 = comp.find('.mod .kno-fb-ctx');
		console.log('li2',li2)
		var getList = function(li){
			li.each((val, obj) => {
				var self = $(obj).children();
				console.log('self',self)
				var name = self.eq(0).find('a').text();
				var value = self.eq(1).text();
				switch (name) {
					case '地址':
					case '位置':
					case 'Address':
						address = value;
						break;
					case '電話':
					case '电话':
					case '电话号码':
					case 'Phone':
						tels.push({tel:value});
				}
			});
		}

		if (li1.length) {
			getList(li1)
		}else if(li2.length){
			console.log('到这来了')
			getList(li2)
		}

		if (address) {
			var ar = address.split(', ');
			if (ar.length > 1)
				country = ar[ar.length - 1]
		}

		var companys = {
			company: original,
			domain: domain,
			tels: tels,
			alias_name: '',
			brands:[],
			outside:outside,
			country: country,
			remake:'',
			plugin_id:original,
			address: [{
				address: address,
				longitude: longitude,
				latitude: latitude
			}]
		}

		checkStatus({company:[original]}).then((res)=>{

			if(!res.company[0].company_id){
				compHeader.find('.Xp3Yhb').append('<button type="button" id="add-company" class="add-company">Add To FMS</button>	')
			}else{
				compHeader.find('.Xp3Yhb').append('<button type="button" class="add-company" disabled >FMS ✔</button>	')

			}

			$('#add-company').on('click', () => {
				store.commit('openInject',{type:'add-company',content:companys})
			})
		})


	}
}

export default function () {
	getCompany()


	return new Promise(function (resolve, reject) {


		var linkedinUrls = [];
		$('.g').find('.rc>.r>a').each(function () {
			var url = this.href;
			var id = funs.getLinkedinUrlId(url);
			if (id) {
				linkedinUrls.push(id)
			}
		});

		//通知后台，数据已经整理完成
		if (linkedinUrls.length) {
			funs.contentSendMessage(linkedinUrls.length);
		}

		//获取linkedin token
		funs.getLinkedInToken().then((ajaxtoken) => {
			console.log(linkedinUrls.length);
			store.commit('progressStart', linkedinUrls.length);
			return linkedin.urlsToContacts(linkedinUrls, ajaxtoken, funs.getVersion());
		}).then(function (data) {
			resolve(data)
		}).catch((err) => {
			reject(err);
			store.commit('progressError');
		})
	})

}
