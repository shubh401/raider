//脚本内容
//针对采集点对应使用相应的脚本内容
import linkedin, {linkedinSearch} from './content/linkedin.js'
import {linkedinSalesProfile, linkedinSalesSearch,linkedinSalesSearchHtml} from './content/linkedin-sales'
import linkedinMyNetwork from './content/linkedin-mynetwork'
import twitter from './content/twitter.js'
import * as  facebook from "./content/facebook";
import * as rocketreach from './content/rocketreach';
import googleSearch from './content/google_search.js';
import * as f from "../../vue-common/functions/functions";

import DataItem from "../../vue-common/DataItem.class";
import store from "../../vue-common/store";

var urlId = '', pasteStatus = true, soundStatus = true;
funs.getStatus('pasteStatus').then((bool) => {
	pasteStatus = bool
	if (pasteStatus && location.hostname !== 'fieldflint.hydrophis.cn') {
		document.addEventListener('paste', pasteEvent);
	}
});
funs.getStatus('soundStatus').then((bool) => {
	soundStatus = bool;
})
//接收后台消息事件
//页面被动事件
chrome.runtime.onMessage.addListener(function (res, sender, sendResponse) {

	switch (res.type) {
		case 'get-twitter-data':
			urlId = funs.pageUniqueId(location.href);
			sendBefore(twitter(res.url));
			break;
		case 'get-facebook-data-contact':
			urlId = funs.pageUniqueId(location.href);
			sendBefore(facebook.contact());
			break;
		case 'get-facebook-data-project':
			urlId = funs.pageUniqueId(location.href);
			sendBefore(facebook.project());
			break;
		case 'get-rocketreach-data-contacts':
			urlId = funs.pageUniqueId(location.href);
			console.log('get-rocketreach-data-contacts url', res.url)
			sendBefore(rocketreach.contacts(res.url));
			break;
		case 'get-linkedin-data-contact':
			console.log('get-linkedin-data-contact')
			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedin(urlId));
			break;
		case 'get-linkedin-mynetwork-contact':
			//mynetwork页面采集

			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedinMyNetwork(res.url));
			break;
		case 'get-linkedin-search-data-contact':
			//linkedin /search 页面

			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedinSearch(res.url));
			break;
		case 'get-linkedin-sales-profile-contact':
			//linkedin sales/profile 页面
			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedinSalesProfile(res.url));
			break;
		case 'get-linkedin-sales-search-contact':
			//linkedin sales/search 页面
			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedinSalesSearch(res.url));
			break;
		case 'get-linkedin-sales-search-contact-html':
			//linkedin sales/search 页面
			urlId = funs.pageUniqueId(location.href);
			sendBefore(linkedinSalesSearchHtml());
			break;
		case 'get-rocketreach-data-search':
			urlId = funs.pageUniqueId(location.href);
			sendBefore(rocketreach.search(res.url));
			break;
		case 'get-page-id':
			sendResponse(urlId);
			break;
		case 'set-paste-status':
			pasteStatus = res.status;

			if (location.hostname !== 'fieldflint.hydrophis.cn') {
				if (pasteStatus) {
					document.addEventListener('paste', pasteEvent);
				} else {
					document.removeEventListener('paste', pasteEvent);
				}
			}
			break;

		case 'set-sound-status':
			soundStatus = res.status;
			break;
	}
});


function pasteEvent(event) {
	//not for ie11  某些chrome版本使用的是event.originalEvent
	var clipboardData = (event.clipboardData || event.originalEvent.clipboardData);

	// for chrome
	var items = clipboardData.items,
		len = items.length,
		blob = null;

	//在items里找粘贴的image,据上面分析,需要循环
	for (var i = 0; i < len; i++) {
		if (items[i].type.indexOf("image") !== -1) {
			// console.log(items[i]);
			// console.log( typeof (items[i]));

			//getAsFile() 此方法只是living standard firefox ie11 并不支持
			blob = items[i].getAsFile();
		}
	}

	if (blob !== null) {
		var reader = new FileReader();
		reader.onload = function (event) {
			// event.target.result 即为图片的Base64编码字符串
			var base64_str = event.target.result
			//可以在这里写上传逻辑 直接将base64编码的字符串上传（可以尝试传入blob对象，看看后台程序能否解析）
			// console.log(base64_str)
			if (!document.getElementById('fms-inject')) {
				console.log('vue根元素重建')
				document.body.appendChild(store.state.appDom);
			}
			store.commit('openInject', {type: 'menu-select-img', content: base64_str})
		}
		reader.readAsDataURL(blob);
	}
}


//页面主动事件
//页面加载完成后处理
document.addEventListener('DOMContentLoaded', () => {

	// linkedin 搜索
	if (/^https?:\/\/[^\.]*?.linkedin.com\/search\/results\/(people|index|all)/.test(location.href)) {

		urlId = funs.pageUniqueId(location.href);
		var keywords = decodeURIComponent(funs.getParam('keywords')); //关键字
		if (keywords) {
			keywords = '&keywords=' + keywords;
		}
		var origin = funs.getParam('origin') || 'FACETED_SEARCH';	//来源
		var page = funs.getParam('page') || 1; //页数
		var start = (page - 1) * 10;
		var blendedSrpEnabled = ''; //全局搜索

		//综合搜索
		if (/^https?:\/\/[^\.]*?.linkedin.com\/search\/results\/index/.test(location.href)) {
			blendedSrpEnabled = 'blendedSrpEnabled=true&';
		}

		var queryContext  = funs.getParam('queryContext')
		if(!queryContext ){
			queryContext  = 'List(spellCorrectionEnabled->true)'
		}

		//筛选条件
		var filtrate = Object.create(null);
		filtrate.geoRegion = funs.getParam('facetGeoRegion'); //地区
		if(filtrate.geoRegion){
			filtrate.geoRegion = encodeURIComponent(decodeURIComponent(filtrate.geoRegion).replace('["','').replace('"]',''))
		}

		filtrate.facetNetwork = funs.getParam('facetNetwork'); //好友熟度数

		if (filtrate.facetNetwork) {
			filtrate.facetNetwork = JSON.parse(decodeURIComponent(filtrate.facetNetwork)).join('%7C');
		}

		filtrate.facetCurrentCompany = funs.getParam('facetCurrentCompany'); //所在公司

		if (filtrate.facetCurrentCompany) {
			filtrate.facetCurrentCompany = JSON.parse(decodeURIComponent(filtrate.facetCurrentCompany)).join('%7C');
		}

		filtrate.company = funs.getParam('company');
		filtrate.facetIndustry = funs.getParam('facetIndustry');
		filtrate.lastName = funs.getParam('lastName');
		filtrate.firstName = funs.getParam('firstName');
		filtrate.facetPastCompany = funs.getParam('facetPastCompany');
		filtrate.facetNonprofitInterest = funs.getParam('facetNonprofitInterest');
		filtrate.facetProfileLanguage = funs.getParam('facetProfileLanguage');
		filtrate.school = funs.getParam('school');
		filtrate.title = funs.getParam('title');
		filtrate.facetConnectionOf = funs.getParam('facetConnectionOf');
		if (filtrate.facetConnectionOf) {
			filtrate.facetConnectionOf = JSON.parse(decodeURIComponent(filtrate.facetConnectionOf)).join('%7C');
		}

		var filtrArr = [];

		for (var i in filtrate) {
			if (filtrate[i]) {
				filtrArr.push(i + '->' + filtrate[i])
			}
		}

		//会员搜索
		if (/^https?:\/\/[^\.]*?.linkedin.com\/search\/results\/people/.test(location.href)) {
			filtrArr.push('resultType->PEOPLE');
		}

		var url = 'https://www.linkedin.com/voyager/api/search/blended?' + blendedSrpEnabled + 'count=10&filters=List(' + filtrArr.join(',') + ')' + keywords + '&origin=' + origin +'&queryContext='+queryContext+'&q=all&start=' + start
		console.log(url)
		sendBefore(linkedinSearch(url));
	} else
	//twitter
	if (/^https?:\/\/twitter.com\/.+$/.test(location.href)) {

		//你可能还喜欢刷新
		$('.js-refresh-related-users').on('click', function () {
			urlId = funs.pageUniqueId(location.href);
			setTimeout(function () {
				sendBefore(twitter(location.href));
			}, 0);
		});
	} else if (funs.getParam('fms-google-map')) {
		console.log('这是用户打开的谷歌地图');
		$('#viewer-header').css('display',"none");
		$('#viewer-footer').css('display',"none");
		$('#video-control').css('display',"none");
		$('#zoom').css('display',"none");
		$('#compass').css('display',"none");
		$('#fineprint').css('display',"none");
		store.commit('hasGoogleMap');
	} else
	//谷歌搜索
	if (/\/\/www\.google\.\w+(\.\w+)?\/search/.test(location.href)) {
		urlId = funs.pageUniqueId(location.href);
		sendBefore(googleSearch());
	}

});

function sendBefore(pro) {
	if (urlId) {
		chrome.runtime.sendMessage({
			type: 'del-content-datalist',
			urlId: urlId,
			dataList: null
		});
	}

	var lists
	return pro.then(function (list) {

		var dataList = list.map((v) => {
			return new DataItem(v);
		});

		console.log('成功第一步:采集到数据', dataList);

		return f.dataListAddMd5(dataList);
	}).then((listData) => {

		store.commit('progressNext');
		lists = listData;
		console.log('成功第二步：添加md5', listData);

		var three = threeWrap(lists);

		if (!store.state.userInfo) {
			store.commit('openLogin', three);
			return
		}

		three();
	})

	function threeWrap(l) {
		return function () {
			f.addServerData(l).then((list) => {
				store.commit('progressNext');
				list = funs.dataListSort(list);
				// console.log(JSON.stringify(list))
				if (urlId) {
					chrome.runtime.sendMessage({
						type: 'get-content-datalist',
						urlId: urlId,
						dataList: list
					}, function (response) {
						if (soundStatus && list.length) {
							store.commit('playbg');
						}
						console.log('采集数据到后台发送成功');
					});
				}
				// return Promise.resolve(list);
			})
		}
	}
}
