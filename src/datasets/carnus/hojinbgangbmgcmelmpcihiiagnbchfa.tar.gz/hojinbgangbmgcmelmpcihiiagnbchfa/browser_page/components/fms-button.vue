<template>
	<button class="fms-button" tabindex="0" @click="$emit('click')" v-focus="focus">
		<slot></slot>
	</button>
</template>
<script>
	export default {
		name: "fms-button",
		data() {
			return {};
		},
		 props:{
		   focus:Boolean,
		 },
		mounted() {
		},
		beforeDestroy() {
		},
		methods: {},
		components: {}
	}
</script>

<style scoped lang="less">
	//按钮
	.fms-button {
		display: inline-block;
		line-height: 36px;
		min-width: 88px;
		height: 36px;
		font-size: 14px;
		border: 0;
		padding: 0 10px !important;
		color: rgb(193, 39, 71) !important;
		-webkit-user-select: none;
		-webkit-transition: background .2s;
		transition: background .2s;
		background: transparent;
		border-radius: 3px;
		cursor: pointer;
		font-size: 15px;
		font-weight: 500;
		outline: none;
		overflow: hidden;
		position: relative;
		text-align: center;
		text-transform: uppercase;
		z-index: 0;
		&:focus {
			background: rgb(255, 221, 237) !important;
		}
		&:active {
			background: rgb(255, 157, 172) !important;
		}
		&:disabled {
			color: #999 !important
		}
	}
</style>