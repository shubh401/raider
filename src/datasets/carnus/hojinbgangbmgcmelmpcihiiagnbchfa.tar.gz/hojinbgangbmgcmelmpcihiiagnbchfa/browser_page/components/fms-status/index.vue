<template>
	<div class="fms-status">
		<fms-progress :total="progress.total" v-model="progress.show" :current="progress.current">
			{{progress.message}}
		</fms-progress>
	</div>
</template>

<script>
	import fmsProgress from './fms-status-progress.vue'

	export default {
		name: "fms-status",
		data() {
			return {

			};
		},
		props: {
			status: {
				type: String,
				default: ''
			}
		},
		computed: {
		  progress(){
		  		return this.$store.state.progress;
		  }
		},
		mounted() {
		},
		methods: {

		},
		components: {fmsProgress}
	}
</script>

<style scoped lang="less">

	.fms-status {
		pointer-events: auto;
		position: fixed;
		z-index: 99999;
		top: 60px;
		right: 20px;
	}
</style>