<template>
	<transition name="zoom">
		<div v-if="value" class="fms-progress fm-none" :class="statusClass">
			<div class="progress-text" v-if="progressText">
				<span>{{progressText}}</span>
			</div>
			<svg v-else class="fms-content-script-svg" xmlns="http://www.w3.org/2000/svg" width="40" height="15"
				  viewBox="0 0 171.62 64.15">
				<path fill="#5c5d5d"
						d="M151.16,296.85l-23.87.08v-9.12A6.72,6.72,0,0,1,134,281.1h17.62V268H134a19.84,19.84,0,0,0-19.82,19.82v44.3h13.1V310l23.87-.08Z"
						transform="translate(-114.19 -268)"/>
				<path fill="#5c5d5d"
						d="M268.72,294l-10-2c-5.88-1.21-6.56-4.1-6.56-6.17a5.38,5.38,0,0,1,2.36-4.73,11.85,11.85,0,0,1,7-1.92c5.37,0,8.95,2.19,10.9,6.69l11.52,0-.5-1.86c-2.83-10.54-10.33-15.89-22.28-15.89-6.2,0-11.23,1.79-15,5.31a17.75,17.75,0,0,0-5.7,13.4c0,4.83,1.43,8.79,4.26,11.77a20.71,20.71,0,0,0,11,5.83l10.81,2.29c6.61,1.36,7.38,4.5,7.38,6.74a6.25,6.25,0,0,1-2.69,5.5,12.45,12.45,0,0,1-7.44,2.17c-7.82,0-12.46-2.83-14.14-8.63l-11.67,0,.49,1.87c3.1,11.79,11.24,17.77,24.21,17.77,6.83,0,12.42-1.76,16.61-5.24a17.61,17.61,0,0,0,6.5-14.17C285.81,302.58,280.06,296.27,268.72,294Z"
						transform="translate(-114.19 -268)"/>
				<path fill="#5c5d5d"
						d="M217.76,268.12h-3.65l-17.34,27.44L179,268.12h-4.59a13.27,13.27,0,0,0-13.27,13.27v50.75h13.1V285.19l18,28.38h7.72l18-28.6v47.17H231V281.39A13.27,13.27,0,0,0,217.76,268.12Z"
						transform="translate(-114.19 -268)"/>
				<polygon fill="#bf1638" points="74 0.17 90.49 0.17 82.26 13.69 74 0.17"/>
			</svg>
			<div class="progress-message">
				<slot></slot>
			</div>
		</div>
	</transition>
</template>

<script>
	export default {
		name: "fms-status-progress",
		data() {
			return {};
		},
		props: {
			current: Number,
			total: Number,
			value: Boolean
		},
		computed: {

			progressText() {
				var pro = ~~(this.current / this.total * 100);
				if (this.total < 0) {
					return 'Error'
				} else if (pro >= 100 || this.current == 0 && this.total == 0) {
					return ''
				} else if (pro === 0) {
					return '0' + '%'
				} else {
					return pro + '%'
				}
			},

			statusClass() {
				var cla = ''
				if (this.total < 0) {
					cla = 'fm-error'
				} else if (this.total == 0) {
					cla = 'fm-none'
				} else {
					if (this.total > this.current) {
						cla = "fm-underway"
					} else {
						cla = "fm-success"
					}
				}

				return cla;
			},
		},
	}
</script>

<style scoped lang="less">
	.fms-progress {
		background: rgba(255, 255, 255, .7);
		margin-bottom: 10px;
		box-sizing: border-box;
		width: 60px;
		height: 60px;
		text-align: center;
		border-radius: 50%;
		transition: all 0.5s;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		&.fm-none {
			color: #666;
			box-shadow: 0px 0px 15px 0 rgba(50, 50, 50, .2),inset -1px -1px 5px 0 rgba(0, 0, 0, .2);
		}

		//进行中
		&.fm-underway {
			color: #10aeff;
			box-shadow: 0px 0px 15px 0 #10aeff,inset -1px -1px 5px 0 rgba(0, 0, 0, .2);
			animation: underway-effect .5s linear infinite;
			.progress-message{
				color:#10aeff;
			}
		}

		//成功
		&.fm-success {
			color: #049E02;
			box-shadow: 0px 0px 15px 0 rgb(4, 158, 2), inset -1px -1px 5px 0 rgba(0, 0, 0, .2);
			.progress-message{
				display: none;
			}
		}

		//出错
		&.fm-error {
			color: rgb(220, 22, 62);
			box-shadow: 0px 0px 15px 0 rgb(220, 22, 62),inset -1px -1px 5px 0 rgba(0, 0, 0, .2);
			.progress-message{
				color:rgb(220, 22, 62);
			}
		}
		.progress-message {
			font-size:.6em;
			font-weight:700;
			color: #666;
			line-height: 2em;
			line-height: 20px;
		}
		.progress-text {
			font-weight: 700;
			font-size: 20px;
		}

		.fms-content-script-svg {
			display: block
		}
	}

	@keyframes underway-effect {
		0% {
			box-shadow: -1px 0px 15px 0 rgb(62, 133, 246), inset 1px 0px 5px 0 rgba(0, 0, 0, .2);
		}
		12.5% {
			box-shadow: -1px -1px 15px 0 rgb(62, 133, 246), inset 1px 1px 5px 0 rgba(0, 0, 0, .2);
		}
		25% {
			box-shadow: 0px -1px 15px 0 rgb(62, 133, 246), inset 0px 1px 5px 0 rgba(0, 0, 0, .2);
		}
		37.5% {
			box-shadow: 1px -1px 15px 0 rgb(62, 133, 246),inset -1px 1px 5px 0 rgba(0, 0, 0, .2);
		}
		50% {
			box-shadow: 1px 0px 15px 0 rgb(62, 133, 246),inset -1px 0px 5px 0 rgba(0, 0, 0, .2);
		}
		62.5% {
			box-shadow: 1px 1px 15px 0 rgb(62, 133, 246),inset -1px -1px 5px 0 rgba(0, 0, 0, .2);
		}
		75% {
			box-shadow: 0px 1px 15px 0 rgb(62, 133, 246), inset 0px -1px 5px 0 rgba(0, 0, 0, .2);
		}
		87.5% {
			box-shadow: -1px 1px 15px 0 rgb(62, 133, 246), inset 1px -1px 5px 0 rgba(0, 0, 0, .2);
		}
		100% {
			box-shadow: -1px 0px 15px 0 rgb(62, 133, 246), inset 1px 0px 5px 0 rgba(0, 0, 0, .2);
		}
	}

	.zoom-enter-active, .zoom-leave-active {

		transition: transform .2s;
	}

	.zoom-leave-active {
		transition: transform .5s 3s;
	}

	.zoom-enter, .zoom-leave-to {
		transform: scale(0) !important;
	}

</style>