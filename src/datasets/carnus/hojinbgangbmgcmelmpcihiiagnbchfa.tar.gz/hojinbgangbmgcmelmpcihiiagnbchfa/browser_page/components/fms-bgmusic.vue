<template>
	<div style="display: none">
		<audio :src="mp3" id="bgmusic" v-gbmusic="_self" controls="controls"></audio>
	</div>
</template>

<script>
	var mp3 = chrome.runtime.getURL('/imgs/dingdong.mp3');
	export default {
		name: "fms-bgmusic",
		data() {
			return {
				mp3: mp3
			};
		},
		directives: {
			gbmusic: {
				// 指令的定义
				inserted(el, binding) {
					var vue = binding.value
					el.volume = 0.3;
					vue.$store.commit('initbgMusic', el);
				}
			}
		},

		methods: {},
		components: {}
	}
</script>

<style scoped>

</style>