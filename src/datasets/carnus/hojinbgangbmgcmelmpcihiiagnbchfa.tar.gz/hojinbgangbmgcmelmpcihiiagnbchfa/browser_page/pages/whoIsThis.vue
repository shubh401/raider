<template>
	<ici-popup v-model="openPopup" :title="popupTitle" no-scroll @keyup.native.esc="close">

		<fms-input-group v-if="currentIndex==-2">
			<div slot="icon" class="fms-input-icon-pic" :style="'background-image:url('+img+')'"></div>
			<ici-input v-model="contact_name" :hint="hint" label="who is this?" @select="select" :focus="true">
				<a slot="title">
					<ici-icon name="icon-tianjia"></ici-icon>
					{{$t('添加')}}
				</a>
				<template slot-scope="list">
					<div class="fms-input-hint-icon"
						  :style="list.item.header?'background-image:url('+list.item.header+')':''"></div>
					<div class="fms-input-hint-name">
						{{list.item.contact_name}}
						<div v-if="list.item.company || list.item.title">
							<small>{{list.item.title || list.item.company}}</small>
						</div>
					</div>
					<div class="fms-input-hint-content">
						<a href="javascript:;">It's me</a>
					</div>
				</template>
			</ici-input>
		</fms-input-group>
		<newContact v-else-if="currentIndex==-1" ref="newContact" :more="isMore"
						:contact-name="contact_name" :img="img"></newContact>
		<addImage v-else-if="currentIndex>=0" :data="hint[currentIndex]" :img="img"></addImage>

		<div slot="footer-left" v-if="currentIndex==-1">
			<fms-button @click="isMore=true" :disabled="isMore">{{$t('展开')}}</fms-button>
		</div>
		<div slot="footer-right">
			<fms-button class="fms-button" tabindex="0" @click="close">{{$t('关闭')}}</fms-button>
			<fms-button v-if="currentIndex==-1" tabindex="0" :disabled="!contact_name || isLoading" @click="addSubmit">
				{{$t('确认添加')}}
			</fms-button>
			<fms-button v-if="currentIndex>-1" class="fms-button" tabindex="0" :disabled="isLoading"
							@click="editSubmit" :focus="currentIndex>-1">
				{{$t('确认')}}
			</fms-button>
		</div>
	</ici-popup>

</template>

<script>
	import {findContact, addContact, uploadImg} from '../../vue-common/ajax/contact.js';
	import newContact from '../pages/newContact.vue'; //新增联系人
	import addImage from '../pages/addImage.vue'; //联系人新增图片
	export default {
		name: "whoIsThis",
		data() {
			return {
				openPopup: false,
				confirmFocus: false,
				isMore: false, //更多
				hint: false, //提示文字，false无提示，true等待提示,[数组]提示列表；
				currentIndex: -2, //状态 -2不确定状态 -1新增 >=0为hint的索引；
				isLoading: false,//加载中
				contact_name: '',
				timeoutId: 0
			};
		},
		components: {newContact, addImage},
		computed: {
			popupTitle() {
				if (this.currentIndex == -2) {
					return this.$t('这是谁？');
				} else if (this.currentIndex == -1) {
					return this.$t('新增联系人');
				} else {
					return this.$t('新增图片');
				}
			},
			img() {
				return this.$store.state.injectCustom.content;
			}
		},

		watch: {
			contact_name(newValue, oldValue) {
				clearTimeout(this.timeoutId);
				this.hint = false;
				if (newValue) {
					this.hint = true;
					this.timeoutId = setTimeout(() => {
						findContact(newValue).then((data) => {
							this.hint = data;
						}).catch((err) => {
							console.log(err)
						})
					}, 400)
				}
			},
		},
		mounted() {
			if (this.img) {
				this.openPopup = true;
			}
		},

		methods: {
			close() {
				this.openPopup = false;
				setTimeout(() => {
					this.$store.commit('closeInject')
				}, 300)
			},
			//新增
			add() {
				this.currentIndex = -1;
			},
			//选择第几个人
			select(index) {
				this.currentIndex = index;
			},
			editSubmit() {
				var data = this.hint[this.currentIndex];
				var _this = this;
				if (data) {
					_this.isLoading = true;
					this.$icimsg.loading(`${this.$t('添加中')}...`);
					funs.contentScriptImgToBase64(this.img).then((val) => {
						uploadImg({contact_id: data.id, img: [val]}).then(() => {
							_this.isLoading = false;
							this.$icimsg.success('Successfully Added');
							this.close();
						}).catch((res) => {
							_this.isLoading = false;
							this.$icimsg.error(res.msg);
						})

					});

				}

				console.log(data)
			},
			//提交
			addSubmit() {

				var formData = this.$refs['newContact'].getInfo()

			 if (!formData.contact_name) {
					this.$icimsg.error(this.$t('联系人姓名不能为空'));
					return;
				}

				this.isLoading = true;
				this.$icimsg.loading('Being added...')
				funs.contentScriptImgToBase64(this.img).then((val) => {
					console.log(formData)
					var form = JSON.parse(JSON.stringify(formData))
					form.img = val;
					addContact(form).then((data) => {
						this.isLoading = false;
						this.$icimsg.success(this.$t('成功添加'));
						this.close()
					}).catch((err) => {
						this.isLoading = false;
						this.$icimsg.error(err.msg);
					})
				})
			},
		},
	}
</script>

<style scoped lang="less">
	.fms-input-hint-icon {
		width: 35px;
		height: 35px;
		flex: none;
		background: #eee no-repeat center;
		background-size: contain;
	}
	.fms-input-hint-name {
		padding-left: 10px;
		font-size: 14px !important;
		flex: auto;
		small {
			color: #999;
		}
	}
	.fms-input-hint-content {
		border-radius: 5px;
		padding: 2px 5px;
		margin-left: 10px;
		font-size: .8em;
		text-align: center;
		flex: none;
		a {
			color: #C12747 !important;
		}
	}
</style>
