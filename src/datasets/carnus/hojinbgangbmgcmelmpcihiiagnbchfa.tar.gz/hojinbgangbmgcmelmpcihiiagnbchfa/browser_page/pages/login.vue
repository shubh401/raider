<template>
	<ici-popup v-model="openPopup" title="Log In FMS Ext"  @keyup.native.esc="close">
		<fms-input-group>
			<ici-icon slot="icon" name="icon-yonghu"></ici-icon>
			<ici-input v-model="formData.username" :label="$t('请输入用户名')" :focus="true" key="username"></ici-input>
		</fms-input-group>
		<fms-input-group>
			<ici-icon slot="icon" name="icon-icon2"></ici-icon>
			<ici-input password v-model="formData.password" :label="$t('请输入密码')" key="password" @keyup-enter="onSubmit"></ici-input>
		</fms-input-group>
		<div slot="footer-left">
			<fms-button @click="onSubmit">{{$t('登录')}}</fms-button>
		</div>
	</ici-popup>
</template>

<script>
	import {login, changeLang} from '../../vue-common/ajax/user'

	export default {
		name: "login",
		data() {
			return {
				openPopup: false,
				formData: {
					username: '',
					password: '',
				}
			};
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo;
			},
			language() {
				return this.$store.state.language;
			}
		},
		mounted() {
			if (!this.userInfo) {
				this.openPopup = true;
			}
		},

		methods: {
			close() {
				this.openPopup = false;
				setTimeout(()=>{
					this.$store.commit('closeInject')
				},300)
			},
			onSubmit() {
				console.log(this.$icimsg)
				this.$icimsg.loading(this.$t('正在登录'));
				login(this.formData).then((res) => {

					this.$store.commit('setUserInfo', res);
					this.$emit('success');
					this.$store.commit('closeInject');

					this.$icimsg.success(this.$t('登录成功'));
					//php切换语言
					changeLang(this.language).then(() => {
						console.log('php切换语言成功')

					}).catch((err) => {
						console.log(err)
						this.$icimsg.error(err.msg)
					})

				}).catch((err) => {
					console.log('1111',err)
					this.$icimsg.error(err.msg)
				})
			},
			changeLang(val) {
				this.$store.commit('changeLang', val)
			}
		},
		components: {}
	}
</script>

<style scoped>

</style>