<template>
	<ici-popup v-model="openPopup" title="Add Account">
		<div v-if="formData">
			<fms-input-group>
				<ici-icon slot="icon" name="icon-gongsixinxi1" size="20px"></ici-icon>
				<ici-input required v-model="formData.company" :label="$t('公司')"></ici-input>
				<ici-input required v-model="formData.alias_name" :label="$t('别名')"></ici-input>
			</fms-input-group>

			<fms-input-group>
				<ici-icon slot="icon" name="icon-quanqiu" size="20px"></ici-icon>
				<ici-input v-model="formData.country" :label="$t('国家')"></ici-input>
			</fms-input-group>
			<fms-input-group v-for="(item,index) of formData.address" :key="'address'+index">
				<ici-icon slot="icon" name="icon-weizhi" size="20px"></ici-icon>
				<ici-input style="flex:none;width:320px;" v-model="item.address" :label="$t('地址')+(index+1)"></ici-input>
				<ici-input v-model="item.latitude" :label="$t('纬度')"></ici-input>
				<ici-input v-model="item.longitude" :label="$t('经度')"></ici-input>
			</fms-input-group>
			<fms-input-group v-for="(tel,index) of formData.tels" :key="'tels'+index">
				<ici-icon slot="icon" name="icon-telephone" v-if="!index" size="20px"></ici-icon>
				<ici-input v-model="tel.tel" :label="$t('电话')+(index+1)"></ici-input>
			</fms-input-group>
			<fms-input-group v-for="(domain,index) of formData.domain" :key="'domain'+index">
				<ici-icon slot="icon" name="icon-wangzhi" v-if="!index" size="20px"></ici-icon>
				<ici-input v-model="domain.domain" :label="$t('网站')+(index+1)"></ici-input>
			</fms-input-group>
			<fms-input-group>

				<ici-icon slot="icon" name="icon-beizhu" size="20px"></ici-icon>
				<ici-input v-model="formData.remake" :label="$t('备注')"></ici-input>
			</fms-input-group>
			<fms-input-group v-if="formData.outside">
				<ici-icon slot="icon" name="icon-tupian" size="20px"></ici-icon>
				<div class="img-list">
					<div class="bg-icon bg-icon-contain img-item" v-for="(item,index) of imgs" :key="'imgs'+index"
						  :style="`background-image:url(${item.img})`">
						<div class="img-item-inner">
							<ici-button @click="removeImg(index)" size="large" class="img-item-close" type="primary"
											shape="circle" borderless plain>
								<ici-icon name="icon-huishouzhan" size="30px"></ici-icon>
							</ici-button>
						</div>
					</div>
					<div class="addpicbutton" @click="openOutside">
						<ici-icon name="icon-tianjia" size="40px"></ici-icon>
						<br> Add Street View
					</div>
				</div>
			</fms-input-group>
		</div>
		<div slot="footer-right">
			<fms-button class="fms-button" tabindex="0" @click="close">{{$t('关闭')}}</fms-button>
			<fms-button class="fms-button" tabindex="0" :disabled="isLoading" @click="submit">
				{{$t('确认')}}
			</fms-button>
		</div>
	</ici-popup>
</template>

<script>
	import {addCompany} from '../../vue-common/ajax/contact'

	window.companyImgs = [];
	export default {
		name: "addCompany",
		data() {
			return {
				isLoading: false,
				openPopup: false,
				formData: null,
				imgs: window.companyImgs,
			}
		},
		computed: {
			datas() {
				return this.$store.state.injectCustom.content;
			}
		},
		mounted() {
			console.log(this.datas)
			if (typeof this.datas === 'object' && this.datas.company) {
				this.formData = this.datas;
				this.openPopup = true;
			}
		},
		methods: {
			close(reload) {
				this.openPopup = false;
				setTimeout(() => {

					if (reload) {
						window.location.reload()
					} else {
						this.$store.commit('closeInject');
					}

				}, 300)
			},
			submit() {
				if (!funs.trim(this.formData.company)) {
					this.$icimsg.error(this.$t('公司名称不能为空'));
					return;
				}
				var companys = {
					company: this.formData.company,
					alias_name: this.formData.alias_name ? [this.formData.alias_name] : '',
					brands: this.formData.brands,
					domain: this.formData.domain.map((val) => val.domain),
					tels: this.formData.tels.map((val) => val.tel),
					plugin_id: this.formData.plugin_id,
					country: this.formData.country,
					remake: this.formData.remake,
					address: this.formData.address,
					img: this.imgs.map((val) => val.img)
				}
				this.$icimsg.loading(`${this.$t('添加中')}...`)
				this.isLoading = true
				addCompany(companys).then((val) => {
					this.$icimsg.success('Successfully Added');
					this.close(true);

				}).catch((res) => {
					this.$icimsg.error(res.msg);
				}).finally(() => {
					this.isLoading = false;
				})
				console.log(companys);
			},
			openOutside() {
				if (this.formData.outside) {
					window.open(this.formData.outside + '&fms-google-map=1', 'google_outside', 'menubar=no,toolbar=no,resizable=no,location=no,width=900,height=506')
				}
			},
			removeImg(index) {
				this.imgs.splice(index, 1)
			}
		},
		components: {}
	}
</script>

<style lang="less" scoped>
	.img-list {
		display: flex;
		flex-wrap: wrap;
	}

	.img-item {
		flex: none;
		position: relative;
		width: 235px;
		height: 160px;
		background-color: #000;
		margin-bottom: 5px;
		.img-item-inner {
			width: 100%;
			height: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			overflow: hidden;
			background-color: rgba(0, 0, 0, 0);
			transition: all .5s;
			.img-item-close {
				margin-top: 20%;
				opacity: 0;
			}
			&:hover {
				background-color: rgba(0, 0, 0, .4);
				.img-item-close {
					margin-top: 0%;
					opacity: 1;
				}
			}
		}
	}

	.img-list > div:nth-child(2n) {
		margin-left: 5px;
	}

	.addpicbutton {
		cursor: pointer;
		flex: none;
		position: relative;
		width: 235px;
		height: 160px;
		padding-top: 50px;
		line-height: 2em;
		text-align: center;
		color: #999;
		font-size: 1.1em;
		border-radius: 5px;
		background: #eee;
	}
</style>