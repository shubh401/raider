<template>
	<!--新增操作-->
	<div>
		<ici-input-group>
			<div slot="icon" class="fms-input-icon-pic" :style="'background-image:url('+img+')'"></div>
			<ici-input v-model="formData.contact_name" :label="$t('联系人姓名')" :focus="true"></ici-input>
		</ici-input-group>

		<ici-input-group v-show="more">
			<ici-input v-model="formData.first_name" :label="$t('名')"></ici-input>
			<ici-input v-model="formData.last_name" :label="$t('姓')"></ici-input>
		</ici-input-group>

		<ici-input-group overflow>
			<ici-icon slot="icon" name="icon-gongsixinxi1" size="20px"></ici-icon>
			<!--<ici-input v-model="formData.company" :label="$t('公司')"></ici-input>-->
			<companyInput  v-model="formData.company" :label="$t('公司')"></companyInput>

			<contactTitleInput v-model="formData.title" :label="$t('职位')"></contactTitleInput>
		</ici-input-group>

		<ici-input-group overflow>
			<ici-icon slot="icon" name="icon-weizhi" size="20px;"></ici-icon>
			<ici-input v-model="formData.country" :label="$t('国家')"></ici-input>

			<cityInput v-model="formData.city" :label="$t('城市')"></cityInput>
		</ici-input-group>

		<!--email-->
		<ici-input-group v-for="(e,index) of email" :key="'email'+index">
			<ici-icon slot="icon" v-show="!index" name="icon-email" size="20px"></ici-icon>
			<ici-input v-model="e.info" :label="$t('邮箱')"></ici-input>

				<ici-icon slot="handle" name="icon-guanbi"  @click="delInfo(email,index)"></ici-icon>
				<ici-icon slot="handle" name="icon-htmal5icon18" color="rgb(193, 39, 71)"
							 v-show="e.info && email.length==index+1" @click="addInfo(email)">
				</ici-icon>

		</ici-input-group>

		<div v-show="more">

			<!--Phone-->
			<ici-input-group v-for="(e,index) of phone" :key="'phone'+index">
				<ici-icon slot="icon" v-show="!index" name="icon-telephone" size="20px"></ici-icon>
				<ici-input v-model="e.info" :label="$t('手机')"></ici-input>
				<ici-icon slot="handle" name="icon-guanbi" @click="delInfo(phone,index)"></ici-icon>
				<ici-icon slot="handle" name="icon-htmal5icon18" color="rgb(193, 39, 71)"
							 v-show="e.info && phone.length==index+1" @click="addInfo(phone)">
				</ici-icon>
			</ici-input-group>
			<!--wechat-->
			<ici-input-group v-for="(e,index) of wechat" :key="'wechat'+index">
				<ici-icon slot="icon" v-show="!index" name="icon-wechat" size="20px"></ici-icon>
				<ici-input v-model="e.info" :label="$t('微信')"></ici-input>
				<template slot="handle">
					<ici-icon name="icon-guanbi" @click="delInfo(wechat,index)"></ici-icon>
					<ici-icon name="icon-htmal5icon18" color="rgb(193, 39, 71)"
								 v-show="e.info && wechat.length==index+1" @click="addInfo(wechat)">
					</ici-icon>
				</template>
			</ici-input-group>
			<!--linkedin-->
			<ici-input-group v-for="(e,index) of linkedin" :key="'linkedin'+index">
				<ici-icon slot="icon" v-show="!index" name="icon-social-linkedin" size="20px"></ici-icon>
				<ici-input v-model="e.info" label="linkedin"></ici-input>
				<template slot="handle">
					<ici-icon name="icon-guanbi" @click="delInfo(linkedin,index)"></ici-icon>
					<ici-icon name="icon-htmal5icon18" color="rgb(193, 39, 71)"
								 v-show="e.info && linkedin.length==index+1" @click="addInfo(linkedin)">
					</ici-icon>
				</template>
			</ici-input-group>

			<!--facebook-->
			<ici-input-group v-for="(e,index) of facebook" :key="'facebook'+index">
				<ici-icon slot="icon" v-show="!index" name="icon-Facebook" size="20px"></ici-icon>
				<ici-input v-model="e.info" label="facebook"></ici-input>
				<template slot="handle">
					<ici-icon name="icon-guanbi" @click="delInfo(facebook,index)"></ici-icon>
					<ici-icon name="icon-htmal5icon18" color="rgb(193, 39, 71)"
								 v-show="e.info && facebook.length==index+1" @click="addInfo(facebook)">
					</ici-icon>
				</template>
			</ici-input-group>

			<!--twitter-->
			<ici-input-group  v-for="(e,index) of twitter" :key="'twitter'+index">
				<ici-icon slot="icon" v-show="!index" name="icon-twitter2" size="20px"></ici-icon>
				<ici-input v-model="e.info" label="twitter"></ici-input>
				<template slot="handle">
					<ici-icon name="icon-guanbi" @click="delInfo(twitter,index)"></ici-icon>
					<ici-icon name="icon-htmal5icon18" color="rgb(193, 39, 71)"
								 v-show="e.info && twitter.length==index+1" @click="addInfo(twitter)">
					</ici-icon>
				</template>
			</ici-input-group>
		</div>
	</div>
</template>

<script>
	import companyInput from '../../vue-common/components/company-input.vue'
	import cityInput from '../../vue-common/components/city-input.vue'
	import contactTitleInput from '../../vue-common/components/contact-title-input.vue'
	export default {
		name: "newContact",
	   components: {companyInput,cityInput,contactTitleInput},
		data() {
			return {
				focus: false,
				formData: {
					contact_name: '',
					title: '',
					company: '',
					first_name: '',
					last_name: '',
					country: '',
					city: '',
					contact: []
				},
				email: [{type: 'Email', info: ''}],
				phone: [{type: 'Phone', info: ''}],
				wechat: [{type: 'Wechat', info: ''}],
				linkedin: [{type: 'Linkedin', info: ''}],
				facebook: [{type: 'Facebook', info: ''}],
				twitter: [{type: 'Twitter', info: ''}]
			};
		},
		created() {
			this.formData.contact_name = this.contactName;
		},
		watch: {
			contactName(val) {
				console.log('valval',val)
				this.formData.contact_name = val;
			}
		},
		props: {
			contactName: String,
			img: [String, Boolean],
			more: Boolean,
		},
		methods: {
			//添加联系方式
			addInfo(obj) {
				obj.push({
					type: obj[0].info,
					info: ''
				})
			},
			//删除联系方式
			delInfo(obj, index) {
				if (obj.length > 1) {
					obj.splice(index, 1)
				} else {
					obj[0].info = ''
				}
			},
			getInfo() {
				var contacts = [];
				this.email.forEach((val) => {
					console.log(val.info)
					if (val.info && /^\w+@\w+\.\w+$/.test(val.info)) {
						contacts.push(val)
					}
				});
				if (this.more) {
					this.phone.forEach((val) => {
						if (val.info && /^\d+$/.test(val.info)) {
							contacts.push(val)
						}
					});

					this.wechat.forEach((val) => {
						if (val.info && /^\w+$/.test(val.info)) {
							contacts.push(val)
						}
					});

					this.linkedin.forEach((val) => {
						if (val.info && funs.isLinkedin(val.info)) {
							contacts.push(val)
						}
					});

					this.facebook.forEach((val) => {
						if (val.info && funs.isFacebook(val.info)) {
							contacts.push(val)
						}
					});

					this.twitter.forEach((val) => {
						if (val.info && funs.isTwitter(val.info)) {
							contacts.push(val)
						}
					});
				}
				this.formData.contact = contacts;
				return this.formData
			}
		},

	}
</script>

<style scoped>

</style>
