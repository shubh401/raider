<template>
	<div>
		<div class="fms-info-list">
			<div class="fms-info-icon"></div>
			<div class="fms-info-content">{{$t('确认联系')}}</div>
		</div>
		<div class="fms-info-list">
			<div class="fms-info-icon"></div>
			<div class="fms-info-content">
				<div class="fms-info-pic new" :style="'background-image:url('+img+')'"></div>
				<div class="fms-info-pic" v-if="data.header"
					  :style="'background-image:url('+data.header+')'"></div>
			</div>
		</div>

		<div class="fms-info-list">
			<div class="fms-info-icon">
				<ici-icon name="icon-renxiang" color="rgb(193, 39, 71)"></ici-icon>
			</div>
			<div class="fms-info-content">{{data.contact_name}}</div>
		</div>
		<div class="fms-info-list">
			<div class="fms-info-icon">
				<ici-icon name="icon-gongsixinxi1" color="rgb(193, 39, 71)"></ici-icon>
			</div>
			<div class="fms-info-content">
				{{data.title}}
				{{data.title&&data.company?' - ':''}}
				{{data.company}}

			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "addImage",
		data() {
			return {};
		},
		props:{
		  data:Object,
		  img:[String, Boolean],
		},
		 mounted(){

		 },
		methods: {

		},
		components: {}
	}
</script>

<style scoped>

</style>