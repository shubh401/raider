<template>
	<div id="fms-inject" :class="{photographing:googleMap && showAccountButton}">
		<fms-status></fms-status>
		<bgmusic></bgmusic>
		<div v-if="googleMap" class="googlemap" >
			<ici-button class="account" shape="circle" v-show="showAccountButton" size="giant" type="ici" relievo long longshadow="right" @click="addPictures">
				<ici-icon name="icon-paizhao" size="40px" ></ici-icon>
			</ici-button>
		</div>
		<div v-if="inject.show">
			<login v-if="!userInfo" @success="loginSuccess"></login>
			<whoIsThis v-else-if="inject.type==='menu-select-img'"></whoIsThis>
			<addCompany v-else-if="inject.type==='add-company'"></addCompany>
		</div>

	</div>
</template>

<script>
	import whoIsThis from './pages/whoIsThis.vue'; //这是谁
	import bgmusic from './components/fms-bgmusic.vue'
	import login from './pages/login.vue';
	import fmsStatus from './components/fms-status/index.vue'
	import addCompany from './pages/addCompany.vue'

	export default {
		name: "app",
		data() {
			return {
			 showAccountButton:true,
			}
		},
		components: {whoIsThis, login, fmsStatus, bgmusic, addCompany},
		watch: {
			'inject.show'(val) {

				if (val && !this.userInfo) {
					funs.getUserInfo().then((data) => {
						console.log('拿到用户信息', data);
						this.$store.commit('setUserInfo', data);
					});
				}
			}
		},
		created() {
			//获取用户信息
			funs.getUserInfo().then((data) => {
				console.log('拿到用户信息', data);
				this.$store.commit('setUserInfo', data);
			});
			funs.getLanguage().then((data) => {
				this.$store.commit('changeLang', data)
			});
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo;
			},
			inject() {
				return this.$store.state.injectCustom;
			},
			googleMap() {
				return this.$store.state.googleMap
			}
		},
		methods: {
			loginSuccess() {
				console.log('callback', this.inject.callback)
				typeof this.inject.callback == 'function' && this.inject.callback();
			},
			addPictures() {
				this.showAccountButton = false;
				setTimeout(()=>{
					funs.contentScriptPrintscreen().then((res) => {
						this.showAccountButton = true;
						console.log(res);
						window.opener.companyImgs.push({img: res})
					})
				},100)
			}
		}
	}

</script>

<style lang="less">
	@import '../node_modules/ici-ui/lib/ici-ui.min.css';
	.account{
		opacity: .3;
		&:hover{
			opacity: 1;
		}
	}

	.add-company {
		cursor: pointer;
		height: 30px;
		background: #C01639 !important;
		color: #fff !important;
		border: none;
		border-radius: 3px;
		outline: none;
		padding: 0 20px;
		transition: all 0.2s;
		&:hover {
			box-shadow: 1px 1px 5px 0 rgba(0, 0, 0, .5);
		}
		&:active {
			box-shadow: none;
		}
		&:disabled{
			background: #04be02 !important;
			color: #fff !important;
		}
	}

	.fade-enter-active, .fade-leave-active {
		transition: opacity .5s;
	}

	.fade-enter, .fade-leave-to {
		opacity: 0;
	}

	#fms-inject {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: 99999;
		background-color: rgba(255, 255, 255, 0);
		pointer-events: none;
		transition: background-color .5s;
		-webkit-tap-highlight-color: transparent;
		font: 400 15px/20px Roboto, RobotoDraft, Helvetica, Arial, sans-serif;
		//遮罩层
		&.shade {
			pointer-events: auto;
			background-color: rgba(255, 255, 255, .5);
		}

		a {
			color: rgb(193, 39, 71);
			text-decoration: none;
			&:hover {
				color: rgb(170, 36, 68);
				text-decoration: none;
			}
			&:active {
				color: rgb(146, 32, 57);
			}
		}
		.fms-iconfont {
			display: inline-block;
		}
		* {
			box-sizing: border-box !important;
		}
	}

	.bg-icon {
		background: #fff no-repeat center;
		background-size: cover;
	}
	.bg-icon-contain{
		background-size: contain !important;
	}

	.fms-info-list {
		padding: 10px 25px 0px;
		display: flex;
		.fms-info-icon {
			text-align: right;
			width: 30px;
			flex: none;
			padding: 0 10px
		}
		.fms-info-content {
			flex: auto;
		}
		.fms-info-pic {
			position: relative;
			display: inline-block;
			width: 50px;
			height: 50px;
			background: no-repeat bottom;
			border: 1px solid #eee;
			background-size: contain;
			&.new:before {
				content: 'newed';
				text-align: center;
				width: 100%;
				font-size: 9px;
				line-height: 9px;
				position: absolute;
				display: inline-block;
				background: rgb(193, 39, 71);;
				top: 0;
				left: 0;
				padding: 2px 0;
				color: #fff;
			}
		}
	}

	.popup-enter-active, .popup-leave-active {
		transition: all .3s cubic-bezier(.8, 0.0, 0.2, 1) !important;
	}

	.popup-enter, .popup-leave-to {
		opacity: 0 !important;
		visibility: hidden !important;
		transform: scale(.8) !important;
	}

	.popup-enter-to {
		opacity: 1 !important;
		visibility: visible !important;
		transform: scale(1) !important;
	}

	.googlemap {
		position: fixed;
		top: 50%;
		margin-top:-37px;
		right: 15px;
		pointer-events: auto;
		z-index: 9999999;
	}
	.photographing{
		-webkit-animation: photographing .5s ease-in-out;
		-o-animation: photographing .5s ease-in-out;
		animation: photographing .5s ease-in-out;
	}
	@keyframes photographing {
		0% {background:rgba(255,255,255,0)}
		25% {background:rgba(255,255,255,.5)}
		50% {background:rgba(255,255,255,1)}
		75% {background:rgba(255,255,255,.5)}
		100% {background:rgba(255,255,255,0)}
	}
</style>