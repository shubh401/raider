/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function() {
    function translate(key) {
        return chrome.i18n.getMessage(key);
    }

    function translateHtml() {
        var els = document.querySelectorAll('[data-i18n]');

        [].forEach.call(els, function (el) {
            el.innerText = translate(el.getAttribute('data-i18n'));
        });
    }

    translateHtml();

    return {
        'translate': translate,
        'translateHtml': translateHtml
    };
}();


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(2);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

/* global isValidNumber, $, URI, browser, msBrowser, chrome: true */
var Translator = __webpack_require__(0);

function AntBuddy(){}

var reUnescapedHtml = /[&<>"']/g;
var htmlEscapes = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  '\'': '&#39;',
  '/': '&#x2F;'
};

function escapeCallback (key) { return htmlEscapes[key]; }
function replaceNotNumber (number) { return number.replace(/\D/g,''); }

AntBuddy.browserType = '';

AntBuddy.intl_regex = /(\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7)[0-9. -]{4,14})(?:\b|x\d+)/g;
AntBuddy.domestic_regex = /(?:\b|(?:((?:\b|\+)1)[. -]?)|\()(\d{3})\)?[. -]?(\d{3})[. -]?(\d{4})(?:\b|x\d+)/g;

AntBuddy.broad_regex = /(\+?[0-9][0-9. ()-]{1,25}[0-9])(?:\b|x\d+)/g;
AntBuddy.defaultPrefix = '+84';

AntBuddy.callVia = function(){
  return localStorage.getItem('call_via');
};

AntBuddy.useBruteforce = function(){
  return localStorage.getItem('deep_detect') === 'yes';
};

AntBuddy.bruteforceExceptions = function(){
  try{
    return JSON.parse(localStorage.getItem('exceptions'));
  }catch(err){
    console.log('handled bruteforcexception error');
    chrome.storage.local.set({
      exceptions: AntBuddy.DEFAULT_SETTINGS.exceptions
    }, function(){});
    return JSON.parse(AntBuddy.DEFAULT_SETTINGS.exceptions);
  }
};

AntBuddy.numberValidator = function(number){
  var normalizePhone = function (phone, default_prefix) {
    if (/^\+/.test(phone)) return phone;
    if (/^00/.test(phone)) return phone.replace(/^00/g, '+');
    if (/^0/.test(phone)) return phone.replace(/^0/g, default_prefix);
    return default_prefix + phone;
  };
  var normalized_phone = normalizePhone(number, AntBuddy.defaultPrefix);
  return isValidNumber(number, 'VN') || isValidNumber(normalized_phone, 'VN');
};

AntBuddy.MIDDLE_BUTTON = 1;
AntBuddy.COOKIE = '';
AntBuddy.BASE_URL = 'https://antbuddy.com';
AntBuddy.BASE_BEEIQ_URL = 'https://beeiq.co';

AntBuddy.DEFAULT_SETTINGS = {
  call_via: 'antbuddy-web',  
  deep_detect: 'yes',
  exceptions: JSON.stringify([
    'docs.google.com'
  ])
};

AntBuddy.CHROME_APP_ID = 'idbejgmlldkhoiogoknpihhhbimbikdo';
AntBuddy.placeCall = function(options) {
  if (options.number) {
    options.number = replaceNotNumber(options.number);
  }
  switch (AntBuddy.callVia()) {
    case 'desktop-app':
      AntBuddy.placeCallOnElectronApp(options);
      break;
    case 'antbuddy-web':
      AntBuddy.placeCallOnAntBuddyWeb(options);
      break;
    case 'beeiq-web':
      AntBuddy.placeCallOnBeeIQWeb(options);
      break;
    default:
      AntBuddy.placeCallOnApp(options, function (response) {
        if (!response) {
          AntBuddy.placeCallOnAntBuddyWeb(options);
        }
      });
  }
};

AntBuddy.placeCallOnElectronApp = function (options) {
  chrome.tabs.query(
    {
      currentWindow: true,
      active : true
    },
    function (tabArray) {
      chrome.tabs.update(
        tabArray[0].id,
        {
          url: 'ab+tel:' + options.number.replace(/ /g, ''),
          active: true
        }, function(tab) {
          console.log(tab);
        }
      );
    }
  );
};

AntBuddy.placeCallOnApp = function (options, callback) {
  const message2 = {
    type: 'call',
    name: options.name,
    number: options.number,
    externalId: options.externalId,
    integration: options.integration
  };
  chrome.runtime.sendMessage(AntBuddy.CHROME_APP_ID, message2, callback);
};

AntBuddy.placeCallOnAntBuddyWeb = function (options) {
  var antbuddyProduction = 'https://*.antbuddy.com/app*';
  chrome.tabs.query({url: antbuddyProduction}, function(tabs) {
    if(!tabs || tabs.length===0) {
      AntBuddy.createNewTab(options.number, options.focus);
      return;
    }
    
    tabs.forEach(function(tab) {
      if(tab.url.indexOf('/app#!/chat')>0) {            
        //call to tab
        AntBuddy.sendMessage(tab, {
          number: options.number,
          app: 'browser'
        });
        AntBuddy.focusTab(tab.id);
        return false;
      }
    });
  });
};

AntBuddy.placeCallOnBeeIQWeb = function (options) {
  var beeIQProduction = 'https://*.beeiq.co/b*';
  chrome.tabs.query({url: beeIQProduction}, function(tabs) {
    if(!tabs || tabs.length===0) {
      AntBuddy.createNewTab(options.number, options.focus);
      return;
    }

    tabs.forEach(function(tab) {
      if(tab.url.indexOf('/b/#/app')>0) {
        AntBuddy.sendMessage(tab, {
          number: options.number,
          app: 'browser'
        });
        AntBuddy.focusTab(tab.id);
        return false;
      }
    });
  });
};

AntBuddy.sendMessage = function (tab, msg) {
  chrome.tabs.sendMessage(tab.id, msg, function(response) {
    console.log(response);
  });
};

AntBuddy.focusTab = function (tabId) {
  chrome.tabs.update(tabId, {active: true}, function() {
    
  });      
};

AntBuddy.notifyCtiVisibility = function (options) {
  const message1 = {
    type: 'cti-visibility',
    isVisible: options.isVisible,
    integration: options.integration
  };
  chrome.runtime.sendMessage(AntBuddy.CHROME_APP_ID, message1);
};

AntBuddy.callHandler = function(event) {
  var callVia = AntBuddy.callVia();
  if(callVia==='desktop-app') {
    return true;
  }
  event.preventDefault();
  var number = $( event.target ).closest('a')[0].text;
  var background = event.metaKey || event.button == AntBuddy.MIDDLE_BUTTON;
  if (AntBuddy.browserType === 'chrome') {
    chrome.extension.sendMessage({type: 'call', number: number, focus: !background}, console.log);
  } else {
    browser.runtime.sendMessage({type: 'call', number: number, focus: !background});
  }
};

AntBuddy.callLink = function(number) {
  var callVia = AntBuddy.callVia();
  var link = 'href="javascript:;"';
  if(callVia==='desktop-app') {
     link = 'href="ab+tel:'+number.replace(/ /g, '') + '"';
  }
  var icon_url = chrome.extension.getURL('icons/icon-32.png');
  var callLink = '<a class="ab-tooltip antbuddy_phone" data-tooltip="'+ Translator.translate('callViaAntBuddy')+'" ' + link + '>';
  if(localStorage.getItem('logo') === 'visible') {
    callLink += '<img alt="AB:" class="antbuddy_icon" src="'+icon_url+'">';
  }
  return callLink + number.replace(reUnescapedHtml, escapeCallback) + '</a>';
};

AntBuddy.updateExistingTab = function(id, windowId, url, number, focus) {
  url = URI.expand(URI(url).hash('!/chat/makecall/{number}').toString(), {'number': number}).toString();

  chrome.tabs.update(id, {url: url, active: focus}, function(result) {
    console.log(result);
  });
  if (focus) {
    chrome.windows.update(windowId, {focused: true}, function(result) {
      console.log(result);
    });
  }
};

AntBuddy.openSessionTab = function(url, number, focus) {
  var account = AntBuddy.accountFromDomain(url);
  var baseURL = AntBuddy.baseURL(account);
  var externalURL = AntBuddy.externalURL(baseURL, number);
  chrome.tabs.create({url: externalURL, active: focus}, function(result) {
    console.log(result);
  });
};

AntBuddy.createNewTab = function(number, focus) {
  var baseURL = AntBuddy.baseURL('');
  var externalURL = AntBuddy.externalURL(baseURL, number);
  chrome.tabs.create({url: externalURL, active: focus}, function(result) {
    console.log(result);
  });
};

AntBuddy.externalURL = function(baseURL, number) { 
  var launchpadURL = '';
  switch(AntBuddy.callVia()) {
    case 'antbuddy-web':
      launchpadURL = 'launchpad';
      break;
    case 'beeiq-web':
      launchpadURL = 'b/#/page/launchpad';
      break;
    default:
      launchpadURL = 'launchpad';
  }
  console.log(number);
  return URI([baseURL, launchpadURL].join('')).toString();
};

AntBuddy.baseURL = function(account) {

  var baseUrl = '';
  switch (AntBuddy.callVia()) {
    case 'antbuddy-web':
      baseUrl = AntBuddy.BASE_URL;
      break;
    case 'beeiq-web':
      baseUrl = AntBuddy.BASE_BEEIQ_URL;
      break;
    default:
      baseUrl = AntBuddy.BASE_URL;
  }
  return URI(baseUrl).subdomain(account).toString();
};

AntBuddy.accountFromDomain = function(domain) {
  return AntBuddy.accountFromURL(URI({protocol: 'https', hostname: domain}));
};

AntBuddy.accountFromURL = function(url) {
  return URI(url).subdomain();
};

AntBuddy.addOnMessageListener = function(request, sender, sendResponse) {
  switch (request.type) {
    case 'call':
      AntBuddy.placeCall(request);
      break;
    case 'cti-visibility':
      AntBuddy.notifyCtiVisibility(request);
      break;
  }
  sendResponse(request);
};

AntBuddy.initialize = function(continueThere){
  // mirror chrome local storage to browser local storage
  //  so that accesses to local storage can be syncronous
  // edge
  var browserType;
  if (!AntBuddy.browserType) {
    if (typeof chrome === 'undefined' || (typeof chrome !== 'undefined' && !chrome.runtime)) {
      if (typeof msBrowser !== 'undefined') {
        chrome = msBrowser;
      } else if (typeof browser !== 'undefined') {
        chrome = browser;
      }
      browserType = 'edge';
      $('body').attr('data-ab-ext-id', browser.runtime.id);
    } else {
      if (chrome.runtime.getManifest().applications) {
        // firefox
        browserType = 'firefox';
      } else {
        // chrome/opera
        browserType = 'chrome';
      }
      $('body').attr('data-ab-ext-id', chrome.runtime.id);
      $('body').attr('data-ab-ext-version', chrome.runtime.getManifest().version);
    }
    AntBuddy.browserType = browserType;
  } else {
    browserType = AntBuddy.browserType;
  }

  if (['chrome'].indexOf(browserType) >= 0) {
    chrome.storage.local.get(function(options) {
      if($.isEmptyObject(options)) {
        options = AntBuddy.DEFAULT_SETTINGS;
      }
  
      $.each(options, function(key, value) {
        localStorage.setItem(key,value);
      });
      continueThere();
    });
  
    chrome.storage.onChanged.addListener(function(changes) {
      $.each(changes, function(key, value) {
        localStorage.setItem(key, value.newValue);
      });
    });
  } else if (['edge', 'firefox'].indexOf(browserType) >= 0) {
    browser.storage.local.get(function(options) {
      if($.isEmptyObject(options)) {
        options = AntBuddy.DEFAULT_SETTINGS;
      }
  
      $.each(options, function(key, value) {
        localStorage.setItem(key,value);
      });
      continueThere();
    });
  
    browser.storage.onChanged.addListener(function(changes) {
      $.each(changes, function(key, value) {
        localStorage.setItem(key, value.newValue);
      });
    });
  }
};

$(document).ready(function() {
  AntBuddy.initialize(function(){});
});

window.AntBuddy = AntBuddy;


/***/ })
/******/ ]);