/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(1);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

// if you checked "fancy-settings" in extensionizr.com, uncomment this lines

// var settings = new Store("settings", {
//     "sample_setting": "This is how you use Store.js to remember values"
// });


//example of using a message handler from the inject scripts
var self = this;

self.widgets = {};

var defaultIntegrationUrls = {
  zendesk: ["*://*.zendesk.com/agent/*"],
  salesforce: ["*://*.salesforce.com/*", "*://*.lightning.force.com/*"],
  desk: ["*://*.desk.com/web/*"]
}

function getIntegrationUrls (integrationUrls, integration) {
  if(!integration || !integrationUrls) return defaultIntegrationUrls

  const urls = {}
  urls[integration] = integrationUrls
  return urls
}

function getIntegrationTabs (callback, integration, integrationUrlsList) {
  var integrationUrls = getIntegrationUrls(integrationUrlsList, integration)
  var urls

  if (integration) {
    urls = integrationUrls[integration]
  } else {
    urls = Object.keys(integrationUrls).reduce(function (prev, key) {
      return prev.concat(integrationUrls[key])
    }, [])
  }

  chrome.tabs.query({ url: urls }, callback)
}

function sendMessageToTab (tabId, data) {
  chrome.tabs.sendMessage(tabId, JSON.stringify(data))
}

function getActiveTab (tabs, callback) {
  var tab = tabs.find(function isTabActive(tab) {
    return tab.active
  })

  if (!tab) {
    tab = tabs[0]
    chrome.tabs.update(tab.id, {
      active: true
    }, callback)
  } else {
    callback(tab)
  }
}

function openContactProfile (contact) {
  const integrationUrls = contact.integrationUrls
  var integration = contact.integration || 'salesforce'

  getIntegrationTabs(function (tabs) {
    if (tabs.length === 0 && contact.externalUrl) {
      contact.externalUrl && chrome.tabs.create({url: contact.externalUrl})
      return
    }

    getActiveTab(tabs, function (tab) {
      sendMessageToTab(tab.id, {
        type: 'open-profile',
        contact: contact
      })
    })
  }, integration, integrationUrls)
}

function notifyCallbarVisibility (payload) {
  getIntegrationTabs(function (tabs) {
    tabs.forEach(function (tab) {
      sendMessageToTab(tab.id, {
        type: 'callbar-visibility',
        isVisible: payload.isVisible
      })
    })
  })
}

function openTicket (ticket) {
  getIntegrationTabs(function (tabs) {
    getActiveTab(tabs, function (tab) {
      sendMessageToTab(tab.id, {
        type: 'open-ticket',
        payload: ticket
      })
    })
  }, ticket.integration, ticket.integrationUrls)
}

setTimeout(function() {
  if (AntBuddy.browserType === 'chrome') {
    chrome.extension.onMessage.addListener(
      function(request, sender, sendResponse) {
        AntBuddy.addOnMessageListener(request, sender, sendResponse);
      }
    );
    chrome.runtime.onMessageExternal.addListener(
      function(request, sender, sendResponse) {
        console.log(sender);
        if (request.message == "hello") {
          self.url = request.popup_url;
          self.widgets[sender.tab.id] = sender.tab.url;
          Talkforce.openPopup(self.url);
          sendResponse(true);
        } else if (request.type === 'open-contact') {
          openContactProfile(request.contact)
        } else if (request.type === 'callbar-visibility') {
          notifyCallbarVisibility(request.payload)
        } else if (request.type === 'open-ticket') {
          openTicket(request.payload)
        }
      });
    
    chrome.tabs.onRemoved.addListener(
      function(tabId) {
        console.log("Closing tab with ID: " + tabId);
        if (self.url) {
          delete self.widgets[tabId];
    
          var existing = Object.keys(self.widgets).length;
          if (Talkforce.isPopupTab(tabId)) {
            Talkforce.popupClosed(self.url);
    
            if (existing > 0) {
              console.log('Re-opening popup for existing widgets: ' + existing);
              Talkforce.openPopup(self.url);
            }
          } else if (existing === 0) {
            console.log('Closing popup as no more widgets exist');
            Talkforce.closePopup(self.url);
          }
        }
      });
    
    chrome.runtime.onConnectExternal.addListener(function(port) {
      var tabId = port.sender.tab.id;
      if (Talkforce.isPopupTab(tabId)) {
        console.log('Received connection from popup tab: ' + tabId);
      }
    
      port.onDisconnect.addListener(function() {
        console.log("Popup is about to close: " + tabId);
      });
    });
    
  } else if (['edge', 'firefox'].indexOf(AntBuddy.browserType) >= 0) {
    browser.runtime.onMessage.addListener(function(request, sender, sendResponse) {
      AntBuddy.addOnMessageListener(request, sender, sendResponse);
    });
  }
}, 1000);

/***/ })
/******/ ]);