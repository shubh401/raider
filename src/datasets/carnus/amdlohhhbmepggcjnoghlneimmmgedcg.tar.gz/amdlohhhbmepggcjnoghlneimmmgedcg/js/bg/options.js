/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(3);


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

var Translator = __webpack_require__(4);
var AntBuddy = window.AntBuddy;

var OptionPanel = function() {
  function init() {
    initUI();
    addEvents();

  }

  function initUI() {
    restore_options();

    // initialize tags manager
    $(".tm-input").tagsManager({
      //prefilled: ["Pisa", "Rome"],
      CapitalizeFirstLetter: false,
      AjaxPush: null,
      AjaxPushAllTags: null,
      AjaxPushParameters: null,
      delimiters: [9, 13, 44],
      backspace: [8],
      blinkBGColor_1: '#FFFF9C',
      blinkBGColor_2: '#CDE69C',
      hiddenTagListName: 'hiddenTagListA',
      hiddenTagListId: null,
      deleteTagsOnBackspace: true,
      tagsContainer: null,
      tagCloseIcon: 'x',
      tagClass: '',
      validator: null,
      onlyTagList: false
    });
  }

  function addEvents() {    
    $('#dd-deep-detect').change(on_deep_detect_change);
    $('#save').click(save_options);
  }

  function restore_options() {
    chrome.storage.local.get(AntBuddy.DEFAULT_SETTINGS, function (items) {
      $('#dd-call-via').val(items.call_via);      
      $('#dd-deep-detect').val(items.deep_detect);
      on_deep_detect_change(); 
      fill_exceptions(JSON.parse(items.exceptions));
    });
  }

  function on_deep_detect_change() {
    var selected = $('#dd-deep-detect').val();
    if (selected === "no") {
        $("#exceptions").hide();
    }
    if (selected === "yes") {
        $("#exceptions").show();
    }
    console.log('3:' + $('#dd-deep-detect').val())
  }

  function save_options() {
    var call_via = $('#dd-call-via').val();    
    var deep_detect = $('#dd-deep-detect').val();
    var exceptions = $(".tm-input").tagsManager('tags');
    console.log('call_via: ', call_via);    
    console.log('deep_detect: ', deep_detect);
    console.log('exceptions: ', exceptions);

    chrome.storage.local.set({
        call_via: call_via,       
        deep_detect: deep_detect,
        exceptions: JSON.stringify(exceptions),
    }, function (err) {
        var msg = '';
        var msgContainer = $('#save-message');

        msgContainer
          .removeClass('alert-error')
          .removeClass('alert-success');

        if(err) {
          msg = Translator.translate('saveErrorMsg');
          msgContainer.addClass('alert-error');
        }else {
          msg = Translator.translate('saveSuccessMsg');
          msgContainer.addClass('alert-success');
        }

        msgContainer          
          .text(msg)
          .show();
        setTimeout(function () {
          msgContainer.hide();
        }, 3000);
    });
  }

  function fill_exceptions(exceptions) {
    var wrapper = $(".tm-input");
    for (var i = 0; i < exceptions.length; i++) {
        wrapper.tagsManager('pushTag', exceptions[i]);
    }
  }

  return {
    'init': init
  }
}();

$(document).ready(function () {    
  OptionPanel.init();  
  Translator.translateHtml();
});

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function() {
    function translate(key) {
        return chrome.i18n.getMessage(key);
    }

    function translateHtml() {
        var els = document.querySelectorAll('[data-i18n]');

        [].forEach.call(els, function (el) {
            el.innerText = translate(el.getAttribute('data-i18n'));
        });
    }

    translateHtml();

    return {
        'translate': translate,
        'translateHtml': translateHtml
    };
}();


/***/ })
/******/ ]);