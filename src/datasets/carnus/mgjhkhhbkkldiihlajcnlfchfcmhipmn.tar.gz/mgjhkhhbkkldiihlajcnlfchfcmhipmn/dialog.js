/*
TruePath: XPath On Click
Version: 0.04
Owner: Sumit Ghosh
Email: ghosh.sumit1@gmail.com
All rights reserved @ 2018. 
*/
var browser_version="NA";
var browser_name="NA";

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-121369733-1']);
var ga = document.createElement('script'); 
ga.type = 'text/javascript'; 
ga.async = true;
ga.src = 'https://ssl.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; 
s.parentNode.insertBefore(ga, s);


var trackEvent = function (eventCategory, eventAction) {
let request = new XMLHttpRequest();
request.open("POST", "https://www.google-analytics.com/collect", true);
let message =
  "v=1&tid=" + "UA-121369733-1" + "&cid= " + "04ae650d-23cf-47a6-93bd-a2380776f882" + "&aip=1" +
  "&ds=add-on&t=event&ec="+eventCategory+"&ea=" + eventAction;
request.send(message);
}

var trackPage = function () {
let request = new XMLHttpRequest();
request.open("POST", "https://www.google-analytics.com/collect", true);
let message =
  "v=1&tid=" + "UA-121369733-1" + "&cid= " + "04ae650d-23cf-47a6-93bd-a2380776f882" + "&aip=1" +
  "&ds=add-on&t=pageview&dp="+"dialog.html"+"&dt="+"TruePath-Home";
request.send(message);
}

function setDOMInfo(info) {
	browser_name=info[1];
	browser_version=info[2];
	if (browser_version>55 && browser_name==='Firefox' ){
		trackPage();
	}
	else{
	_gaq.push(['_trackPageview']);
	}
   document.getElementById('total').textContent   = info[0];
   document.getElementById('serenity').textContent   = "@FindBy(xpath = "+"\""+info[0]+"\")";
   
   if (info[4]!='na'){
	   newItemLabel();
   }
      
   if (info[3]!='na'){
	   newItemTextArea(info[3]);
   }
   addHelpTextElement();
   addBetaTextElement();
 }

window.addEventListener('DOMContentLoaded', function () {
    chrome.runtime.sendMessage(
        {from: 'popup', subject: 'DOMInfo'},
        setDOMInfo);
	document.querySelector("#copy").addEventListener("click", copy);
	document.querySelector("#copySerenityBtn").addEventListener("click", copySerenity);
  });
    
  function copy() {
  var copyText = document.querySelector("#total");
  copyText.select();
  document.execCommand("copy");
    if (browser_version>55 && browser_name==='Firefox' ){
		trackEvent("NormalXPathCopy", "clicked");
	}
	else {
		_gaq.push(['_trackEvent', 'NormalXPathCopy', 'clicked']);
	}
   setTimeout(function(){ window.opener = self; window.close() }, 100);
}

 function copySerenity() {
  var copyText = document.querySelector("#serenity");
  copyText.select();
  document.execCommand("copy");
     if (browser_version>55 && browser_name==='Firefox' ){
		trackEvent("PageObjectXPathCopy", "clicked");
	}
	else {
		_gaq.push(['_trackEvent', 'PageObjectXPathCopy', 'clicked']);
	}
  setTimeout(function(){ window.opener = self; window.close() }, 100);
}


function newItemLabel(){
    var para = document.createElement("text");
    var t1 = document.createTextNode("Above XPath is inside Frame.")
	var t2 = document.createTextNode(" The url  of Frame: ")
	para.style.color = "Yellow";
    para.appendChild(t1);
	para.appendChild(t2);
    document.body.appendChild(para);
}

function newItemTextArea(urlIFrame){
    var para = document.createElement("textarea");
    var t1 = document.createTextNode(urlIFrame);
	para.style.color = "White";
	para.style.background = "#395697";
	para.style.height = 'Auto';
    para.style.width = 350+'px';
	para.appendChild(t1);
    document.body.appendChild(para);
}

function addHelpTextElement(){
	var divElement = document.createElement("div");
	var para = document.createElement("span");
    var t1 = document.createTextNode("For Help and Tips: ")
	para.style.color = "White";
    para.appendChild(t1);
	var helpLink = document.createElement("a");
	helpLink.innerHTML="click here";
	helpLink.setAttribute("href","http://qaworld.ga/truepath");
	helpLink.style.color = "White";
	helpLink.setAttribute("target","_blank");
		
	document.body.appendChild(divElement).appendChild(para).appendChild(helpLink);
}


function addBetaTextElement(){
    var divElement = document.createElement("div");
    var t1 = document.createTextNode("@Beta Version.")
	divElement.style.color = "White";
    divElement.appendChild(t1);
    document.body.appendChild(divElement);
}