/*
TruePath: Xpath On Click
Version: 0.04
Owner: Sumit Ghosh
Email: ghosh.sumit1@gmail.com

All rights reserved @ 2018. 
*/

var parent = chrome.contextMenus.create({"title": "Relative XPath", "contexts":["all"]});
var oldValue = [];
var menuID;
var iFrame;
var browser_version="NA";
var browser_name="Chrome";
var compositeDataTracker = []; 
var iFrameUrl;
var isInFrame;
var details=[];

try{
if(browser.runtime.getBrowserInfo!==undefined) {
	browser.runtime.getBrowserInfo().then((info) => {
		browser_name=info.name;
		browser_version = info.version.split(".")[0];
	}
	);
}
}
catch(err){}

var showInfo = function (xpath) {
	iFrameUrl=xpath[3];
	isInFrame=xpath[4];
	removeOldMenuItems();	
	if (browser_version>55 && browser_name==='Firefox' ){
		uniqueXpath(xpath);
	}
	else{		
		createMenuItemsOldVersion(xpath);		
	}
}


var showIFrameInfo = function (xpath) {
	removeOldMenuItems();
	if (browser_version>55 && browser_name==='Firefox'){
		iFrame = chrome.contextMenus.create({"title": "Clicked on iFrame can't generate XPath now", "icons": {"64": "unProcess.png"}, "parentId": parent,  "contexts":["all"]});
	}
	else{		
		iFrame = chrome.contextMenus.create({"title": "Clicked on iFrame can't generate XPath now","parentId": parent,  "contexts":["all"]});		
	}
	oldValue.push(iFrame);
}

var removeOldMenuItems=function(){
		if (oldValue.length>0){
			try{
			for (var i=0; i<oldValue.length; i++){
			chrome.contextMenus.remove(oldValue[i]);
			}
			}
			catch(err){}
	}
}

var uniqueXpath = function (xpath) {
	for (var i=0; i<xpath[0].length;i++){		
		 threeStar = chrome.contextMenus.create({"title": xpath[0][i], "icons": {"64": "threeStar.png"}, "parentId": parent, "id": xpath[0][i]});
		 oldValue.push(threeStar);
		}
	
	if ((xpath[0].length>0) && (xpath[1].length>0)) { createSeparator();}
	
	for (var i=0; i<xpath[1].length;i++){		
		 twoStar = chrome.contextMenus.create({"title": xpath[1][i], "icons": {"64": "twoStar.png"}, "parentId": parent, "id": xpath[1][i]});
		 oldValue.push(twoStar);
		}
		
	if ((xpath[1].length>0) && (xpath[2].length>0)) { createSeparator();}
	
	if ((xpath[2].length>0) && (xpath[0].length>0) && (xpath[1].length==0)) { createSeparator();}
	
	for (var i=0; i<xpath[2].length;i++){		
		 oneStar = chrome.contextMenus.create({"title": xpath[2][i], "icons": {"64": "oneStar.png"}, "parentId": parent, "id": xpath[2][i]});
		 oldValue.push(oneStar);
		}
}

var createMenuItemsOldVersion = function (xpath) {
	var threeStarlenght=xpath[0].length;
	var twoStarlenght=xpath[1].length;
	var oneStarlenght=xpath[2].length;	
		
	if (twoStarlenght>0){
		twoStarMenu = chrome.contextMenus.create({"title": "XPath with id, href, src...", "parentId": parent, "contexts":["all"]});
		for (var i=0; i<twoStarlenght;i++){		
		twoStar =chrome.contextMenus.create({"title": xpath[1][i], "parentId": twoStarMenu, "id": xpath[1][i], "contexts":["all"]});
		}
		oldValue.push(twoStarMenu);
	}
	
	if ((threeStarlenght>0) && (twoStarlenght>0)) { createSeparator();}
	
	if (threeStarlenght>0){
		threeStarMenu = chrome.contextMenus.create({"title": "XPath with class, name, title...", "parentId": parent, "contexts":["all"]});
		for (var i=0; i<threeStarlenght;i++){		
		threeStar = chrome.contextMenus.create({"title": xpath[0][i], "parentId": threeStarMenu, "id": xpath[0][i], "contexts":["all"]});
		}
		oldValue.push(threeStarMenu);
	}
	
	if ((threeStarlenght>0) && (oneStarlenght>0)) { createSeparator();}
	
	if ((twoStarlenght>0) && (oneStarlenght>0) && (threeStarlenght==0)) { createSeparator();}
	
	if (oneStarlenght>0){
		oneStarMenu = chrome.contextMenus.create({"title": "XPath with index", "parentId": parent, "contexts":["all"]});
		for (var i=0; i<oneStarlenght;i++){
		oneStar = chrome.contextMenus.create({"title": xpath[2][i], "parentId": oneStarMenu, "id": xpath[2][i], "contexts":["all"]});
		}
		oldValue.push(oneStarMenu);
	}
}

var createSeparator=function(){
	separatorKey=chrome.contextMenus.create({ type: "separator", "parentId": parent, contexts: ["all"]});
	oldValue.push(separatorKey);
}

chrome.contextMenus.onClicked.addListener(copyToClipboard);

function copyToClipboard(data, tab) {
	var w = 430;
    var h = 360;
    var left = (screen.width/2)-(w/2);
    var top = (screen.height/2)-(h/2); 
	if (Number.isInteger(data.menuItemId)) { 
	    chrome.windows.create({
				 url: chrome.extension.getURL('warning.html'),
                 type: 'popup', width: w, height: h, left: left, top: top
            });
	}
	else{
    chrome.windows.create({
				 url: chrome.extension.getURL('dialog.html'),
                 type: 'popup', width: w, height: h, left: left, top: top
            });
			
	saveClickMenuInfo(data);		
	}
}

var saveClickMenuInfo = function (xpath) {
menuID=xpath.menuItemId;
if (compositeDataTracker.length>0){compositeDataTracker=[]}
compositeDataTracker.push(menuID);
compositeDataTracker.push(browser_name);
compositeDataTracker.push(browser_version);
compositeDataTracker.push(iFrameUrl);
compositeDataTracker.push(isInFrame);
}
chrome.runtime.onMessage.addListener(function (msg, sender, response) {
  if ((msg.from === 'popup') && (msg.subject === 'DOMInfo')) {
		response(compositeDataTracker);
  }
  else if (msg.messagePass === 'iframe'){
	  showIFrameInfo(msg);
  }
  else
  {
	  showInfo(msg);
  }
});
