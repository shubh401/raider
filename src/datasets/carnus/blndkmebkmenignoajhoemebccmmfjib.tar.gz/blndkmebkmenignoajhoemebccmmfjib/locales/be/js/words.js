// Belarusian
var EXT_LOCALE = "be";

var WORDS = {
	// popup
	btnTranslate:				"Перакласці",
	btnClear:					"Выдаліць",
	txtUse:						"выкарыст.:",
	txtBackTranslation:			"адваротны пераклад",
	hntFullExchange:			"Shift-Click – змяніць месцамі разам з тэкстам",
	hntTranslate:				"Ctrl-Enter – перакласці",
	hntReTranslate:				"Shift-Change – перакласці абраным сэрвісам",
	txtTranslateActivePage:		"Перакласці актыўную старонку",
	optAutoDetect:				"Аўтавызнач.",
	lnkSettingsPage:			"налады",

	txtUnregisteredMode:		"**Незарэгістраваны рэжым**",
	txtUnregisteredModeDetails:	"**Незарэгістраваны рэжым дапамагае перакладаць толькі словы**\nПасля рэгістрацыі ты робішся ўладальнікам прахону да:\n- гэта апавяданне знікне і магчыма, дадатковая рэклама ў пошукавых сістэмах;\n- функцыя чытача тэкста, адваротны пераклад, тэставы рэжым для ўправаджэньня Японскай і Карэйскай мовы;\n- будучыя новыя функцыі.\n\nкалі нічога з вышпералічанага не патрабуецца, рэгістрацыя не патрэбна.",
	txtVerify:					"Зарэгістраваць",

	cmTranslateIt:				"Перакласці",
	cmTranslatePage:			"Перакласці старонку",

	// services
	byGoogle:					"Google Пераклад",
	byBing:						"Bing Перакладчык",
	byYandex:					"Яндекс.Пераклад",
	byPromt:					"Promt Перакладчык",
	byPragma:					"Pragma Перакладчык",
	byBaidu:					"Baidu Перакладчык",
	byBabylon:					"Babylon Перакладчык",
	byBabylonDictionaries:		"Слоўнікі ад Babylon",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL Перакладчык",

	tbByGoogle:					"от Google Пераклад",
	tbByBing:					"от Bing Перакладчык",
	tbByYandex:					"от Яндекс.Пераклад",
	tbByPromt:					"от Promt Перакладчык",

	// dictionary
	txtDictionary:				"слоўнік",
	linkRemove:					"выдаліць",
	txtUsePersonalDictionary:	"Скарыстацца асабістым слоўнікам",
	txtShow:					"паказаць",
	txtHide:					"схаваць",

	// options
	txtOptionsTitle:			"Translator - налады",
	txtMadeBy:					"Распрацавана",
	linkFeedback:				"паведаміць аб памылке / адваротная сувязь",
	hdrDefaultSourceLang:		"Мова бяздзейнасці, з якой будзе перекладацца тэкст",
	hdrDefaultTargetLang:		"Мова бяздзейнасці,з якой будзе перекладацца тэкст",
	hdrMaxStoredLangPairs:		"Максімальная колькасць скарыстаных пар моў якія трэба захоўваць",
	hdrTranslateBtnPosition:	"Знаходжанне кнопкі \"Перакласці\"",
	txtAtRight:					"правы бок",
	txtAtLeft:					"левы бок",
	txtInvertButons:			"прамен кнопкі месцамі",
	hdrTextareaFont:			"Шрыфт тэкставага поля",
	optDefault:					"Бяздзейнасць",
	wrnTextareaFont:			"Ты здолен наладзіць канкрэтны шрыфт у <a href='javascript:;'>наладах</a> браўзара.",
	hdrSetupPopupHotkey:		"Налады набітай клавішы для ўсплывае акна",
	btnSetupPopupHotkey:		"Адчыніць наладчык набітых клавіш",
	hdrUseTranslateToolbar:		"Скарыстацца панэллю перакладчыка на кожнай старонцы",
	hdrUseContextMenuForPages:	"Скарыстацца кантэкстным меню для старонак",
	hdrBingPrivateKey:			"Асабісты прахон перакладчыка Bing",
	txtBingClientId:			"ID спажыўца:",
	txtBingClientSecret:		"Ключ спажыўца:",
	hintBingPrivateKey:			"Калі ёсць жаданне быць незалежным ад агульнадаступных ключоў якія могуць быць заблакаваны, зрабі налады для сваіх, асабістых,ключоў доступу.<br />Гэта можна атрымаць тут:",
	optDisabled:				"Адключана",
	wrnUseTranslateToolbar:		"<b>Увага!</b> Частка некаторых ісходных старонак будзе адпраўляцца правайдару перакладчыка для вызначэння ісходнай мовы!<br />Выключэнні: старонкі з наканаваннем сваёй мовы.",
	hdrOtherOptions:			"Іншыя налады",
	txtOpenNewTabsNextToActive:	"Адкрываць новыя ўкладкі следам за актыўнай",
	txtRememberLastTranslation:	"Запамінаць апошні пераклад",
	txtUseTextToSpeech:			"Скарыстаць функцыю чытання тэксту",
	txtUseYellowMarker:			"Скарыстаць жоўты маркер маркер як папярэджанне аб тым што вылучаны тэкст можа быць перахоплены пашырэннем",
	txtOutputExtensionButton:	"Выводзіць кнопку пашырэння ў адраснай панэлі",
	txtUseEnterToTranslate:		"Скарыстаць клавішу \"Увод\" для пераклада",

	txtUseGoogleCn:				"Скарыстаць google.cn (для выпадкаў, калі ў вас заблакаваны google.com)",

	txtYouCanUseMyOtherProducts:"Таксама маешь магчымасць пачаставацца іншымі маімі прадуктамі:",
	txtMyCalendarExensionDescr:	"пашырэнне календару для Оpera",
	txtMyWebanketaServiceDescr:	"бясплатнае стварэнне анкет, апытанак, тэстаў і галасаванняў!",

	txtPoweredByOpera:			"Працуе на браўзары Opera"
};
//	translated by Turov Igor
