// English
var EXT_LOCALE = "en";

var WORDS = {
	// popup
	btnTranslate:				"Translate",
	btnClear:					"Clear",
	txtUse:						"use:",
	txtBackTranslation:			"back translation",
	hntFullExchange:			"Shift-Click – full exchange",
	hntTranslate:				"Ctrl-Enter – translate",
	hntReTranslate:				"Shift-Change – re-translate by choosed service",
	txtTranslateActivePage:		"Translate active page",
	optAutoDetect:				"Auto detect",
	lnkSettingsPage:			"settings",

	txtUnregisteredMode:		"**Unregistered mode**",
	txtUnregisteredModeDetails:	"**Unregistered mode limited by basic functions**\nAfter registration you will have:\n- lack of this message and possible advertising in search engines;\n- text-to-speech, back translation, test Japanese and Korean IME;\n- future new features.\n\nif nothing from the list you need and you do not want to thank the author, registration is not require.",
	txtVerify:					"Click here to Register",

	cmTranslateIt:				"Translate it",
	cmTranslatePage:			"Translate page",

	// services
	byGoogle:					"Google Translate",
	byBing:						"Bing Translator",
	byYandex:					"Yandex Translate",
	byPromt:					"Promt Translator",
	byPragma:					"Pragma Translator",
	byBaidu:					"Baidu Translator",
	byBabylon:					"Babylon Translator",
	byBabylonDictionaries:		"Dictionaries by Babylon",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL Translator",

	tbByGoogle:					"by Google Translate",
	tbByBing:					"by Bing Translator",
	tbByYandex:					"by Yandex Translate",
	tbByPromt:					"by Promt Translator",

	// dictionary
	txtDictionary:				"dictionary",
	linkRemove:					"remove",
	txtUsePersonalDictionary:	"Use personal dictionary",
	txtHide:					"hide",
	txtShow:					"show",

	// options
	txtOptionsTitle:			"Translator settings",
	txtMadeBy:					"Made by",
	linkFeedback:				"bug report / feedback",
	hdrDefaultSourceLang:		"Default source language",
	hdrDefaultTargetLang:		"Default target language",
	hdrMaxStoredLangPairs:		"Maximum stored language pairs",
	hdrTranslateBtnPosition:	"\"Translate\"-button position",
	txtAtRight:					"at right",
	txtAtLeft:					"at left",
	txtInvertButons:			"invert buttons",
	hdrTextareaFont:			"Textarea font",
	optDefault:					"Default",
	wrnTextareaFont:			"You can setup concrete fonts in browser <a href='javascript:;'>settings</a>.",
	hdrSetupPopupHotkey:		"Setup popup hotkey",
	btnSetupPopupHotkey:		"Open hotkeys configurator",
	hdrUseTranslateToolbar:		"Use Translate Toolbar on each page",
	hdrUseContextMenuForPages:	"Use context menu for pages",
	hdrBingPrivateKey:			"Bing Translator Private Access",
	txtBingClientId:			"Client ID:",
	txtBingClientSecret:		"Client Secret:",
	hintBingPrivateKey:			"If you want to be independent from blockable public keys, you can setup own private keys.<br />They can be received from here:",
	optDisabled:				"Disabled",
	wrnUseTranslateToolbar:		"<b>Warning!</b> Source (piece) of almost every page will be send to translator provider for detecting page language!<br />Exception: pages with definition of their language.",
	hdrOtherOptions:			"Other options",
	txtOpenNewTabsNextToActive:	"Open new tabs next to active",
	txtRememberLastTranslation:	"Remember last translation",
	txtUseTextToSpeech:			"Use text-to-speech",
	txtUseYellowMarker:			"Use yellow marker as warning about catchable selected text",
	txtOutputExtensionButton:	"Output extension button on address bar",
	txtUseEnterToTranslate:		"Use \"Enter\" key to translate",

	txtUseGoogleCn:				"Use google.cn (for cases when your firewall block google.com)",

	txtYouCanUseMyOtherProducts:"You can also try my other products:",
	txtMyCalendarExensionDescr:	"calendar extension for Opera",
	txtMyWebanketaServiceDescr:	"free creation of questionnaires, surveys, tests and polls!",

	txtPoweredByOpera:			"Powered by the Opera Browser"
};