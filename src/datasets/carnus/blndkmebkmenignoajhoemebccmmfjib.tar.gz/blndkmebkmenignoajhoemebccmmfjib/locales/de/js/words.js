// German
var EXT_LOCALE = "de";

var WORDS = {
	// popup
	btnTranslate:				"Übersetzen",
	btnClear:					"Löschen",
	txtUse:						"nutze:",
	txtBackTranslation:			"übersetzung zurück",
	hntFullExchange:			"Shift-Taste + Klick – Alles tauschen",
	hntTranslate:				"Strg + Enter – Übersetzen",
	hntReTranslate:				"Shift-Taste + Ändern – Re-Übersetzen durch ausgewählten Service",
	txtTranslateActivePage:		"Übersetze aktuelle Seite",
	optAutoDetect:				"Autom. Erkennen",
	lnkSettingsPage:			"einstellungen",

	txtUnregisteredMode:		"**Unregistrierter Modus**",
	txtUnregisteredModeDetails:	"**Unregistrierter Modus hilft, nur einzelne Wörter zu übersetzen**\nNach der Registrierung haben Sie:\n- Fehlen dieser Nachricht und mögliche zusätzliche Werbung in Suchmaschinen;\n- Text-zu-Sprache, Rückübersetzung, Test Japanisch und Koreanisch IME;\n- zukünftige neue Funktionen.\n\nWenn nichts aus der Liste, die Sie benötigen, ist die Registrierung nicht erforderlich.",
	txtVerify:					"Zu registrieren",

	cmTranslateIt:				"Es übersetzen",
	cmTranslatePage:			"Seite übersetzen",

	// services
	byGoogle:					"Google Übersetzer",
	byBing:						"Bing Übersetzer",
	byYandex:					"Yandex Übersetzer",
	byPromt:					"Promt Übersetzer",
	byPragma:					"Pragma Übersetzer",
	byBaidu:					"Baidu Übersetzer",
	byBabylon:					"Babylon Übersetzer",
	byBabylonDictionaries:		"Wörterbücher von Babylon",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL Übersetzer",

	tbByGoogle:					"mit Google Übersetzer",
	tbByBing:					"mit Bing Übersetzer",
	tbByYandex:					"mit Yandex Übersetzer",
	tbByPromt:					"mit Promt Übersetzer",

	// dictionary
	txtDictionary:				"wörterbuch",
	linkRemove:					"entfernen",
	txtUsePersonalDictionary:	"Persönliches wörterbuch verwenden",
	txtShow:					"zeigen",
	txtHide:					"ausblenden",

	// options
	txtOptionsTitle:			"Translator - Einstellungen",
	txtMadeBy:					"Erstellt von",
	linkFeedback:				"Bug-Bericht / Feedback",
	hdrDefaultSourceLang:		"Standard-Ausgangssprache",
	hdrDefaultTargetLang:		"Standard-Zielsprache",
	hdrMaxStoredLangPairs:		"Anzahl maximal gespeicherter Spracheinträge",
	hdrTranslateBtnPosition:	"Position \"Übersetzen\"-Schaltfläche",
	txtAtRight:					"rechts",
	txtAtLeft:					"links",
	txtInvertButons:			"schaltflächen tauschen",
	hdrTextareaFont:			"Textarea schrift",
	optDefault:					"Standard",
	wrnTextareaFont:			"Sie können in den Browsereinstellungen konkrete Schriftarten <a href='javascript:;'>einrichten</a>.",
	hdrSetupPopupHotkey:		"Setup popup heißer Taste",
	btnSetupPopupHotkey:		"Öffnen Sie heißer Taste-Konfigurator",
	hdrUseTranslateToolbar:		"Übersetzungsleiste auf jeder Seite anzeigen",
	hdrUseContextMenuForPages:	"Einsatz-Kontext-Menü für Seiten",
	hdrBingPrivateKey:			"Bing Übersetzer Privatzugang",
	txtBingClientId:			"Klient ID:",
	txtBingClientSecret:		"Klient Geheimnis:",
	hintBingPrivateKey:			"Wenn Sie von blockierbaren öffentlichen Schlüssel, unabhängig zu sein, können Sie eigene private Schlüssel-Setup.<br />Sie können von hier empfangen werden:",
	optDisabled:				"Deaktiviert",
	wrnUseTranslateToolbar:		"<b>Achtung!</b> Von fast jeder Webseite werden Inhalte zu übersetzer anbieter gesendet, um die Sprache einer Seite bestimmen zu können!<br />Ausnahme: Seiten mit einer festgelegten Sprache.",
	hdrOtherOptions:			"Weitere Optionen",
	txtOpenNewTabsNextToActive:	"Neue Tabs neben dem aktiven Tab öffnen",
	txtRememberLastTranslation:	"Angemeldet letzten Übersetzung",
	txtUseTextToSpeech:			"Text-zu-Sprache benutzen",
	txtUseYellowMarker:			"Benutze gelbe Markierung als Hinweis für erfassten Text",
	txtOutputExtensionButton:	"Symbol der Erweiterung auf Adressleiste anzeigen",
	txtUseEnterToTranslate:		"Use \"Enter\"-taste zu übersetzen",

	txtUseGoogleCn:				"Benutze google.cn (für die Fälle, wenn Ihre Firewall Block google.com)",

	txtYouCanUseMyOtherProducts:"Testen Sie auch meine anderen Produkte:",
	txtMyCalendarExensionDescr:	"Kalender-Erweiterung für Opera",
	txtMyWebanketaServiceDescr:	"Kostenlose Erstellung von Fragebögen, Umfragen, Tests und Abstimmungen!",

	txtPoweredByOpera:			"Unterstützt von Opera Browser"
};
//	translated by myonno
