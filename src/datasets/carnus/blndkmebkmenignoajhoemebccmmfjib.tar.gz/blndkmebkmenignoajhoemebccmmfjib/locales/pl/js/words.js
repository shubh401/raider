// Pollish
var EXT_LOCALE = "pl";

var WORDS = {
	// popup
	btnTranslate:				"Przetłumacz",
	btnClear:					"Wyczyść",
	txtUse:						"użyj:",
	txtBackTranslation:			"tłumaczenie powrotem",
	hntFullExchange:			"Shift + Kliknięcie – zamiana",
	hntTranslate:				"Ctrl + Enter – przetłumacz",
	hntReTranslate:				"Shift + Zmiana – ponownie tłumaczyć przez wybrany serwis",
	txtTranslateActivePage:		"Przetłumacz aktywną stronę",
	optAutoDetect:				"Automatycznie wykrywanie",
	lnkSettingsPage:			"ustawienia",

	txtUnregisteredMode:		"**Tryb niezarejestrowany**",
	txtUnregisteredModeDetails:	"**Tryb niezarejestrowany pomaga tłumaczyć tylko pojedyncze słowa**\nPo rejestracji będziesz miał:\n- brak tej wiadomości i ewentualne dodatkowe reklamy w wyszukiwarkach;\n- tekst-wobec-Przemówienie, w tył tłumaczenie, test japoński i Koreańczyk IME;\n- przyszłe nowe funkcje.\n\nJeśli nic z listy, czego potrzebujesz, rejestracja nie jest wymagana.",
	txtVerify:					"Kliknij tutaj aby się zarejestrować",

	cmTranslateIt:				"Przetłumacz to",
	cmTranslatePage:			"Przetłumacz stronę",

	// services
	byGoogle:					"Tłumacz Google",
	byBing:						"Tłumacz Bing",
	byYandex:					"Tłumacz Yandex",
	byPromt:					"Tłumacz Promt",
	byPragma:					"Tłumacz Pragma",
	byBaidu:					"Tłumacz Baidu",
	byBabylon:					"Tłumacz Babylon",
	byBabylonDictionaries:		"Słowniki Babylon",
	byUrban:					"Słownik Urban",
	byDeepl:					"Tłumacz DeepL",

	tbByGoogle:					"przez Tłumacz Google",
	tbByBing:					"przez Tłumacz Bing",
	tbByYandex:					"przez Tłumacz Yandex",
	tbByPromt:					"przez Tłumacz Promt",

	// dictionary
	txtDictionary:				"słownik",
	linkRemove:					"usunąć",
	txtUsePersonalDictionary:	"Używaj osobistego słownika",
	txtShow:					"pokaż",
	txtHide:					"ukryć",

	// options
	txtOptionsTitle:			"Ustawienia tłumacza",
	txtMadeBy:					"Stworzone przez",
	linkFeedback:				"Raport o błędach / Opinie",
	hdrDefaultSourceLang:		"Domyślny język źródłowy",
	hdrDefaultTargetLang:		"Domyślny język docelowy",
	hdrMaxStoredLangPairs:		"Maksymalna liczba przechowywanych par języków",
	hdrTranslateBtnPosition:	"Pozycja przycisku \"Tłumacz\"",
	txtAtRight:					"po prawej",
	txtAtLeft:					"po lewej",
	txtInvertButons:			"zamiana przycisków miejscami",
	hdrTextareaFont:			"Czcionka Textarea",
	optDefault:					"Domyślnie",
	wrnTextareaFont:			"Konkretne czcionki można konfigurować w <a href='javascript:;'>ustawieniach</a> przeglądarki.",
	hdrSetupPopupHotkey:		"Konfiguracja skrótu popup",
	btnSetupPopupHotkey:		"Otwarte hotkeys konfigurator",
	hdrUseTranslateToolbar:		"Używaj Paska Tłumaczenia na każdej stronie",
	hdrUseContextMenuForPages:	"Użycie menu kontekstowego dla stron",
	hdrBingPrivateKey:			"Tłumacz Bing prywatny dostęp",
	txtBingClientId:			"Klienta ID:",
	txtBingClientSecret:		"Klienta Sekret:",
	hintBingPrivateKey:			"Jeśli chcesz być niezależna od blokowalnych klucze publiczne, można ustawić własne klucze prywatne.<br />Mogą być odebrane z tutaj:",
	optDisabled:				"Wyłączone",
	wrnUseTranslateToolbar:		"<b>Uwaga!</b> W celu wykrycia języka strony, do tłumacz zostanie wysłany fragment źródłowy strony!<br />Wyjątki: strony z określonym językiem.",
	hdrOtherOptions:			"Pozostałe opcje",
	txtOpenNewTabsNextToActive:	"Otwieraj nowe karty obok aktywnej",
	txtRememberLastTranslation:	"Zapamiętaj ostatnie tłumaczenie",
	txtUseTextToSpeech:			"Używaj wymowy tekstu",
	txtUseYellowMarker:			"Używaj żółtego znacznika jako ostrzeżenia o pobraniu zaznaczonego tekstu",
	txtOutputExtensionButton:	"Pokazuj przycisk rozszerzenia na pasku narzędzi",
	txtUseEnterToTranslate:		"Użyj \"Enter\" klucz do przetłumaczenia",

	txtUseGoogleCn:				"Używaj google.cn (w przypadkach, gdy blok zapora google.com)",

	txtYouCanUseMyOtherProducts:"Możesz również spróbować moich innych produktów:",
	txtMyCalendarExensionDescr:	"rozszerzenie kalendarza dla Opery",
	txtMyWebanketaServiceDescr:	"darmowe tworzenie ankiet, badań, testów i głosowań!",

	txtPoweredByOpera:			"Wspierane przez przeglądarkę Opera"
};
//	translated by odie2 (Maciej Gryniuk - http://maciej-gryniuk.tk/)