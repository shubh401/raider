// Ukrainian
var EXT_LOCALE = "uk";

var WORDS = {
	// popup
	btnTranslate:				"Перекласти",
	btnClear:					"Очистити",
	txtUse:						"вик.:",
	txtBackTranslation:			"зворотній переклад",
	hntFullExchange:			"Shift-Click – поміняти місцями разом із текстом",
	hntTranslate:				"Ctrl-Enter – перекласти",
	hntReTranslate:				"Shift-Change – перекласти обраним сервісом",
	txtTranslateActivePage:		"Перекласти активну сторінку",
	optAutoDetect:				"Автовизн.",
	lnkSettingsPage:			"налаштування",

	txtUnregisteredMode:		"**Незареєстрований режим**",
	txtUnregisteredModeDetails:	"**Незареєстрований режим допомагає перекладати лише окремі слова**\nПісля реєстрації будуть в наявності:\n- відсутність цього повідомлення і можлива додаткова реклама в пошукових системах;\n- функція читання тексту, зворотній переклад, словник, тестовий режим вводу для Японської та Корейської мов;\n- нові функції у майбутньому.\n\n якщо нічого з вище наведеного Вам не потрібне, реєстрація не є необхідною.",
	txtVerify:					"Зареєструвати",

	cmTranslateIt:				"Перекласти",
	cmTranslatePage:			"Перекласти сторінку",

	// services
	byGoogle:					"Google Переклад",
	byBing:						"Bing Перекладач",
	byYandex:					"Яндекс.Переклад",
	byPromt:					"Promt Перекладач",
	byPragma:					"Pragma Перекладач",
	byBaidu:					"Baidu Перекладач",
	byBabylon:					"Babylon Перекладач",
	byBabylonDictionaries:		"Словники від Babylon",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL Перекладач",

	tbByGoogle:					"від Google Перекладу",
	tbByBing:					"від Bing Перекладача",
	tbByYandex:					"від Яндекс.Перекладу",
	tbByPromt:					"від Promt Перекладача",

	// dictionary
	txtDictionary:				"словник",
	linkRemove:					"видалити",
	txtUsePersonalDictionary:	"Використовувати власний словник",
	txtShow:					"показати",
	txtHide:					"сховати",

	// options
	txtOptionsTitle:			"Translator - налаштування",
	txtMadeBy:					"Розроблено",
	linkFeedback:				"повідомити про помилку / зворотній зв'язок",
	hdrDefaultSourceLang:		"Мова за замовчуванням, з якої буде перекладатися текст",
	hdrDefaultTargetLang:		"Мова за замовчуванням, на яку буде перекладатися текст",
	hdrMaxStoredLangPairs:		"Максимальна кількість мовних пар, які треба запам'ятати",
	hdrTranslateBtnPosition:	"Розташування кнопки \"Перекласти\"",
	txtAtRight:					"справа",
	txtAtLeft:					"зліва",
	txtInvertButons:			"поміняти кнопки місцями",
	hdrTextareaFont:			"Шрифт текстового поля",
	optDefault:					"За замовчуванням",
	wrnTextareaFont:			"Ви маєте змогу налаштувати конкретні шрифти в <a href='javascript:;'>опціях</a> браузера.",
	hdrSetupPopupHotkey:		"Налаштування гарячої клавіші для спливаючого вікна",
	btnSetupPopupHotkey:		"Відкрити налаштування гарячих клавіш",
	hdrUseTranslateToolbar:		"Використовувати панель перекладача на кожній сторінці",
	hdrUseContextMenuForPages:	"Використовувати контекстне меню для сторінок",
	hdrBingPrivateKey:			"Персональний доступ перекладача Bing",
	txtBingClientId:			"ID клієнта:",
	txtBingClientSecret:		"Ключ клієнта:",
	hintBingPrivateKey:			"Якщо Ви хочете бути незалежні від публічних ключів доступу до сервісу, які блокуються, Ви можете додати свої власні ключі.<br />Вони можуть бути отримані тут:",
	optDisabled:				"Відключено",
	wrnUseTranslateToolbar:		"<b>Увага!</b> Частина деяких сторінок, які перекладаються, будуть відправляться провайдеру перекладача для визначення мови оригіналу!<br />Виключення: сторінки з передвизначенням власної мови.",
	hdrOtherOptions:			"Інші налаштування",
	txtOpenNewTabsNextToActive:	"Відкривати нові вкладки після активної",
	txtRememberLastTranslation:	"Запам'ятовувати останній переклад",
	txtUseTextToSpeech:			"Використовувати функцію читання тексту",
	txtUseYellowMarker:			"Використовувати жовтий маркер як попередження про те, що виділений текст може бути перехоплений додатком",
	txtOutputExtensionButton:	"Показувати кнопку додатка в адресній панелі",
	txtUseEnterToTranslate:		"Використовувати клавішу \"Ввод\" для перекладу",

	txtUseGoogleCn:				"Використовувати google.cn (для випадків, коли у Вас заблокований google.com)",

	txtYouCanUseMyOtherProducts:"Ви також можете спробувати інші мої продукти:",
	txtMyCalendarExensionDescr:	"розширення календаря для Opera",
	txtMyWebanketaServiceDescr:	"безкоштовне створення анкет, опитувань, тестів та голосувань!",

	txtPoweredByOpera:			"Працює на браузері Opera"
};
//	translated by Vasyl, fixed by Михаил Журавский
