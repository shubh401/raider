// Portuguese (Brazil)
var EXT_LOCALE = "pt-br";

var WORDS = {
	// popup
	btnTranslate:				"Traduzir",
	btnClear:					"Limpar",
	txtUse:						"usar:",
	txtBackTranslation:			"tradução de volta",
	hntFullExchange:			"Shift-Click – troca completa",
	hntTranslate:				"Ctrl-Enter – traduzir",
	hntReTranslate:				"Shift-Change – Re-traduzir pelo serviço escolhido",
	txtTranslateActivePage:		"Traduzir página ativa",
	optAutoDetect:				"Auto detectar",
	lnkSettingsPage:			"configurações",

	txtUnregisteredMode:		"**Modo não registrado**",
	txtUnregisteredModeDetails:	"**Modo não registrado ajuda a traduzir apenas palavras simples**\nApós o registro você terá:\n- falta desta mensagem e possível publicidade nos motores de busca;\n- texto-para-fala, back translation, teste de japonês e coreano IME;\n- novas funcionalidades futuras.\n\nse nada da lista que você precisa, o registro não é necessário.",
	txtVerify:					"Clique aqui para se cadastrar",

	cmTranslateIt:				"Traduzi-lo",
	cmTranslatePage:			"Traduzir página",

	// services
	byGoogle:					"Google Tradutor",
	byBing:						"Bing Tradutor",
	byYandex:					"Yandex Tradutor",
	byPromt:					"Promt Tradutor",
	byPragma:					"Pragma Tradutor",
	byBaidu:					"Baidu Tradutor",
	byBabylon:					"Babylon Tradutor",
	byBabylonDictionaries:		"Dicionários por Babylon",
	byUrban:					"Dicionário Urbano",
	byDeepl:					"DeepL Tradutor",

	tbByGoogle:					"por Google Tradutor",
	tbByBing:					"por Bing Tradutor",
	tbByYandex:					"por Yandex Tradutor",
	tbByPromt:					"por Promt Tradutor",

	// dictionary
	txtDictionary:				"dicionário",
	linkRemove:					"remover",
	txtUsePersonalDictionary:	"Usar o dicionário pessoal",
	txtShow:					"exposição",
	txtHide:					"ocultar",

	// options
	txtOptionsTitle:			"Configurações do Tradutor",
	txtMadeBy:					"Feito por",
	linkFeedback:				"relatório de bug / gabarito",
	hdrDefaultSourceLang:		"Idioma de origem padrão",
	hdrDefaultTargetLang:		"Idioma alvo padrão",
	hdrMaxStoredLangPairs:		"Limite de pares de idiomas armazenados",
	hdrTranslateBtnPosition:	"\"Traduzir\"-posição do Botão",
	txtAtRight:					"à direita",
	txtAtLeft:					"à esquerda",
	txtInvertButons:			"inverter botões",
	hdrTextareaFont:			"Fonte Textarea",
	optDefault:					"Padrão",
	wrnTextareaFont:			"Você pode configurar fontes concretas em <a href='javascript:;'>configurações</a> do navegador.",
	hdrSetupPopupHotkey:		"Configurar a tecla de atalho pop-up",
	btnSetupPopupHotkey:		"Configurador de hotkeys aberto",
	hdrUseTranslateToolbar:		"Usar Barra de Tradução em cada página",
	hdrUseContextMenuForPages:	"Menu de contexto de uso para páginas",
	hdrBingPrivateKey:			"Bing Tradutor acesso privado",
	txtBingClientId:			"Cliente ID:",
	txtBingClientSecret:		"Cliente Segredo:",
	hintBingPrivateKey:			"Se você quer ser independente de blockable chaves públicas, você pode configurar as chaves particulares próprias.<br />Eles podem ser recebidos a partir daqui:",
	optDisabled:				"Desativado",
	wrnUseTranslateToolbar:		"<b>Aviso!</b> Uma parte da fonte de quase toda página será enviado a provedor de tradutor para detecção do idioma da página!<br />Exceção: páginas com definição de seu idioma.",
	hdrOtherOptions:			"Outras opções",
	txtOpenNewTabsNextToActive:	"Abrir novas abas próximas a ativa",
	txtRememberLastTranslation:	"Lembre-se de última tradução",
	txtUseTextToSpeech:			"Usar texto-para-fala",
	txtUseYellowMarker:			"Usar marcador amarelo como aviso sobre texto selecionado capturável",
	txtOutputExtensionButton:	"Exibir botão da extensão na barra de tarefas",
	txtUseEnterToTranslate:		"Use \"Enter\" chave para traduzir",

	txtUseGoogleCn:				"Usar google.cn (para casos em que o seu bloco firewall google.com)",

	txtYouCanUseMyOtherProducts:"Você também pode experimentas meus outros produtos:",
	txtMyCalendarExensionDescr:	"extensão calendário para Opera",
	txtMyWebanketaServiceDescr:	"criação gratuita de questionários, pesquisas, testes e enquetes!",

	txtPoweredByOpera:			"Sustentado pelo Navegador Opera"
};
//	translated by Aurélio
