// Czech
var EXT_LOCALE = "cs";

var WORDS = {
	// popup
	btnTranslate:				"Přeložit",
	btnClear:					"Smazat",
	txtUse:						"použít:",
	txtBackTranslation:			"zpětný překlad",
	hntFullExchange:			"Shift-klik – včetně výměny textových polí",
	hntTranslate:				"Ctrl-Enter – přeložit",
	hntReTranslate:				"Shift-Change – ihned přeložit zvolenou službou",
	txtTranslateActivePage:		"Přeložit současnou stránku",
	optAutoDetect:				"Automatická detekce",
	lnkSettingsPage:			"nastavení",

	txtUnregisteredMode:		"**Neregistrovaná verze**",
	txtUnregisteredModeDetails:	"**Pokud není provedena registrace, je možné překládat pouze samostatná slova**\nPokud provedete registraci, budete moci:\n- nedostatek této zprávy a možná další reklama ve vyhledávačích;\n- funkce čtení textu, zpětný překlad, test japonský a korejský IME;\n- budoucí nové funkce.\n\nPokud žádné z těchto funkcí nepotřebujete, registraci provádět nemusíte.",
	txtVerify:					"Pro registraci klikněte zde",

	cmTranslateIt:				"Přeložit to",
	cmTranslatePage:			"Přeložit stránku",

	// services
	byGoogle:					"Google překladač",
	byBing:						"Bing překladač",
	byYandex:					"Yandex překladač",
	byPromt:					"Promt překladač",
	byPragma:					"Pragma překladač",
	byBaidu:					"Baidu překladač",
	byBabylon:					"Babylon překladač",
	byBabylonDictionaries:		"Slovníky Babylon",
	byUrban:					"Urban slovník",
	byDeepl:					"DeepL překladač",

	tbByGoogle:					"Google překladačem",
	tbByBing:					"Bing překladačem",
	tbByYandex:					"Yandex překladačem",
	tbByPromt:					"Promt překladačem",

	// dictionary
	txtDictionary:				"slovník",
	linkRemove:					"odebrat",
	txtUsePersonalDictionary:	"Používat osobní slovník",
	txtShow:					"show",
	txtHide:					"skrýt",

	// options
	txtOptionsTitle:			"Nastavení překladače",
	txtMadeBy:					"Vyrobil",
	linkFeedback:				"nahlásit problém / zpětná vazba",
	hdrDefaultSourceLang:		"Výchozí zdrojový jazyk",
	hdrDefaultTargetLang:		"Výchozí cílový jazyk",
	hdrMaxStoredLangPairs:		"Maximální počet připnutých jazykových variant překladu",
	hdrTranslateBtnPosition:	"Pozice tlačítka \"Přeložit\"",
	txtAtRight:					"na pravo",
	txtAtLeft:					"na levo",
	txtInvertButons:			"přehotid tlačítka",
	hdrTextareaFont:			"Písmo TextFont",
	optDefault:					"Výchozí",
	wrnTextareaFont:			"V <a href='javascript:;'>nastavení</a> prohlížeče můžete nastavit konkrétní písma.",
	hdrSetupPopupHotkey:		"Nastavení klávesové zkratky otevření překladače",
	btnSetupPopupHotkey:		"Otevřít konfigurátor klávesových zkratek",
	hdrUseTranslateToolbar:		"Používat nástrojovou lištu translátoru na každé stránce",
	hdrUseContextMenuForPages:	"Na stránkách polovit kontextové menu překladače",
	hdrBingPrivateKey:			"Privátní přístup Bing překladače",
	txtBingClientId:			"Klienstké ID:",
	txtBingClientSecret:		"Klientské heslo:",
	hintBingPrivateKey:			"Pokud chcete být nezávislý na veřejných klíčích, které mohou být zablokované, můžete nastavit vlastní soukromé klíče.<br />Klíče můžete získat zde:",
	optDisabled:				"Zakázáno",
	wrnUseTranslateToolbar:		"<b>Varování!</b> Zdrojové kódy (jeho části) téměř každé stránky budou odesílány poskytovateli překladače za účelem zjištění jazyka stránky!<br />Výjimku tvoří stránky, které mají jazyk definovaný v hlavičce.",
	hdrOtherOptions:			"Ostatní nastavení",
	txtOpenNewTabsNextToActive:	"Nové záložky otevírat za aktivní stránku",
	txtRememberLastTranslation:	"Pamatovat si poslední překlad",
	txtUseTextToSpeech:			"Používat převod textu na řeč",
	txtUseYellowMarker:			"Ikonu rozšížení zvýrazňovat žlutě jako varování, že vybraný text může být zpracován překladačem",
	txtOutputExtensionButton:	"Zobrazit tlačítko překladače v adresním řádku",
	txtUseEnterToTranslate:		"Použijte klávesu \"Enter\" k překladu",

	txtUseGoogleCn:				"Používat google.cn (například pokud je doména google.com blokována firewallem)",

	txtYouCanUseMyOtherProducts:"Můžete také vyzkoušet jiné produkty:",
	txtMyCalendarExensionDescr:	"rozšíření Kalendář pro Operu",
	txtMyWebanketaServiceDescr:	"bezplatné vytváření dotazníků, průzkumů, testů a hlasování!",

	txtPoweredByOpera:			"Běží na prohlížeči Opera"
};
//	translated by Petr Havel
