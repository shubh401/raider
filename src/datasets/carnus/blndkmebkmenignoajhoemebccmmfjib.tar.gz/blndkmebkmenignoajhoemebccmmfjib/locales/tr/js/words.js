// Turkish
var EXT_LOCALE = "tr";

var WORDS = {
	// popup
	btnTranslate:				"Çevirmek",
	btnClear:					"Temizlemek",
	txtUse:						"kullanın:",
	txtBackTranslation:			"geri çeviri",
	hntFullExchange:			"Shifte basarak - tam değişim",
	hntTranslate:				"Ctrl-Enter - çeviri",
	hntReTranslate:				"Shift-değiştir - seçilen servis tarafından yeniden tercüme",
	txtTranslateActivePage:		"Etkin sayfayı çevir",
	optAutoDetect:				"Otomatik algılama",
	lnkSettingsPage:			"ayarlar",

	txtUnregisteredMode:		"**Kayıtsız mod**",
	txtUnregisteredModeDetails:	"**Kayıtsız mod temel işlevlerle sınırlıdır**\nKayıt olduktan sonra:\n- bu mesaj eksikliği ve arama motorları olası reklam;\n- metin-konuşma, geri çeviri, Japonca ve Korece IME testi;\n- gelecekteki yeni özellikler.\n\neğer listeden hiçbir şey gerekmiyorsa ve yazara teşekkür etmek istemiyorsanız, kayıt gerektirmez.",
	txtVerify:					"Kayıt olmak için buraya tıklayın",

	cmTranslateIt:				"Çevir",
	cmTranslatePage:			"Sayfayı çevir",

	// services
	byGoogle:					"Google Çeviri",
	byBing:						"Bing Çeviricisi",
	byYandex:					"Yandex Çeviri",
	byPromt:					"Promt Çevirmen",
	byPragma:					"Pragma Çevirmen",
	byBaidu:					"Baidu Tercüman",
	byBabylon:					"Babylon Tercüman",
	byBabylonDictionaries:		"Babylon 'nun sözlükleri",
	byUrban:					"Urban Sözlük",
	byDeepl:					"DeepL Çeviricisi",

	tbByGoogle:					"Google Çevirmen tarafından",
	tbByBing:					"Bing Çevirmen tarafından",
	tbByYandex:					"Yandex Çevirmen tarafından",
	tbByPromt:					"Promt Çevirmen tarafından",

	// dictionary
	txtDictionary:				"sözlük",
	linkRemove:					"kaldır",
	txtUsePersonalDictionary:	"Kişisel sözlüğü kullan",
	txtShow:					"göstermek",
	txtHide:					"saklamak",

	// options
	txtOptionsTitle:			"Çevirmen ayarları",
	txtMadeBy:					"Tarafından yapıldı",
	linkFeedback:				"hata raporu / geribildirim",
	hdrDefaultSourceLang:		"Varsayılan kaynak dil",
	hdrDefaultTargetLang:		"Varsayılan hedef dil",
	hdrMaxStoredLangPairs:		"Maksimum saklanan dil çiftleri",
	hdrTranslateBtnPosition:	"\"Çevir\"-button pozisyonu",
	txtAtRight:					"sağda",
	txtAtLeft:					"solda",
	txtInvertButons:			"düğmeler",
	hdrTextareaFont:			"Textarea yazı tipi",
	optDefault:					"Varsayılan",
	wrnTextareaFont:			"Tarayıcı <a href='javascript:;'>ayarlarında</a> beton yazı tipleri ayarlayabilirsiniz.",
	hdrSetupPopupHotkey:		"Açılır pencere kısayolunu ayarla",
	btnSetupPopupHotkey:		"Hotkeys yapılandırıcısını aç",
	hdrUseTranslateToolbar:		"Her sayfada Çevir Araç Çubuğu'nu kullanın",
	hdrUseContextMenuForPages:	"Sayfalar için içerik menüsünü kullan",
	hdrBingPrivateKey:			"Bing Tercüman Özel Erişim",
	txtBingClientId:			"Müşteri Kimliği:",
	txtBingClientSecret:		"Müşteri sırrı:",
	hintBingPrivateKey:			"Engellenen genel anahtarlardan bağımsız olmak istiyorsanız, kendi özel anahtarlarını ayarlayabilirsiniz.<br /> Buradan alınabilirler:",
	optDisabled:				"Engelli",
	wrnUseTranslateToolbar:		"<b>Uyarı!</ b> Hemen hemen her sayfanın kaynağı (parçası), sayfa dilini algılamak için çevirmen sağlayıcısına gönderilecektir!<br /> İstisna: kendi dillerinin tanımlandığı sayfalar.",
	hdrOtherOptions:			"Diğer seçenekler",
	txtOpenNewTabsNextToActive:	"Etkinliğin yanındaki yeni sekmeleri aç",
	txtRememberLastTranslation:	"Son çeviriyi hatırla",
	txtUseTextToSpeech:			"Metin-konuşma kullan",
	txtUseYellowMarker:			"Seçmeli metin hakkında uyarı olarak sarı işaretçiyi kullan",
	txtOutputExtensionButton:	"Adres çubuğunda çıkış uzantısı düğmesi",
	txtUseEnterToTranslate:		"Çevirmek için \"Enter\" tuşunu kullanın",

	txtUseGoogleCn:				"google.cn adresini kullanın (güvenlik duvarınızın google.com adresini engellediği durumlar için)",

	txtYouCanUseMyOtherProducts:"Diğer ürünlerimi de deneyebilirsiniz:",
	txtMyCalendarExensionDescr:	"Opera için takvim uzantısı",
	txtMyWebanketaServiceDescr:	"anketlerin, anketlerin, testlerin ve anketlerin ücretsiz oluşturulması!",

	txtPoweredByOpera:			"Opera Tarayıcı tarafından desteklenmektedir"
};
//	translated by Erhan Kültür
