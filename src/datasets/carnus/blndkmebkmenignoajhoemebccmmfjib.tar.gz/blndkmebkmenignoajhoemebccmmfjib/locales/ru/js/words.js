// Russian
var EXT_LOCALE = "ru";

var WORDS = {
	// popup
	btnTranslate:				"Перевести",
	btnClear:					"Очистить",
	txtUse:						"исп.:",
	txtBackTranslation:			"обратный перевод",
	hntFullExchange:			"Shift-Click – поменять местами вместе с текстом",
	hntTranslate:				"Ctrl-Enter – перевести",
	hntReTranslate:				"Shift-Change – перевести выбранным сервисом",
	txtTranslateActivePage:		"Перевести активную страницу",
	optAutoDetect:				"Автоопр.",
	lnkSettingsPage:			"настройки",

	txtUnregisteredMode:		"**Незарегистрированный режим**",
	txtUnregisteredModeDetails:	"**Незарегистрированный режим ограничен основными функциями**\nПосле регистрации Вам будут доступны:\n- отсутствие этого сообщения и возможная реклама в поисковиках;\n- функция чтения текста, обратный перевод, тестовый режим ввода для Японского и Корейского языков;\n- будущие новые функции.\n\nесли ничего из вышеперечисленного Вам не нужно и Вы не хотите отблагодарить автора, регистрация не требуется.",
	txtVerify:					"Зарегистрировать",

	cmTranslateIt:				"Перевести",
	cmTranslatePage:			"Перевести страницу",

	// services
	byGoogle:					"Google Перевод",
	byBing:						"Bing Переводчик",
	byYandex:					"Яндекс.Перевод",
	byPromt:					"Promt Переводчик",
	byPragma:					"Pragma Переводчик",
	byBaidu:					"Baidu Переводчик",
	byBabylon:					"Babylon Переводчик",
	byBabylonDictionaries:		"Словари от Babylon",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL Переводчик",

	tbByGoogle:					"от Google Перевод",
	tbByBing:					"от Bing Переводчик",
	tbByYandex:					"от Яндекс.Перевод",
	tbByPromt:					"от Promt Переводчик",

	// dictionary
	txtDictionary:				"словарь",
	linkRemove:					"удалить",
	txtUsePersonalDictionary:	"Использовать личный словарь",
	txtShow:					"показать",
	txtHide:					"скрыть",

	// options
	txtOptionsTitle:			"Translator - настройки",
	txtMadeBy:					"Разработано",
	linkFeedback:				"сообщить об ошибке / обратная связь",
	hdrDefaultSourceLang:		"Язык по-умолчанию, с которого будет переводиться текст",
	hdrDefaultTargetLang:		"Язык по-умолчанию, на который будет переводиться текст",
	hdrMaxStoredLangPairs:		"Максимальное количество используемых пар языков, которые следует запоминать",
	hdrTranslateBtnPosition:	"Расположение кнопки \"Перевести\"",
	txtAtRight:					"справа",
	txtAtLeft:					"слева",
	txtInvertButons:			"поменять кнопки местами",
	hdrTextareaFont:			"Шрифт текстового поля",
	optDefault:					"По-умолчанию",
	wrnTextareaFont:			"Вы можете настроить конкретные шрифты в <a href='javascript:;'>настройках</a> браузера.",
	hdrSetupPopupHotkey:		"Настройка горячей клавиши для всплывающего окна",
	btnSetupPopupHotkey:		"Открыть настройщик горячих клавиш",
	hdrUseTranslateToolbar:		"Использовать панель переводчика на каждой странице",
	hdrUseContextMenuForPages:	"Использовать контекстное меню для страниц",
	hdrBingPrivateKey:			"Персональный доступ переводчика Bing",
	txtBingClientId:			"ID клиента:",
	txtBingClientSecret:		"Ключ клиента:",
	hintBingPrivateKey:			"Если Вы хотите быть независимым от блокирующихся публичных ключей доступа к сервису, Вы можете настроить свои личные ключи доступа.<br />Он могут быть получены тут:",
	optDisabled:				"Отключено",
	wrnUseTranslateToolbar:		"<b>Внимание!</b> Часть некоторых исходных страниц будет отправляться провайдеру переводчика для определения исходного языка!<br />Исключения: страницы с предопределением своего языка.",
	hdrOtherOptions:			"Другие настройки",
	txtOpenNewTabsNextToActive:	"Открывать новые вкладки следом за активной",
	txtRememberLastTranslation:	"Запоминать последний перевод",
	txtUseTextToSpeech:			"Использовать функцию чтения текста",
	txtUseYellowMarker:			"Использовать жёлтый маркер как предупреждение о том, что выделенный текст может быть перехвачен расширением",
	txtOutputExtensionButton:	"Выводить кнопку расширения в адресной панели",
	txtUseEnterToTranslate:		"Использовать клавишу \"Ввод\" для перевода",

	txtUseGoogleCn:				"Использовать google.cn (для случаев, когда у вас заблокирован google.com)",

	txtYouCanUseMyOtherProducts:"Вы также можете попробовать другие мои продукты:",
	txtMyCalendarExensionDescr:	"расширение календаря для Opera",
	txtMyWebanketaServiceDescr:	"бесплатное создание анкет, опросов, тестов и голосований!",

	txtPoweredByOpera:			"Работает на браузере Opera"
};