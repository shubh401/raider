// Italian
var EXT_LOCALE = "it";

var WORDS = {
	// popup
	btnTranslate:				"Traduci",
	btnClear:					"Cancella",
	txtUse:						"usa:",
	txtBackTranslation:			"traduzione posteriore",
	hntFullExchange:			"Shift-Click – scambio completo",
	hntTranslate:				"Ctrl-Enter – traduci",
	hntReTranslate:				"Shift-Change – traduci con il servizio selezionato",
	txtTranslateActivePage:		"Traduci la pagina attiva",
	optAutoDetect:				"Rilevamento auto.",
	lnkSettingsPage:			"impostazioni",

	txtUnregisteredMode:		"**Modalità non registrata**",
	txtUnregisteredModeDetails:	"**La modalità non registrata aiuta a tradurre solo le singole parole**\nDopo la registrazione si avrà:\n- mancanza di questo messaggio e possibile pubblicità aggiuntiva nei motori di ricerca;\n- Text-to-speech, traduzione indietro, test giapponese e coreano IME;\n- nuove funzionalità future.\n\nse nulla dalla lista che ti serve, la registrazione non è necessario.",
	txtVerify:					"Clicca qui per registrarti",

	cmTranslateIt:				"Traducilo",
	cmTranslatePage:			"Traduci pagina",

	// services
	byGoogle:					"Google Traduttore",
	byBing:						"Bing Traduttore",
	byYandex:					"Yandex Traduttore",
	byPromt:					"Promt Traduttore",
	byPragma:					"Pragma Traduttore",
	byBaidu:					"Baidu Traduttore",
	byBabylon:					"Babylon Traduttore",
	byBabylonDictionaries:		"Dizionari di Babylon",
	byUrban:					"Dizionario Urban",
	byDeepl:					"DeepL Traduttore",

	tbByGoogle:					"con Google Traduttore",
	tbByBing:					"con Bing Traduttore",
	tbByYandex:					"con Yandex Traduttore",
	tbByPromt:					"con Promt Traduttore",

	// dictionary
	txtDictionary:				"dizionario",
	linkRemove:					"rimuovere",
	txtUsePersonalDictionary:	"Utilizzare il dizionario personale",
	txtShow:					"visualizza",
	txtHide:					"nascondere",

	// options
	txtOptionsTitle:			"Impostazioni traduttore",
	txtMadeBy:					"Realizzato da",
	linkFeedback:				"segnalazione di bug / feedback",
	hdrDefaultSourceLang:		"Lingua di origine predefinita",
	hdrDefaultTargetLang:		"Lingua di destinazione predefinita",
	hdrMaxStoredLangPairs:		"Coppie massime di lingue memorizzate",
	hdrTranslateBtnPosition:	"Posizione del pulsante \"Traduci\"",
	txtAtRight:					"a destra",
	txtAtLeft:					"a sinistra",
	txtInvertButons:			"inverti pulsanti",
	hdrTextareaFont:			"Textarea font",
	optDefault:					"Predefinita",
	wrnTextareaFont:			"È possibile impostare i font concreti nelle <a href='javascript:;'>impostazioni</a> del browser.",
	hdrSetupPopupHotkey:		"Installazione popup hotkey",
	btnSetupPopupHotkey:		"Aperte tasti di scelta rapida configuratore",
	hdrUseTranslateToolbar:		"Utilizza la Barra Traduci in ogni pagina",
	hdrUseContextMenuForPages:	"Utilizzare menu di scelta rapida per le pagine",
	hdrBingPrivateKey:			"Bing Traduttore accesso privato",
	txtBingClientId:			"Cliente ID:",
	txtBingClientSecret:		"Cliente Segreto:",
	hintBingPrivateKey:			"Se si vuole essere indipendente dalle chiavi pubbliche bloccabili, è possibile configurare proprie chiavi private.<br />Essi possono essere ricevuti da qui:",
	optDisabled:				"Disattivato",
	wrnUseTranslateToolbar:		"<b>Attenzione!</b> La sorgente (o parte) di quasi ogni pagina sarà inviata a fornitore di traduzioni per determinare la lingua originale!<br />Eccezioni: pagine nella lingua di destinazione utilizzata.",
	hdrOtherOptions:			"Altre opzioni",
	txtOpenNewTabsNextToActive:	"Aprire nuove schede accanto a quella attiva",
	txtRememberLastTranslation:	"Ricorda ultima traduzione",
	txtUseTextToSpeech:			"Utilizzare il lettore di testo",
	txtUseYellowMarker:			"Utilizza il marcatore giallo come avvertimento che il testo selezionato può essere tradotto",
	txtOutputExtensionButton:	"Pulsante dell'estensione sulla barra degli indirizzi",
	txtUseEnterToTranslate:		"Utilizzare il tasto \"Enter\" per tradurre",

	txtUseGoogleCn:				"Utilizza google.cn (per i casi in cui il firewall blocca google.com)",

	txtYouCanUseMyOtherProducts:"Puoi provare anche gli altri miei prodotti:",
	txtMyCalendarExensionDescr:	"estensione calendario per Opera",
	txtMyWebanketaServiceDescr:	"libera creazione di questionari, indagini, test e sondaggi!",

	txtPoweredByOpera:			"Realizzato per il Browser Opera"
};
//	translated by Andrea Gramegna
