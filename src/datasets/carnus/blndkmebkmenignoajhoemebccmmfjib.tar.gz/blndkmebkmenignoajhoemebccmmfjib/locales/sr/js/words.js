// Serbian
var EXT_LOCALE = "sr";

var WORDS = {
	// popup
	btnTranslate:				"Преведи",
	btnClear:					"Очисти",
	txtUse:						"користи:",
	txtBackTranslation:			"повратни превод",
	hntFullExchange:			"Shift+клик – пуна замена",
	hntTranslate:				"Ctrl+Enter – преведи",
	hntReTranslate:				"Shift+промени – преведи изабраним сервисом",
	txtTranslateActivePage:		"Преведи активну страницу",
	optAutoDetect:				"Откриј језик",
	lnkSettingsPage:			"подешавања",

	txtUnregisteredMode:		"**Нерегистрована режим**",
	txtUnregisteredModeDetails:	"**Нерегистрована режим помаже да се преведе само појединачне речи**\nНакон регистрације имате:\n- непостојање ове поруке и могуће оглашавање у претраживачима;\n- Функција читања у тексту, задњи превод, тест јапански и корејски име;\n- будуће нове карактеристике.\n\nако ништа са листе потребно, Регистрација је не захтева.",
	txtVerify:					"Кликните овде да бисте се регистровали",

	cmTranslateIt:				"Преведи",
	cmTranslatePage:			"Преведи страницу",

	// services
	byGoogle:					"Google преводилац",
	byBing:						"Bing преводилац",
	byYandex:					"Yandex преводилац",
	byPromt:					"Promt преводилац",
	byPragma:					"Pragma преводилац",
	byBaidu:					"Baidu преводилац",
	byBabylon:					"Babylon преводилац",
	byBabylonDictionaries:		"Babylon речници",
	byUrban:					"Urban Dictionary",
	byDeepl:					"DeepL преводилац",

	tbByGoogle:					"од Google преводиоца",
	tbByBing:					"од Bing преводиоца",
	tbByYandex:					"од Yandex преводиоца",
	tbByPromt:					"од Promt преводиоца",

	// dictionary
	txtDictionary:				"речник",
	linkRemove:					"уклонити",
	txtUsePersonalDictionary:	"Користи лични речник",
	txtShow:					"схов",
	txtHide:					"сакрити",

	// options
	txtOptionsTitle:			"Translator - Подешавања",
	txtMadeBy:					"Креирао",
	linkFeedback:				"Пријава грешака / Повратне информације",
	hdrDefaultSourceLang:		"Подразумевани изворни језик",
	hdrDefaultTargetLang:		"Подразумевани циљни језик",
	hdrMaxStoredLangPairs:		"Максимални број сачуваних језичких парова",
	hdrTranslateBtnPosition:	"Позиција дугмета \"Преведи\"",
	txtAtRight:					"десно",
	txtAtLeft:					"лево",
	txtInvertButons:			"зaмени места дугмади",
	hdrTextareaFont:			"Област текста фонтова",
	optDefault:					"Подразумевани",
	wrnTextareaFont:			"Можес да конкретне фонтова у <a href='javascript:;'>поставке</a> прегледача.",
	hdrSetupPopupHotkey:		"Подешавање пречице искачућег прозора",
	btnSetupPopupHotkey:		"Отвори подешавања тастерских пречица",
	hdrUseTranslateToolbar:		"Користи алатну траку за превод на свакој страници",
	hdrUseContextMenuForPages:	"Користи контекстни мени за странице",
	hdrBingPrivateKey:			"Приватни приступ Bing преводиоца",
	txtBingClientId:			"ID клијента:",
	txtBingClientSecret:		"Тајна клијента:",
	hintBingPrivateKey:			"Ако желите да будете независни од јавних кључева који могу бити блокирани, можете да подесите сопствене приватне кључеве.<br />Могу бити примљени одавде:",
	optDisabled:				"Онемогућено",
	wrnUseTranslateToolbar:		"<b>Упозорење!</b> Извор скоро сваке странице ће бити послат преводилац-у ради откривања језика странице!<br />Изузетак: странице са већ дефинисаним језиком.",
	hdrOtherOptions:			"Остале опције",
	txtOpenNewTabsNextToActive:	"Отвори нове картице поред активне",
	txtRememberLastTranslation:	"Запамти последњи превод",
	txtUseTextToSpeech:			"Прикажи дугме за изговор текста",
	txtUseYellowMarker:			"Користи жуту ознаку као обавештење да је изабрани текст прихваћен за превод",
	txtOutputExtensionButton:	"Прикажи дугме проширења на траци адресе",
	txtUseEnterToTranslate:		"Користите \"Enter\" кључ за превођење",

	txtUseGoogleCn:				"Користи google.cn (у случајевима када заштитни зид блокира google.com)",

	txtYouCanUseMyOtherProducts:"Пробајте моје друге производе:",
	txtMyCalendarExensionDescr:	"календар за Opera прегледач",
	txtMyWebanketaServiceDescr:	"бесплатно креирање упитника, анкета, тестова и гласања!",

	txtPoweredByOpera:			"Креирано за Opera прегледач"
};
//	translated by sijera
