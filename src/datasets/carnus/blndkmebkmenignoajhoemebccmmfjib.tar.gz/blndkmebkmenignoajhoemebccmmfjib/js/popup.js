﻿/* globals chrome, widget, WORDS, is_edge, popupInSidebar, sbStoragePrefix, languages, lang_default_locales, propPopupSize, popupMinimumSize, TranslateText, TranslateUrl, DetectUserPreferedLanguage, OpenCopyrightLink, Trim, backTranslating, FixCfgPopupSize, VerifyWidgetAsync */
// (c) http://www.frequency-decoder.com/demo/detect-text-direction/
var ltrChars		= 'A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02B8\u0300-\u0590\u0800-\u1FFF'+'\u2C00-\uFB1C\uFDFE-\uFE6F\uFEFD-\uFFFF',
	rtlChars		= '\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC',
	ltrDirCheckRe	= new RegExp('^[^'+rtlChars+']*['+ltrChars+']'),
	rtlDirCheckRe	= new RegExp('^[^'+ltrChars+']*['+rtlChars+']');
if (typeof WORDS == "undefined")
	WORDS = null;

var partner_images = {
/*
					"SkyEng": {
								"require":	{
												"user_langs": ["ru"],
												"dict_langs": ["en-ru", "ru-en"]
											},
								"image":	"img/partners/skyeng_320x50_03.gif",
								"link":		"http://skyeng.ru/go/translator"
								},
*/
					};

var supportMP3 = null;
var backgroundPage = null;
if (chrome && chrome.runtime.getBackgroundPage)
	chrome.runtime.getBackgroundPage( function(bgPage){
		backgroundPage = bgPage;
	});

function SendMessageToBackgroundScript(msg)
{
	if (opera && opera.extension)
		opera.extension.postMessage( msg );
	else if (chrome)
	{
		// Edge better work via async messages
		chrome.runtime.sendMessage(msg, function(answer)	// this handler did not support `sender` object
		{
			onMessageHandler(answer);
		});

		// in some cases we want response => sender has to be window
		// But this method badly work with Edge!
		// TODO: use sendMessage
/*
		if (chrome.runtime && chrome.runtime.getBackgroundPage)
			chrome.runtime.getBackgroundPage( function(bgPage){
				bgPage.onMessageHandler( msg, window );
			});

		// alternative: var bgPage = chrome.extension.getBackgroundPage();
*/
	}
}


var activePage = {};
var useEnterToTranslate = false;
var defSourceLang = "";
var defTargetLang = DetectUserPreferedLanguage();
var maxStoreLangPairs = 3;
var mostUsedLangPairs = {};
// var useGoogleDict = true;
var detectedInputStringsLang = "";
var rememberLastTranslation = true;
var useGoogleCn = false;
var useGoogleTTS = true;
var usePersonalDictionary = true;

var prevValues = {};

/*
var SpeechRecognition = (window.SpeechRecognition || window.webkitSpeechRecognition);
var useSpeechRecognition = !!SpeechRecognition;
*/
// While SpeechRecognition doesn't support by Chrome in extensions
var useSpeechRecognition = false;

if (widget)
	widget.cfg.getAsync([
							"useEnterToTranslate",
							"defSourceLang", "defTargetLang",
							"maxStoreLangPairs", "mostUsedLangPairs",
							sbStoragePrefix+"detectedInputStringsLang",
							"rememberLastTranslation", "useGoogleCn", "useGoogleTTS", "useSpeechRecognition", "usePersonalDictionary",
							"mode"
						], function(cfg)
	{
		useEnterToTranslate = (cfg.useEnterToTranslate == "true");

		if (languages[cfg.defSourceLang])
			defSourceLang = cfg.defSourceLang;

		if (languages[cfg.defTargetLang])
			defTargetLang = cfg.defTargetLang;

		if ((cfg.maxStoreLangPairs != null) && (cfg.maxStoreLangPairs-0) >= 0)
			maxStoreLangPairs = cfg.maxStoreLangPairs-0;

		if (cfg.mostUsedLangPairs)
		{
			mostUsedLangPairs = JSON.parse(cfg.mostUsedLangPairs);

			// filter old values
			for (var pair in mostUsedLangPairs)
				if (pair.indexOf("~") < 0)
					delete mostUsedLangPairs[pair];
			//
		}

		//useGoogleDict = ((cfg.useGoogleDict == null) || (cfg.useGoogleDict == "true"));

		if (cfg[sbStoragePrefix+"detectedInputStringsLang"] != null)
			detectedInputStringsLang = cfg[sbStoragePrefix+"detectedInputStringsLang"];

		rememberLastTranslation = ((cfg.rememberLastTranslation == null) || (cfg.rememberLastTranslation == "true"));

		useGoogleCn = (cfg.useGoogleCn == "true");

		useGoogleTTS = (((cfg.useGoogleTTS == null) || (cfg.useGoogleTTS == "true")) && (cfg.mode != "demo"));
		usePersonalDictionary = ((cfg.usePersonalDictionary == null) || (cfg.usePersonalDictionary == "true"));
//		useSpeechRecognition = SpeechRecognition && (((cfg.useSpeechRecognition == null) || (cfg.useSpeechRecognition == "true")) && (cfg.mode != "demo"));

		if (cfg.mode != "demo")
		{
			var firstScript = document.getElementsByTagName("SCRIPT")[0];

			var new_script = document.createElement("SCRIPT");
			new_script.src = "js/libs/wanakana.js";
			firstScript.parentNode.insertBefore(new_script, firstScript);

			var new_script = document.createElement("SCRIPT");
			new_script.src = "js/libs/wanahangul.js";
			firstScript.parentNode.insertBefore(new_script, firstScript);
		}
	});

var lastNonAutodetect = "";
//var lastTargetLang = "";
//var lastChoosedProvider = "";

var msAppId = "";
var yaAppId = "";
var udAppId = "";
var bdAppId = "";
var bdSignId = "";

var last_inited_ime = null;

function SetupImeBasedOnFromLang()
{
	if (widget.mode == "demo")
		return;

	var fromLang = document.getElementById("fromLang");
	var fromText = document.getElementById("fromText");
	var from_langs = fromLang.value.split('~', 2);

	if (last_inited_ime != from_langs[0])
	{
		// deinit previous IME
		switch (last_inited_ime)
		{
			case "ja":
				wanakana.unbind( fromText );
				break;

			case "ko":
				wanahangul.unbind( fromText );
				break;
		}
		last_inited_ime = null;

		// init new IME
		switch (from_langs[0])
		{
			case "ja":
				wanakana.bind( fromText );
				last_inited_ime = "ja";
				break;

			case "ko":
				wanahangul.bind( fromText );
				last_inited_ime = "ko";
				break;
		}
	}
}

function ChangeFromLang(sender)
{
	var lngs = sender.value.split('~', 2);
	var new_cfg = {};
	new_cfg[sbStoragePrefix+"translateFromLang"] = lngs[0];
	widget.cfg.setAsync(new_cfg);

	if (lngs.length > 1)	// if we have pair
	{
		var toLang = document.getElementById("toLang");
		toLang.value = lngs[1];
		ChangeToLang( toLang );
		SetupImeBasedOnFromLang();
	}
	else
		RepaintMostUsedLangPairs();

	lastNonAutodetect = lngs[0];		// rewrite on any manual change
}

function ChangeToLang(sender)
{
	var new_cfg = {};
	new_cfg[sbStoragePrefix+"translateToLang"] = sender.value;
	widget.cfg.setAsync(new_cfg);

	var fromLang = document.getElementById("fromLang");
	if (fromLang.value.indexOf('~') >= 0)	// if we have selected language pair
	{
		var lngs = fromLang.value.split('~', 2);
		var newLangPair = lngs[0]+'~'+sender.value;
		var i, len = fromLang.options.length;
		for (i=0; i<len; i++)
			if (fromLang.options[i].value == newLangPair)	// if we have result pair
			{
				fromLang.value = newLangPair;
				RepaintMostUsedLangPairs();
				return;
			}

		fromLang.value = lngs[0];
		RepaintMostUsedLangPairs();
	}

	prevValues["translateToLang"] = sender.value;
}

function ChangeTranslateProvider(new_provider)
{
	var new_cfg = {};
	new_cfg[sbStoragePrefix+"translateProvider"] = new_provider;
	widget.cfg.setAsync(new_cfg);

	if (document.getElementById("translateProvider").value != new_provider)
		document.getElementById("translateProvider").value = new_provider;
	translateProvider = new_provider;

	var lastChoosedProvider = prevValues["translateProvider"];

	// disable / enabled source language combobox
		var fromLangEl = document.getElementById("fromLang");
		if (new_provider == "urban")
		{
			var toLangEl = document.getElementById("toLang");
			if ((lastChoosedProvider != "urban") && (lastChoosedProvider != "dictionaries"))
			{
				lastNonAutodetect = fromLangEl.value;
//				lastTargetLang = toLangEl.value;
				prevValues["translateToLang"] = toLangEl.value;
			}
			fromLangEl.value = "";
			window.setTimeout(function() { fromLangEl.disabled = true; }, 10);	// problem with redraw :(
			toLangEl.value = "en";
			toLangEl.disabled = true;
			document.getElementById("exchangeFromTo").disabled = true;
		}
		else if (new_provider == "dictionaries")
		{
			if (lastChoosedProvider == "urban")
			{
				var toLangEl = document.getElementById("toLang");
				toLangEl.value = prevValues["translateToLang"];
				toLangEl.disabled = false;
			}
			else if (lastChoosedProvider != "dictionaries")
				lastNonAutodetect = fromLangEl.value;
			fromLangEl.value = "";
			window.setTimeout(function() { fromLangEl.disabled = true; }, 10);	// problem with redraw :(
			document.getElementById("exchangeFromTo").disabled = true;
		}
		else
		{
			if (lastChoosedProvider == "dictionaries")
				fromLangEl.value = lastNonAutodetect;

			if (lastChoosedProvider == "urban")
			{
				fromLangEl.value = lastNonAutodetect;
				var toLangEl = document.getElementById("toLang");
				toLangEl.value = prevValues["translateToLang"];
				toLangEl.disabled = false;
			}
			fromLangEl.disabled = false;
			document.getElementById("exchangeFromTo").disabled = false;
		}

//		lastChoosedProvider = new_provider;
		prevValues["translateProvider"] = new_provider;
//		opera.extension.postMessage( {action:"change_translate_provider", provider:new_provider} );

	if (globalShiftKeyActive)
		TranslateText();
	SetupImeBasedOnFromLang();
}

function SetupBackTranslationVisibility( status )
{
//	var argumentStatus = status;
	if (status === undefined)
		status = document.getElementById("chkBackTranslation").checked;
	// do not auto setup checkbox, because this function can temporary hide backtranslation (urban, dictionaries,..)

	var toFromBlock = document.getElementById("to_from_block");

	if (!status || (translateProvider == "dictionaries") || (translateProvider == "urban"))
	{
		// hide backTranslation
		window.setTimeout(function()
		{
			document.getElementsByTagName("FORM")[0].className = "no_back_translation";
			document.getElementById("txtBackTranslation").nextSibling.style.display = "none";
		}, 50);	// problem with redraw fromLang (Opera Classic) :(
	}
	else if (document.getElementsByTagName("FORM")[0].className.indexOf("no_back_translation") > -1)
	{
		// show backTranslation
		document.getElementById("toFromText").value = "";
		window.setTimeout(function()
		{
			document.getElementsByTagName("FORM")[0].className = "";
			document.getElementById("txtBackTranslation").nextSibling.style.display = "inline";
		}, 50);	// problem with redraw fromLang (Opera Classic) :(
	}
}

function RepaintMostUsedLangPairs( langPair )
{
	if (mostUsedLangPairs && maxStoreLangPairs)
	{
		var fromLang = document.getElementById("fromLang");
		var currPair = (langPair ? langPair : fromLang.value);

		while (fromLang.options[0].value !== "")
			fromLang.options.remove(0);

		var pair = "";
		for (pair in mostUsedLangPairs)
		{
			if (fromLang.options[0].value === "")
				fromLang.insertBefore( new Option( "——————————", "---" ), fromLang.options[0] ).disabled = 1;

			var lngs = pair.split('~', 2);
			if (pair == currPair)
			{
				if (lngs[0] === "")
				{
//					fromLang.insertBefore( new Option( (languages[lngs[0]] || WORDS.optAutoDetect) + " → " + languages[lngs[1]], pair ), fromLang.options[0] ).selected = true;
					fromLang.insertBefore( new Option( (languages[lngs[0]] || WORDS.optAutoDetect), pair ), fromLang.options[0] ).selected = true;
					currPair = "";	// Auto detect
				}
				else
					fromLang.insertBefore( new Option( languages[lngs[0]], pair ), fromLang.options[0] ).selected = true;
			}
			else
			{
				fromLang.insertBefore( new Option( "~" + (languages[lngs[0]] || WORDS.optAutoDetect) + " → " + languages[lngs[1]], pair ), fromLang.options[0] );
			}
		}
//		fromLang.value = currPair;
//		fromLang.value = fromLang.value;		// fix for undefined pairs
		if (opera && opera.extension)	// Opera Classic repaint bug
		{
			fromLang.style.opacity = "0.99";
			window.setTimeout(function()
			{
				fromLang.style.opacity = "1";
			}, 100);
		}
	}
	else if (typeof langPair == "string")
	{
		document.getElementById("fromLang").value = langPair.split('~', 2)[0];
	}
	SetupImeBasedOnFromLang();
}

function AddMostUsedLangPair(from_lang, to_lang)
{
	if (maxStoreLangPairs === 0)
		return;

	if (from_lang.indexOf('~') >= 0)
		from_lang = from_lang.split('~', 2)[0];
	var newLangPair = from_lang+'~'+to_lang;

	var keys = [];
	var i, len = 0;
	for (i in mostUsedLangPairs)
	{
		if (newLangPair == i)
		{
			delete mostUsedLangPairs[i];	// for move new pair to the top
			break;
		}
		keys[len++] = i;
	}

	if (len >= maxStoreLangPairs)
		delete mostUsedLangPairs[keys[0]];

	mostUsedLangPairs[newLangPair] = (languages[from_lang] || WORDS.optAutoDetect)	// "Auto detect"
										+ ' - '
										+ languages[to_lang];

	RepaintMostUsedLangPairs( newLangPair );
	widget.cfg.setAsync( {"mostUsedLangPairs": JSON.stringify(mostUsedLangPairs)} );
}

function StoreDetectedInputStringsLang(lang)
{
	detectedInputStringsLang = lang.toLowerCase();

	var new_cfg = {};
	new_cfg[sbStoragePrefix+"detectedInputStringsLang"] = detectedInputStringsLang;
	widget.cfg.setAsync(new_cfg);

	document.getElementById("fromText")["myLanguage"] = detectedInputStringsLang;
}

function FixTextareaButtonsDirection(textarea, value)
{
	if (value == "")	// keep previous settings on clear textarea
		return;

	textarea.dir = rtlDirCheckRe.test(value) ? 'rtl' : (ltrDirCheckRe.test(value) ? 'ltr' : '');
	var ta_parent = textarea.parentNode;
	var ta_direction = GetStyleOfElement(textarea, "direction");
	if (ta_parent.className.indexOf(" "+ta_direction) < 0)
	{
		RemoveClass(ta_parent, "ltr");
		RemoveClass(ta_parent, "rtl");
		AppendClass(ta_parent, ta_direction);
	}
}

//function StoreLastFromText(value, value_lang)
function StoreLastFromText()
{
/*
	var translateLastFromTextKey = sbStoragePrefix+"translateLastFromText";
	var translateLastFromTextLangKey = sbStoragePrefix+"translateLastFromTextLang";
	widget.cfg.getAsync([translateLastFromTextKey, translateLastFromTextLangKey], function(cfg)
	{
		// detect fromText lang
		var fromLang = document.getElementById("fromLang");
		var fromText = document.getElementById("fromText");
		var set_lang = (value_lang ? value_lang : fromLang.value);
		if (set_lang.indexOf("~") >= 0)
		{
			set_lang = set_lang.split("~")[0];
			if ((set_lang == "") && (prevValues[translateLastFromTextKey] == value) && fromText["myLanguage"])	// auto detect and same text
				set_lang = fromText["myLanguage"];
		}

		if ((prevValues[translateLastFromTextKey] == value) && (prevValues[translateLastFromTextLangKey] == set_lang))
			return;

		// update storage
		prevValues[translateLastFromTextKey] = value;
		prevValues[translateLastFromTextLangKey] = set_lang;
		var new_cfg = {};
		if (rememberLastTranslation)
			new_cfg[translateLastFromTextKey] = value;
		else
			new_cfg[translateLastFromTextKey] = "";
		new_cfg[translateLastFromTextLangKey] = set_lang;
		widget.cfg.setAsync(new_cfg);
		fromText["myLanguage"] = set_lang;

		if (!set_lang && (fromLang.value == ""))
			StoreDetectedInputStringsLang("");
		ShowAutodetectedLang( set_lang );

		if (useSpeechRecognition)
			fromLangMicrophone.changeText(value);

		if (useGoogleTTS)
			fromLangListener.changeText(value);

		FixTextareaButtonsDirection( fromText, value );
	});
*/
	var fromLang = document.getElementById("fromLang");
	var fromText = document.getElementById("fromText");

	var lang = fromText["myLanguage"];
	if (!lang)
	{
		lang = fromLang.value;
		if (lang.indexOf("~"))
			lang = lang.split("~")[0];
	}

	var new_cfg = {};
	if (rememberLastTranslation)
		new_cfg[sbStoragePrefix+"translateLastFromText"] = fromText.value;
	else
		new_cfg[sbStoragePrefix+"translateLastFromText"] = "";
	new_cfg[sbStoragePrefix+"translateLastFromTextLang"] = lang;
	widget.cfg.setAsync(new_cfg);

	prevValues["translateLastFromText"] = fromText.value;
	prevValues["translateLastFromTextLang"] = lang;
}

//function StoreLastToText(value)
function StoreLastToText()
{
	var toTextEl = document.getElementById("toText");
//	if (typeof value == "undefined")
//		value = toTextEl.value;

	var new_cfg = {};
	new_cfg[sbStoragePrefix+"translateLastToText"] = toTextEl.value;
	widget.cfg.setAsync(new_cfg);
}

//function StoreLastToFromText(value)
function StoreLastToFromText()
{
	var toFromTextEl = document.getElementById("toText");

	var new_cfg = {};
	new_cfg[sbStoragePrefix+"translateLastToFromText"] = toFromTextEl.value;
	widget.cfg.setAsync(new_cfg);
}

function CheckPossibilityToPutInDictionary()
{
	var from_lang = document.getElementById("fromText")["myLanguage"];
	var from_text = document.getElementById("fromText").value;
	var to_lang = document.getElementById("toText")["myLanguage"];
	var to_text = document.getElementById("toText").value;

	return (from_lang && to_lang && (from_lang !== "") && (from_text !== "") && (to_text !== ""));
}

function AddRemoveTranslationToFavorite()
{
	var from_lang = document.getElementById("fromText")["myLanguage"];
	var from_text = document.getElementById("fromText").value;
	var to_lang = document.getElementById("toText")["myLanguage"];
	var to_text = document.getElementById("toText").value;

	if (!CheckPossibilityToPutInDictionary())
		return;

	widget.cfg.getAsync("myDictionary", function(cfg)
	{
		var dictionary = {};
		if ((cfg["myDictionary"] != null) && (typeof cfg["myDictionary"] == "object") && !cfg["myDictionary"].slice)
			dictionary = cfg["myDictionary"];
		var lang_pair = from_lang + "~" + to_lang;
		if (typeof dictionary[lang_pair] == "undefined")
			dictionary[lang_pair] = [];

		var i, lang_pair_dict = dictionary[lang_pair];
		var found = false;
		for (i in lang_pair_dict)
			if (lang_pair_dict[i] && (lang_pair_dict[i][0] == from_text) && (lang_pair_dict[i][1] == to_text))
			{
				found = true;
				dictionary[lang_pair].splice(i, 1)
				break;
			}
		if (!found)
		{
			dictionary[lang_pair].push([from_text, to_text]);
		}

		var new_cfg = {};
		new_cfg["myDictionary"] = dictionary;
		widget.cfg.setAsync(new_cfg, function()
		{
			RepaintFavoriteButton();
		});
	});
}

function RepaintFavoriteButton()
{
	var from_lang = document.getElementById("fromText")["myLanguage"];
	var from_text = document.getElementById("fromText").value;
	var to_lang = document.getElementById("toText")["myLanguage"];
	var to_text = document.getElementById("toText").value;
	var toTextFavorite = document.getElementById("toTextFavorite");

	// source language is unknown => can't put in dictionary
	if (!CheckPossibilityToPutInDictionary())
	{
		toTextFavorite.classList.remove("favortite");
		toTextFavorite.classList.add("disabled");
		return;
	}
	toTextFavorite.classList.remove("disabled");

	// detect is this translate in dictionary or not
	widget.cfg.getAsync("myDictionary", function(cfg)
	{
		var dictionary = {};
		if (typeof cfg["myDictionary"] != "undefined")
			dictionary = cfg["myDictionary"];
		var lang_pair = (from_lang + "~" + to_lang).replace(/^~/, "");
		if (typeof dictionary[lang_pair] == "undefined")
		{
			toTextFavorite.classList.remove("favortite");
			return;
		}

		var i, lang_pair_dict = dictionary[lang_pair];
		for (i in lang_pair_dict)
			if (lang_pair_dict[i] && (lang_pair_dict[i][0] == from_text) && (lang_pair_dict[i][1] == to_text))
			{
				toTextFavorite.classList.add("favortite");
				return;
			}

		toTextFavorite.classList.remove("favortite");
		return;
	});
}

function RemoveDictionaryFromText(str)
{
	if (str.match(/^([^\[]+)\[[^\n]+\]$/m))			// asd [asd] <= [asd]
	{
		// gogole
		str = Trim(RegExp.$1);
		str = str.replace(/ \<\=$/g, "");	// remove " <="
	}
	else if (str.match(/^([^\n]+)\n\n[^ \:\n]+:\n1\. [^\n]+/g))	// asd\n\nnoun:\n1. asd
	{
		// yandex
		str = Trim(RegExp.$1);
	}
	else if (str.match(/^[^ \:\n]+:\n1\. ([^\n]+)/g))	// noun:\n1. asd\n
	{
		// promt
		str = Trim(RegExp.$1);
	}
	else if (str.match(/^([^\n]+)\n\n[^ \:\n]+:\n- [^\n]+/g))	// noun:\n - asd\n
	{
		// deepl
		str = Trim(RegExp.$1);
	}
	return str;
}

function ExchangeLanguages(evt)
{
	var fromLang = document.getElementById("fromLang");
	var toLang = document.getElementById("toLang");

	var tmp_value = fromLang.value;
	if (tmp_value.indexOf('~') >= 0)
		tmp_value = tmp_value.split('~', 2)[0];

	// if fromLang = auto_detect => DetectUserPreferedLanguage()
	if (tmp_value === "")
	{
		tmp_value = detectedInputStringsLang;
		if ((tmp_value === "") || (tmp_value == toLang.value))
			tmp_value = defTargetLang;
	}
	// if same langauges => from = auto_detect
	if (tmp_value == toLang.value)
		fromLang.value = "";
	else
	{
		ShowAutodetectedLang('');
		fromLang.value = toLang.value;
		StoreDetectedInputStringsLang("");
		toLang.value = tmp_value;

		ChangeFromLang(fromLang);
		ChangeToLang(toLang);

		var fromText = document.getElementById("fromText");

		// exchange texts
		if (evt.shiftKey)
		{
			var toText = document.getElementById("toText");
			var tmp_value = toText.value;
			toText.value = fromText.value;
			fromText.value = RemoveDictionaryFromText(tmp_value);

			OnEventOfFromText();
			OnEventOfToText();

			// user want edit and retranslate in backward order
			fromText.focus();
		}
		else
		{
			// user want enter other sentence
			fromText.select();
			fromText.focus();
		}
	}
	SetupImeBasedOnFromLang();
}


// events handlers
function OnEventOfFromLang(event)
{
	if (event)
	{
		var fromLangEl = this;
		switch (event.type)
		{
			case "focus":
				ShowAutodetectedLang('');
				return true;
			case "keydown":
				return CheckCtrlEnter(event);
			case "change":
				break
		}
	}
	else
	{
		var fromLangEl = document.getElementById("fromLang");
	}

	ChangeFromLang(fromLangEl);

	return true;
}

function OnEventOfToLang(event)
{
	if (event)
	{
		var toLangEl = this;
		switch (event.type)
		{
			case "keydown":
				return CheckCtrlEnter(event);
			case "change":
				break;
		}
	}
	else
	{
		var toLangEl = document.getElementById("toLang");
	}

	ChangeToLang(toLangEl);

	return true;
}

function OnEventOfProvider(event)
{
	if (event)
	{
		var providerEl = this;
		switch (event.type)
		{
			case "keydown":
				return CheckCtrlEnter(event);
			case "input":
			case "change":
				break;
		}
	}
	else
	{
		var providerEl = document.getElementById("translateProvider");
	}

	ChangeTranslateProvider(providerEl.value);

	return true;
}

function OnEventOfFromText(event, new_value, new_value_lang)
{
	var result = true;
	if (event)
	{
		var fromTextEl = this;
		switch (event.type)
		{
			case "keydown":
//				this["myLanguage"] = null;
//				return CheckEnterOrCtrlEnter(event);
				result = CheckEnterOrCtrlEnter(event);
				break;
			case "keyup":
/*
				StoreLastFromText(this.value, false);
				RepaintFavoriteButton();
				break;
*/
			case "change":
				break;
		}
	}
	else
	{
		var fromTextEl = document.getElementById("fromText");
		var fromLangEl = document.getElementById("fromLang");
		if (new_value)
			fromTextEl.value = new_value;
		if (new_value_lang || (new_value_lang === ""))			// autodetected language
		{
			StoreDetectedInputStringsLang( new_value_lang );
			ShowAutodetectedLang( new_value_lang );
		}
	}

	StoreLastFromText();
	RepaintFavoriteButton();
	FixTextareaButtonsDirection( fromTextEl, fromTextEl.value );

	if (useSpeechRecognition)
		fromLangMicrophone.changeText(fromTextEl.value);

	if (useGoogleTTS)
		fromLangListener.changeText(fromTextEl.value);

	return result;
}

function OnEventOfToText(event)
{
	if (event)
	{
		var toTextEl = this;
	}
	else
	{
		var toTextEl = document.getElementById("toText");
		var toLangEl = document.getElementById("toLang");
	}

	StoreLastToText();
	RepaintFavoriteButton();
	FixTextareaButtonsDirection( toTextEl, toTextEl.value );

	if (useGoogleTTS)
		toLangListener.changeText(toTextEl.value);

	return true;
}

function OnEventOfFromToText(event)
{
	if (event)
	{
		var toFromText = this;
	}
	else
	{
		var toFromText = document.getElementById("toFromText");
	}

	StoreLastToFromText();
	FixTextareaButtonsDirection( toFromText, toFromText.value );
	console.log(toFromText.value);

	if (useGoogleTTS)
		toFromLangListener.changeText(toFromText.value);

	return true;
}
/*
function OnTranslate()
{
	RepaintFavoriteButton();

	return true;
}
*/
//


function StartTranslateByHotkey(evt)
{
	document.getElementById("fromText").focus();
	TranslateText();

	// do not reload popup
	if (evt.stopPropagation) evt.stopPropagation();
	if (evt.preventDefault) evt.preventDefault();
	evt.cancelBubble = true;
	evt.returnValue = false;
	return false;
}

function CheckEnterOrCtrlEnter(evt)
{
	if (useEnterToTranslate && (evt.keyCode == 13))
		return StartTranslateByHotkey(evt);
	return CheckCtrlEnter(evt);
}

function CheckCtrlEnter(evt)
{
	if (evt.ctrlKey && (evt.keyCode == 13))
		return StartTranslateByHotkey(evt);
	return true;
}


var animation, lastAnimatedChar = "";
function StartTranslatingAnimation()
{
	var animationTarget = (backTranslating ? "toFromText" : "toText");
	if (animation)
		StopTranslatingAnimation();
	animation = window.setInterval(function()
	{
		if (lastAnimatedChar === "") lastAnimatedChar = "|";
		else if (lastAnimatedChar == "|") lastAnimatedChar = "/";
		else if (lastAnimatedChar == "/") lastAnimatedChar = "-";
		else if (lastAnimatedChar == "-") lastAnimatedChar = "\\";
		else if (lastAnimatedChar == "\\") lastAnimatedChar = "|";
		if (animation)
			document.getElementById(animationTarget).value = lastAnimatedChar;
	}, 50);
}

function StopTranslatingAnimation()
{
	window.clearInterval(animation);
	animation = null;
	lastAnimatedChar = "";
}

function ShowAutodetectedLang(detectedLang)
{
	var fromLang = document.getElementById("fromLang");

	if ((fromLang.options[ fromLang.selectedIndex ].value === "") || (fromLang.options[ fromLang.selectedIndex ].value.indexOf("~") === 0))
	{
		if (!languages[detectedLang] && (detectedLang.indexOf("-") > 0))
		{
			// try find zh-CN
			var parts = detectedLang.split("-");
			parts[1] = parts[1].toUpperCase();
			if (languages[parts.join("-")])
				detectedLang = parts.join("-");
			else
			{
				// try find sr-Cyrl
				parts = detectedLang.split("-");
				parts[1] = parts[1].charAt(0).toUpperCase() + parts[1].substr(1);
				if (languages[parts.join("-")])
					detectedLang = parts.join("-");
			}
		}

		if (detectedLang && languages[detectedLang])
			fromLang.options[ fromLang.selectedIndex ].text = (WORDS ? WORDS.optAutoDetect : "Auto detect") + " ("+languages[detectedLang]+")";	// Auto detect
		else
			fromLang.options[ fromLang.selectedIndex ].text = (WORDS ? WORDS.optAutoDetect : "Auto detect");	// "Auto detect";
	}
}


function ClearText()
{
	document.getElementById("fromText").value = "";
	document.getElementById("toText").value = "";
	document.getElementById("toFromText").value = "";
//	StoreLastFromText("");
	OnEventOfFromText();
//	StoreLastToText("");
	OnEventOfToText();
	StoreLastToFromText("");
	SetupUIBasedOnMode(widget.mode);
}

function onMessageHandler(msg, sender)
{
	if (opera)
	{
		sender = msg.source;
		msg = msg.data;
	}

	if (typeof msg == "undefined")
		msg = {};

	if (msg.action == "set_active_page_data")
	{
		activePage = { url:msg.url, title:msg.title };
		if (activePage.url)
		{
			// 	var tab = opera.extension.bgProcess.opera.extension.tabs.getFocused();	// still not better :(
			var btnTranslateUrl = document.getElementById("btnTranslateUrl");
			btnTranslateUrl.style.visibility = "visible";
			btnTranslateUrl.getElementsByTagName("SPAN")[1].innerText = '"'+activePage.title+'"';
			btnTranslateUrl.title = activePage.title;
		}

		var fromText = document.getElementById("fromText");
		var fromLang = document.getElementById("fromLang");
		widget.cfg.getAsync([
								sbStoragePrefix+"translateLastFromText",
								sbStoragePrefix+"translateLastFromTextLang",
								sbStoragePrefix+"translateLastToText",
								sbStoragePrefix+"translateLastToFromText"
							], function(cfg)
		{
			prevValues["translateLastFromText"]		= cfg[sbStoragePrefix+"translateLastFromText"];
			prevValues["translateLastFromTextLang"]	= cfg[sbStoragePrefix+"translateLastFromTextLang"];
			prevValues["translateLastToText"]		= cfg[sbStoragePrefix+"translateLastToText"];
			prevValues["translateLastToFromText"]	= cfg[sbStoragePrefix+"translateLastToFromText"];
			if (!rememberLastTranslation)
			{
				prevValues["translateLastFromText"]	= "";
				prevValues["translateLastToText"]	= "";
			}

			var prev_value		= prevValues["translateLastFromText"];
			var prev_value_lang	= prevValues["translateLastFromTextLang"];

			if (msg.selection && (prev_value != msg.selection))		// if new selection
			{
				fromText.value = msg.selection;
				fromText.select();
//				StoreLastFromText(fromText.value);
				OnEventOfFromText();

				// pragma and yandex
				var provider = document.getElementById("translateProvider").value;
				if ((defSourceLang !== "")
					|| ((provider != "pragma") && (provider != "yandex")))
				{
					fromLang.value = defSourceLang;
					ChangeFromLang(fromLang);
				}

				TranslateText(true);
			}
			else
			{
				if (prev_value)
				{
					fromText.value = prev_value;
					fromText["myLanguage"] = prev_value_lang;
					if (useSpeechRecognition)
						fromLangMicrophone.changeText(prev_value);
					if (useGoogleTTS)
						fromLangListener.changeText(prev_value);
					fromText.select();
					FixTextareaButtonsDirection(fromText, prev_value);
				}

				if (rememberLastTranslation && (prev_value = cfg[sbStoragePrefix+"translateLastToText"]))
				{
					var toText = document.getElementById("toText");
					toText.value = prev_value;
					toText["myLanguage"] = document.getElementById("toLang").value;
					if (useGoogleTTS)
						toLangListener.changeText(prev_value);
					FixTextareaButtonsDirection(toText, prev_value);
				}

				if (rememberLastTranslation && (prev_value = cfg[sbStoragePrefix+"translateLastToFromText"]))
				{
					var toFromText = document.getElementById("toFromText");
					toFromText.value = prev_value;
					if (useGoogleTTS)
						toFromLangListener.changeText(prev_value);
					FixTextareaButtonsDirection(toFromText, prev_value);
				}

				RepaintFavoriteButton();
			}
		});
	}
	else if (msg.action == "fix_elements_size")	// on resize (Opera did not support onResize event handler for popups)
	{
/*
		// fix sizes of language lists
		var fromLang = document.getElementById("fromLang");
		fromLang.style.width = (fromLang.myDefaultWidth + Math.floor(msg.deltaX / 2)) + "px";
		var toLang = document.getElementById("toLang");
		toLang.style.width = (toLang.myDefaultWidth + Math.floor(msg.deltaX / 2)) + "px";

		// get to_from_block height
		var minusHeight = 0;
		if (document.getElementById("to_from_block").style.display == "block")
			minusHeight = document.getElementById("to_from_block").clientHeight;

		// fix sizes of textareas
		var textarea = document.getElementById("result_as_text").getElementsByTagName("TEXTAREA")[0];
		textarea.style.height = (textarea.myDefaultHeight + msg.deltaY - minusHeight) + "px";
		var iframe = document.getElementById("result_as_html").getElementsByTagName("IFRAME")[0];
		iframe.style.height = (iframe.myDefaultHeight + msg.deltaY - minusHeight) + "px";
*/
	}
	else if (msg.action == "setup_msAppId")
	{
		window.msAppId = msg.value;
//		if (status.data["refreshed"]) TranslateText();
//		if (status.data["next_action"] == "retranslate") TranslateText();
		if (msg.next_action == "retranslate")
			TranslateText();
		else if (msg.next_action == "replay")
			( msg.next_action_args["player"] == "from"
				? fromLangListener
				: (msg.next_action_args["player"] == "toFrom"
					? toFromLangListener
					: toLangListener)
			).play();
	}
	else if (msg.action == "setup_yaAppId")
	{
		window.yaAppId = msg.value;
		if (msg.next_action == "retranslate")
			TranslateText();
	}
	else if (msg.action == "setup_udAppId")
	{
		window.udAppId = msg.value;
		if (msg.next_action == "retranslate")
			TranslateText();
	}
	else if (msg.action == "setup_bdAppId")
	{
		window.bdAppId = msg.value;
		window.bdSignId = msg.value2;
		if (msg.next_action == "retranslate")
			TranslateText();
	}
	else if (msg.action == "retranslate_text")
	{
		TranslateText();
	}

	return true;
}

function OnOpenLinkInSeparateTab()
{
	// currently Edge can't open regular link to other extension page
	// this is workaround
	if (is_edge)
	{
		chrome.tabs.create({ url: document.URL.replace("popup.html", "options.html") });
		return false;
	}
	else if (opera)
		this.target = "_blank";	// Opera Classic does not support named windows here

	return true;	// Chrome support regular links
}


var translateProvider = "";
var backTranslation = "false";
window.addEventListener('load', function()
{
	translateProvider = document.getElementById("translateProvider").value;
/*
	// setup default sizes
	if (!popupInSidebar)
	{
		var fromLang = document.getElementById("fromLang");
		fromLang.myDefaultWidth = fromLang.clientWidth;
		var toLang = document.getElementById("toLang");
		toLang.myDefaultWidth = toLang.clientWidth;

		var textarea = document.getElementById("result_as_text").getElementsByTagName("TEXTAREA")[0];
		textarea.myDefaultHeight = popupMinimumSize.height - (document.getElementsByTagName("FORM")[0].clientHeight - textarea.clientHeight);
		var iframe = document.getElementById("result_as_html").getElementsByTagName("IFRAME")[0];
		iframe.myDefaultHeight = textarea.myDefaultHeight;
	}
	//
*/

//	if (window.innerWidth < popupMinimumSize.width)
	if (popupInSidebar)
		document.getElementById("exchangeFromTo").getElementsByTagName("SPAN")[0].innerText = "ʌ - v";

//	document.getElementById("fromText").addEventListener('mouseup', PasteTextToSourceText, false);

	var i;

	if (WORDS)
	{
		document.getElementById("txtUse").innerText					= WORDS.txtUse;
		document.getElementById("txtBackTranslation").innerText		= WORDS.txtBackTranslation;
//		document.getElementById("txtBackTranslationTitle").innerText= WORDS.txtBackTranslation;
		document.getElementById("btnTranslate").value				= WORDS.btnTranslate;
		document.getElementById("btnClear").value					= WORDS.btnClear;

		document.getElementById("exchangeFromTo").title			= WORDS.hntFullExchange;
		document.getElementById("fromText").title				= WORDS.hntTranslate;
		document.getElementById("translateProvider").title		= WORDS.hntReTranslate;

		if (usePersonalDictionary)
		{
			document.getElementById("lnkDictionaryPage").innerText	= WORDS.txtDictionary;
			document.getElementById("lnkDictionaryPage").addEventListener("click", OnOpenLinkInSeparateTab);
		}
		else
			document.getElementById("lnkDictionaryPage").parentNode.style.display = "none";


		document.getElementById("lnkSettingsPage").innerText = WORDS.lnkSettingsPage;
		document.getElementById("lnkSettingsPage").addEventListener("click", OnOpenLinkInSeparateTab);

		var services = document.getElementById("translateProvider").options;
		var len = services.length;
		for (i=0; i<len; i++)
		{
			if (services[i].value == "google")				services[i].text = WORDS.byGoogle;
			else if (services[i].value == "bing")			services[i].text = WORDS.byBing;
			else if (services[i].value == "yandex")			services[i].text = WORDS.byYandex;
			else if (services[i].value == "promt")			services[i].text = WORDS.byPromt;
			else if (services[i].value == "pragma")			services[i].text = WORDS.byPragma;
			else if (services[i].value == "baidu")			services[i].text = WORDS.byBaidu;
			else if (services[i].value == "babylon")		services[i].text = WORDS.byBabylon;
			else if (services[i].value == "dictionaries")	services[i].text = WORDS.byBabylonDictionaries;
			else if (services[i].value == "deepl")			services[i].text = WORDS.byDeepl;
		}

		document.getElementById("btnTranslateUrl").getElementsByTagName("SPAN")[0].innerText = WORDS.txtTranslateActivePage;
	}
	/////////////////////////////////////////////////////////////


	if (widget)
		widget.cfg.getAsync([
								"useTextareaFont",
								"buttonPosition", "buttonPositionInvert",
								sbStoragePrefix+"translateProvider",
								sbStoragePrefix+"backTranslation",
								sbStoragePrefix+"translateFromLang",
								sbStoragePrefix+"translateToLang"
							], function(cfg)
		{
			if (cfg.useTextareaFont && cfg.useTextareaFont.length > 0)
			{
				var tas = document.getElementsByTagName("TEXTAREA");
				for (i=0; i<tas.length; i++)
					tas[i].style.fontFamily = cfg.useTextareaFont;
			}

			// setup button position
			if (cfg.buttonPosition == "left")
				document.getElementById("submitButtons").className += " invert";

			if (cfg.buttonPositionInvert == "true")
			{
				var btnClear = document.getElementById("btnClear");
				var tmpParent = btnClear.parentNode;
				tmpParent.insertBefore( tmpParent.removeChild(btnClear), document.getElementById("btnTranslate") );
			}

			// setup translateProvider
				if (cfg[sbStoragePrefix+"translateProvider"])
					translateProvider = cfg[sbStoragePrefix+"translateProvider"];
				ChangeTranslateProvider(translateProvider);

			// setup backTranslation checkbox
				backTranslation = cfg[sbStoragePrefix+"backTranslation"];
				document.getElementById("chkBackTranslation").checked = (backTranslation == "true" && (widget.mode != "demo"));
				SetupBackTranslationVisibility();


			// setup fromLangs
				var fromLang = document.getElementById("fromLang");
				fromLang.options.remove(0);

				fromLang.options.add( new Option( WORDS ? WORDS.optAutoDetect : "Auto detect", "" ) );	// "Auto detect"
				fromLang.options.add( new Option( "——————————", "---" ) );
				fromLang.options[fromLang.options.length-1].disabled = 1;

				for (i in languages)
					fromLang.options.add( new Option( languages[i], i ) );

				fromLang.value = cfg[sbStoragePrefix+"translateFromLang"] || defSourceLang || "";

			// setup toLangs
				var toLang = document.getElementById("toLang");
				toLang.options.remove(0);
				for (i in languages)
					toLang.options.add( new Option( languages[i], i ) );

				prevValues["translateToLang"] = cfg[sbStoragePrefix+"translateToLang"] || defTargetLang || "";
				if (toLang.disabled)
				{
					// provider without target language (Urban Dictionary)
					toLang.value = "en";
				}
				else
				{
					toLang.value = prevValues["translateToLang"];
					if (toLang.value === "")					// toLang don't has Auto-detect => select first item
						toLang.options[0].selected = true;
				}

				RepaintMostUsedLangPairs( fromLang.value+'~'+toLang.value );
				ShowAutodetectedLang( detectedInputStringsLang );
		});


//	document.getElementById("result_as_html").style.display = "none";

		if (useSpeechRecognition)	// && !demo
		{
			fromLangMicrophone.button = document.getElementById("fromTextMicrophone");
			fromLangMicrophone.source = document.getElementById("fromText");
			fromLangMicrophone.language = document.getElementById("fromLang");

			fromLangMicrophone.button.style.display = "block";
		}

	// init TTS buttons
		if (useGoogleTTS)
		{
			fromLangListener.button = document.getElementById("fromTextPlayer");
			fromLangListener.source = document.getElementById("fromText");
			fromLangListener.language = document.getElementById("fromLang");
			toLangListener.button = document.getElementById("toTextPlayer");
			toLangListener.source = document.getElementById("toText");
			toLangListener.language = document.getElementById("toLang");
			toFromLangListener.button = document.getElementById("toFromTextPlayer");
			toFromLangListener.source = document.getElementById("toFromText");
			toFromLangListener.language = document.getElementById("fromLang");

			fromLangListener.button.style.display = "block";
			toLangListener.button.style.display = "block";
			toFromLangListener.button.style.display = "block";
		}

		if (usePersonalDictionary)
		{
			var toTextFavorite = document.getElementById("toTextFavorite");
			toTextFavorite.style.display = "block";
			toTextFavorite.classList.remove("disabled");
		}

	// data for resize
		if (!popupInSidebar)
		{
			if (opera && opera.extension)
				opera.extension.postMessage( {action:"change_popup_size", deltaX:0, deltaY:0} );
			else// if ((typeof chrome != "undefined") && chrome.runtime.onMessage)
			{
				widget.cfg.getAsync("popupSize", function(cfg)
				{
					propPopupSize = FixCfgPopupSize(cfg.popupSize);

					var form = document.getElementsByTagName("FORM")[0];
					form.style.width = (propPopupSize[0] - 10 - 15) + "px";	// minus paddings
					form.style.height = (propPopupSize[1] - 10 - 10) + "px";	// minus paddings

					// Alpha versions of Opera can be broken with regular size => setup minimum
					form.style.minWidth = popupMinimumSize.width + "px";
					form.style.minHeight = popupMinimumSize.height + "px";
				});
/*
				// new layout not require fix elements. Made by CSS
				onMessageHandler({
					action: "fix_elements_size",
					deltaX: parseInt(form.style.width)-popupMinimumSize.width,
					deltaY: parseInt(form.style.height)-popupMinimumSize.height
				});
*/
			}
		}

	// try to get page selection or load previous used data
		if (popupInSidebar)
		{
			// for sidebar we don't need page selection
			onMessageHandler({ action:"set_active_page_data" }, window);
		}
		else
		{
			if (opera && opera.extension)
			{
				opera.extension.onmessage = onMessageHandler;
/*
				opera.extension.postMessage( {action:"get_active_page_data"} );
*/
		//		if (useGoogleTTS)
		//			opera.extension.postMessage( {action:"get_msAppId"} );
			}
			else if (chrome)
			{
				if (chrome.runtime.onMessage)
				{
					chrome.runtime.onMessage.addListener( onMessageHandler );
/*
					chrome.runtime.getBackgroundPage( function(bgPage){
						bgPage.onMessageHandler( {action:"get_active_page_data"}, window );
//						bgPage.postMessage( {action:"get_active_page_data", sender:window} );
					});
*/
/*
					if (backgroundPage)
						backgroundPage.onMessageHandler( {action:"get_active_page_data"}, window );
*/
				}
			}

			SendMessageToBackgroundScript( {action:"get_active_page_data"} );
		}

		document.getElementById("fromText").focus();
}, false);

if (useSpeechRecognition)
{
	var fromLangMicrophone	= { button:null, source:null, language:null, status:-1, mic:null };

	fromLangMicrophone.changeText = function(text)
	{
		if (this.status > 0)
			this.stop();
		this.status = -1;

		if (this.button)
		{
			if (text.length)
				this.button.className = "microphone_button";
			else
				this.button.className = "microphone_button disabled";
		}
	};
	fromLangMicrophone.stop = function()
	{
		if (this.mic)
			this.mic.stop();
		this.status = 0;
		this.button.innerText = "";
		this.button.className = "microphone_button";
	};

	fromLangMicrophone.listen = function()
	{
		if (this.status == 1)
			return this.stop();

		var recognizer = new SpeechRecognition();
		this.mic = recognizer;
		recognizer.interimResults = true;
		/*
		Problem solution for mobile devices:
			recognition.continuous = false;
			recognition.interimResults = false;
		*/
		recognizer.lang = this.language;
		var sender = this;
		recognizer.onresult = function (event)
		{
			var result = event.results[event.resultIndex];
			var fromText = document.getElementById("fromText");
			fromText.value += result[0].transcript;

			if (result.isFinal)
			{
				sender.stop();
//				StoreLastFromText(fromText.value);
				OnEventOfFromText();
			}
		};
		recognizer.onerror = function(event)
		{
			var fromText = document.getElementById("fromText");
			fromText.value = event.error + (event.message !== "" ? ": "+event.message : "");
			sender.stop();
		};
		recognizer.start();

		this.status = 1;
		this.button.className = "microphone_button listening";
	};
}

if (useGoogleTTS)
{
	// http://flash-mp3-player.net/players/js/
	// status: -1 - not loaded, 0 - stopped, 1 - playing
	var fromLangListener	= { button:null, source:null, language:null, status:-1, playingTimer:null, player:null };
	var toLangListener		= { button:null, source:null, language:null, status:-1, playingTimer:null, player:null };
	var toFromLangListener	= { button:null, source:null, language:null, status:-1, playingTimer:null, player:null };
//	fromLangListener.onInit = toLangListener.onInit = toFromLangListener.onInit = function() { alert("init!"); this.position = 0; };
	fromLangListener.changeText = toLangListener.changeText = toFromLangListener.changeText = function(text)
	{
		if (this.status > 0)
			this.stop();
		this.status = -1;

		if (this.button)
		{
			if (text.length)
				this.button.className = "player_button";
			else
				this.button.className = "player_button disabled";
		}
	};
	fromLangListener.stop = toLangListener.stop = toFromLangListener.stop = function()
	{
		if (this.player)
		{
			if (this.player.stop)
				this.player.stop();
			else if (this.player.pause)
				this.player.pause();
		}
		this.status = 0;
		this.button.innerText = "";
		this.button.className = "player_button";
		if (this.playingTimer)
		{
//			clearTimeout(this.playingTimer);
			this.playingTimer = null;
		}
	};

	fromLangListener.play = toLangListener.play = toFromLangListener.play = function(sender, by_browser_tts)
	{
		if (this.source.value === "")	return;
		if (this.status == 1)			return this.stop();

		var speechText = this.source.value;
		if ((this.source.id == "toText") || (this.source.id == "toFromText"))
			speechText = RemoveDictionaryFromText(speechText);

		// Microsoft's wav-files supported by <audio>
		// http://api.microsofttranslator.com/v2/http.svc/Speak?language=en&appid=TISQKDDbZzWSRopWpt2o9iaGQ5dgoqDOM1TfrkF4MUN4*&text=test

		// Yandex's wav-files supported by <audio>
		// https://tts.voicetech.yandex.net/tts?format=wav&quality=hi&platform=web&application=translate&lang=ru_RU&text=%D1%82%D0%B5%D1%81%D1%82
		// But only for russian?

		// Google support only mp3
		// https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=test+window&tl=en

		// TODO: instead of using lang_default_locales[] try to get supporting language online + cache result
		var text_lang = (this.source["myLanguage"] || this.language.value.split("~")[0] || detectedInputStringsLang || "en");
		var lastChoosedProvider = prevValues["translateProvider"];

		if (!by_browser_tts && (!lang_default_locales[text_lang] || (lastChoosedProvider == "google")) && (supportMP3 || (supportMP3 === null && (supportMP3 = (new Audio()).canPlayType("audio/mpeg")) )))
		{
			this.player = new Audio("https://translate.google."+(useGoogleCn ? "cn" : "com")+"/translate_tts?ie=UTF-8&client=tw-ob"
									+"&tl=" + (this.source["myLanguage"] || this.language.value.split("~")[0] || detectedInputStringsLang || "en")
									+"&q=" + encodeURIComponent(speechText.substr(0, 100)));
		}
		else if (!by_browser_tts && lang_default_locales[text_lang])
		{
			if (msAppId === "")
			{
				var player_type = (this.source.id.indexOf("from") === 0
									? "from"
									: (this.source.id.indexOf("toFrom") === 0
										? "toFrom"
										: "to"));
				SendMessageToBackgroundScript( { action: "get_msAppId", next_action:"replay", next_action_args:{player:player_type} } );
				return;
			}

//		     http://api.microsofttranslator.com/V2/Ajax.svc/Speak
/*
			// deprecated :(
			this.player = new Audio("http://api.microsofttranslator.com/v2/http.svc/Speak"
									+"?language=" + (this.source["myLanguage"] || this.language.value.split("~")[0] || detectedInputStringsLang || "en")
									+"&appid=Bearer%20" + encodeURIComponent(msAppId)
									+"&text=" + encodeURIComponent(speechText.substr(0, 100)));
*/
			// https://www.bing.com/translator/api/language/Speak?locale=en-US&gender=male&media=audio/mp3&text=was -- But it require -US...
			// https://www.bing.com/translator/api/language/Speak?locale=ru-RU&gender=male&media=audio/mp3&text=%D1%82%D0%B5%D1%81%D1%82
			this.player = new Audio("https://www.bing.com/translator/api/language/Speak"
									+"?locale=" + lang_default_locales[text_lang]
									+"&gender=male"
									+"&media=audio/wav"
									+"&text=" + encodeURIComponent(speechText.substr(0, 100)));
		}
		else if (chrome && chrome.tts)	// unsupported language + format
		{
			var sender = this;
			chrome.tts.speak(speechText.substr(0, 100), {"lang":text_lang, "onEvent":function(event)
																			{
																				switch (event.type)
																				{
																					case "cancelled":
																					case "interrupted":
																					case "error":
																					case "end":
																						sender.stop();
																						break;
																				}
																			}});
			this.player = chrome.tts;	// it also has .stop()
		}
		else
			return;

//		sender.appendChild(player);
		if (this.player.play)		// tts doesn't has play()
			this.player.play();

		this.status = 1;
		this.button.className = "player_button playing";
		if (this.player.addEventListener)
		{
			sender = this;
			this.player.addEventListener("ended", function(){ sender.stop(); }, false);
			// if web-speech is broken, try use browser's tts
			this.player.addEventListener("error", function(){ sender.status = 0; sender.play(sender.button, true); }, false);
		}
	};
}



var resizeStartPosForm	= {x:0, y:0};
var resizeStartPos		= {x:0, y:0};
var resizeLastPos		= {x:0, y:0};
var resizePopupTimer	= null;

function resizeSendNewDeltas(e)
{
	if (opera)
	{
		opera.extension.postMessage({
			action: "change_popup_size",
			deltaX: resizeStartPos.x-resizeLastPos.x,
			deltaY: resizeLastPos.y-resizeStartPos.y
		});
	}
	else
	{
		var form = document.getElementsByTagName("FORM")[0];
		var form_width, form_height;

		if (popupMinimumSize.width < (resizeStartPosForm.x + resizeStartPos.x-resizeLastPos.x))
			form_width = (resizeStartPosForm.x + resizeStartPos.x-resizeLastPos.x);
		else
			form_width = popupMinimumSize.width;

		if (popupMinimumSize.height < (resizeStartPosForm.y + resizeLastPos.y-resizeStartPos.y))
			form_height = (resizeStartPosForm.y + resizeLastPos.y-resizeStartPos.y);
		else
			form_height = popupMinimumSize.height;

		// Chrome has limits :/ (800x600)
		if (form_width > 775)
			form_width = 775;
		if (form_height > 580)
			form_height = 580;

		form.style.width = form_width + "px";
		form.style.height = form_height + "px";

		onMessageHandler({
			action: "fix_elements_size",
			deltaX: form_width-popupMinimumSize.width,
			deltaY: form_height-popupMinimumSize.height
		});
	}
}

function resizeMouseMove(e)
{
	window.clearTimeout(resizePopupTimer);
	resizeLastPos.x = e.screenX;
	resizeLastPos.y = e.screenY;
	resizePopupTimer = window.setTimeout(resizeSendNewDeltas, 10);
}

function resizeMouseUp(e)
{
	if (e.bubbles !== undefined)	// if function was called manual => do not setup handlers
	{
//		resizeMouseMove(e);			// we have some problems with this actions :(
		window.document.body.style.cursor = "auto";

		window.removeEventListener('mouseup', resizeMouseUp);
		window.removeEventListener('mousemove', resizeMouseMove);
	}

	if (opera)
		opera.extension.postMessage( {action:"save_popup_size"} );
	else
	{
//		chrome.runtime.sendMessage( {action:"save_popup_size"} );
		var form = document.getElementsByTagName("FORM")[0];
		widget.cfg.setAsync( {"popupSize": (parseInt(form.style.width)+10+15) + "x" + (parseInt(form.style.height)+10+10)} );	// plus paddings
	}
}

function StartResizePopup(e)
{
	resizeStartPos.x = e.screenX;
	resizeStartPos.y = e.screenY;

	var form = document.getElementsByTagName("FORM")[0];
	resizeStartPosForm.x = parseInt(document.defaultView.getComputedStyle(form, "").getPropertyValue("width"));
	resizeStartPosForm.y = parseInt(document.defaultView.getComputedStyle(form, "").getPropertyValue("height"));

	if (e.bubbles !== undefined)	// if function was called manual => do not setup handlers
	{
		window.document.body.style.cursor = "ne-resize";

		window.addEventListener('mouseup', resizeMouseUp, false);
		window.addEventListener('mousemove', resizeMouseMove, false);
	}
	return false;
}
/*
function PasteTextToSourceText(evt)
{
	if (!evt.which || evt.which != 3) return true;	// right click
	if (!globalShiftKeyActive) return true;			// with Shift key

//	var pasteEvent = new ClipboardEvent('paste', { bubbles: true, cancelable: true, dataType: 'text/plain', data: 'My string' } );
	var pasteEvent = new ClipboardEvent('paste', { bubbles: true, cancelable: true, dataType: 'text/plain' } );
	evt.srcElement.dispatchEvent(pasteEvent);
	evt.stopPropagation();
	return false;
}
*/

var globalShiftKeyActive = false;

window.addEventListener('DOMContentLoaded', function()
{
	var setupGlobalShiftKeyActive = function(evt) { globalShiftKeyActive = evt.shiftKey; };
	window.addEventListener('keydown', setupGlobalShiftKeyActive, false);	// in Opera 11.xx without third parameter don't work
	window.addEventListener('keyup', setupGlobalShiftKeyActive, false);

	if (popupInSidebar)
		document.getElementsByTagName("HTML")[0].className = "sidebar";

	document.getElementsByTagName("FORM")[0].addEventListener("submit", function(event) { return false; }, false);

	var fromLang = document.getElementById("fromLang");
	fromLang.addEventListener("keydown", OnEventOfFromLang, false);
	fromLang.addEventListener("change", OnEventOfFromLang, false);
	fromLang.addEventListener("focus", OnEventOfFromLang, false);

	var exchangeFromTo = document.getElementById("exchangeFromTo");
	exchangeFromTo.addEventListener("keydown", function(event) { return CheckCtrlEnter(event); }, false);
	exchangeFromTo.addEventListener("click", function(event) { ExchangeLanguages(event); }, false);

	var toLang = document.getElementById("toLang");
	toLang.addEventListener("keydown", OnEventOfToLang, false);
	toLang.addEventListener("change", OnEventOfToLang, false);

	var fromText = document.getElementById("fromText");
	fromText.addEventListener("keydown", OnEventOfFromText, false);
	fromText.addEventListener("keyup", OnEventOfFromText, false);
	fromText.addEventListener("change", OnEventOfFromText, false);

	document.getElementById("fromTextMicrophone").addEventListener("click", function(event) { fromLangMicrophone.listen(this); }, false);
	document.getElementById("fromTextPlayer").addEventListener("click", function(event) { fromLangListener.play(this); }, false);
	document.getElementById("toTextFavorite").addEventListener("click", function(event) { AddRemoveTranslationToFavorite(); }, false);

	var translateProvider = document.getElementById("translateProvider");
	translateProvider.addEventListener("keydown", OnEventOfProvider, false);
	translateProvider.addEventListener("input", OnEventOfProvider, false);		// Firefox did not support it => duplicate for onChange
	translateProvider.addEventListener("change", OnEventOfProvider, false);		// in Chrome work only when lose focus

	document.getElementById("copyrightTarget").addEventListener("click", OpenCopyrightLink, false);

	document.getElementById("chkBackTranslation").addEventListener("change", function(event)
	{
		var new_cfg = {};
		new_cfg[sbStoragePrefix+"backTranslation"] = this.checked ? "true" : "false";
		widget.cfg.setAsync(new_cfg);
		TranslateText();
	}, false);

	document.getElementById("btnTranslate").addEventListener("click", function(event) { TranslateText(); }, false);
	document.getElementById("btnClear").addEventListener("click", function(event) { ClearText(); }, false);

	document.getElementById("toTextPlayer").addEventListener("click", function(event) { toLangListener.play(this); }, false);
	document.getElementById("toFromTextPlayer").addEventListener("click", function(event) { toFromLangListener.play(this); }, false);

	document.getElementById("btnTranslateUrl").addEventListener("click", function(event) { TranslateUrl(); }, false);


	if (popupInSidebar || (typeof exports == "object"))		// Firefox currently did not support resize
		document.getElementById("imgWindowsResizer").style.display = "none";
	else
		document.getElementById("imgWindowsResizer").addEventListener("mousedown", function(event) { return StartResizePopup(event); }, false);


	if (chrome && chrome.management && chrome.management.getSelf)
		chrome.management.getSelf(function(info){
			if (info.installType == "development")
				document.getElementById("versionMode").innerText = "-dev";
		});
}, false);
