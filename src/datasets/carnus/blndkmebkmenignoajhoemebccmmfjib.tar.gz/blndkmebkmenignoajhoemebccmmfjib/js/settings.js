/* globals chrome, widget, WORDS, is_edge, languages */
function SaveSettings()
{
	if (!widget)
		return;

	var new_cfg = {};

	var defSourceLang = document.getElementsByName("defSourceLang")[0].value;
	if (!languages[defSourceLang]) defSourceLang = "";
	new_cfg["defSourceLang"] = defSourceLang;

	var defTargetLang = document.getElementsByName("defTargetLang")[0].value;
	if (!languages[defTargetLang]) defTargetLang = "";
	new_cfg["defTargetLang"] = defTargetLang;

	var maxStoreLangPairs = document.getElementsByName("maxStoreLangPairs")[0].value;
	if (maxStoreLangPairs < 0) maxStoreLangPairs = 0;
	if (maxStoreLangPairs > 16) maxStoreLangPairs = 16;
	new_cfg["maxStoreLangPairs"] = maxStoreLangPairs;

//	new_cfg["useGoogleDict"] = document.getElementsByName("useGoogleDict")[0].checked ? "true" : "false";

	var btnPosition = "";
	var inps = document.getElementsByName("buttonPosition");
	var i, cnt = inps.length;
	for (i=0; i<cnt; i++)
		if (inps[i].checked)
			btnPosition = inps[i].value;
	new_cfg["buttonPosition"] = btnPosition;

	InvertButtonsPositionImages( document.getElementsByName("buttonPositionInvert")[0].checked );
	new_cfg["buttonPositionInvert"] = document.getElementsByName("buttonPositionInvert")[0].checked ? "true" : "false";

	new_cfg["useGoogleCn"] = document.getElementsByName("useGoogleCn")[0].checked ? "true" : "false";
	new_cfg["openNewTabsNextToActive"] = document.getElementsByName("openNewTabsNextToActive")[0].checked ? "true" : "false";
	new_cfg["rememberLastTranslation"] = document.getElementsByName("rememberLastTranslation")[0].checked ? "true" : "false";

	new_cfg["useGoogleTTS"] = document.getElementsByName("useGoogleTTS")[0].checked ? "true" : "false";
	new_cfg["usePersonalDictionary"] = document.getElementsByName("usePersonalDictionary")[0].checked ? "true" : "false";
/*
	new_cfg["useSpeechRecognition"] = document.getElementsByName("useSpeechRecognition")[0].checked ? "true" : "false";
	if (new_cfg["useSpeechRecognition"] == "true")
	{
		var SpeechRecognition = (window.SpeechRecognition || window.webkitSpeechRecognition);
		if (SpeechRecognition)
		{
			var recognizer = new SpeechRecognition();
			recognizer.onerror = function(event)
			{
				var errUseSpeechRecognition = document.getElementById("errUseSpeechRecognition");
				errUseSpeechRecognition.innerText = event.error;
			};
			recognizer.start();
			recognizer.stop();
		}
	}
*/
	var useTextareaFont = document.getElementsByName("useTextareaFont")[0].value;
	if (!useTextareaFont) useTextareaFont = "";
	new_cfg["useTextareaFont"] = useTextareaFont;

	var useTranslateToolbar = document.getElementsByName("useTranslateToolbar")[0].value;
	if (!useTranslateToolbar) useTranslateToolbar = "";
	new_cfg["useTranslateToolbar"] = useTranslateToolbar;

	var useContextMenuForPages = document.getElementsByName("useContextMenuForPages")[0].value;
	if (!useContextMenuForPages) useContextMenuForPages = "";
	new_cfg["useContextMenuForPages"] = useContextMenuForPages;

	new_cfg["bingClientId"] = document.getElementsByName("bingClientId")[0].value;
	new_cfg["bingClientSecret"] = document.getElementsByName("bingClientSecret")[0].value;

	new_cfg["useSelMarker"] = document.getElementsByName("useSelMarker")[0].checked ? "true" : "false";

	var useExtensionButton = document.getElementsByName("useExtensionButton")[0].checked;
	new_cfg["useExtensionButton"] = useExtensionButton ? "true" : "false";
//		opera.extension.postMessage({ action:"update_extension_button" });
	if (opera && (typeof opera == "object"))
	{
		if (opera.extension.bgProcess.opera.contexts.toolbar.length)
		{
			if (!useExtensionButton)
				opera.extension.bgProcess.opera.contexts.toolbar.removeItem( opera.extension.bgProcess.theButton );
		}
		else
		{
			if (useExtensionButton)
				opera.extension.bgProcess.opera.contexts.toolbar.addItem( opera.extension.bgProcess.theButton );
		}
	}

	new_cfg["useEnterToTranslate"] = document.getElementsByName("useEnterToTranslate")[0].checked ? "true" : "false";

	if (widget)
	{
		widget.cfg.setAsync(new_cfg, function() {
			if (chrome && chrome.browserAction && chrome.browserAction["openPopup"])
				chrome.extension.getBackgroundPage().CreateOrRemovePageContextMenu();
		});
	}
}

function InvertButtonsPositionImages(invert)
{
	var i, imgs = document.getElementsByTagName("IMG");
	for (i=0; i<imgs.length; i++)
		if (imgs[i].src.indexOf("img/buttons_") > 0)
		{
			if (invert)
				imgs[i].src = imgs[i].src.replace(/(\/buttons_[^_\.]+)\.png/, "$1_invert.png");
			else
				imgs[i].src = imgs[i].src.replace(/(\/buttons_[^_\.]+)_invert\.png/, "$1.png");
		}
}



window.addEventListener('DOMContentLoaded', function()
{
	var inp;
	document.getElementsByTagName("FORM")[0].addEventListener("submit", function(){ return false; }, false);

	// Default source language
	var i, selSource = document.getElementsByName("defSourceLang")[0];
	selSource.addEventListener("change", SaveSettings, false);
	for (i in languages)
		selSource.options.add( new Option( languages[i], i ) );

	// Default target language
	var i, selTarget = document.getElementsByName("defTargetLang")[0];
	selTarget.addEventListener("change", SaveSettings, false);
	for (i in languages)
		selTarget.options.add( new Option( languages[i], i ) );

	if (widget)
	{
		widget.cfg.getAsync([
								"translator_uuid",
								"defSourceLang", "defTargetLang", "maxStoreLangPairs",
								"btnPositionInvert", "btnPosition", "useTextareaFont",
								"useTranslateToolbar", "useContextMenuForPages",
								"bingClientId", "bingClientSecret",
								"useGoogleCn", "openNewTabsNextToActive", "rememberLastTranslation",
								"useGoogleTTS", "usePersonalDictionary", "useSpeechRecognition", "useSelMarker", "useExtensionButton", "useEnterToTranslate",
								"mode"
							],
							function(cfg)
		{
			document.getElementById("linkFeedback").href += "?uuid=" + cfg.translator_uuid;

			if (cfg.defSourceLang == null)
				cfg.defSourceLang = "";
			selSource.value = cfg.defSourceLang;

			if (cfg.defTargetLang == null)
				cfg.defTargetLang = "";
			selTarget.value = cfg.defTargetLang;

			// Maximum stored language pairs
			if (cfg.maxStoreLangPairs == null)
				cfg.maxStoreLangPairs = 3;
			(inp = document.getElementsByName("maxStoreLangPairs")[0]).value = cfg.maxStoreLangPairs;
			inp.addEventListener("change", SaveSettings, false);

			// "Translate"-button position
			cfg.btnPositionInvert = (cfg.btnPositionInvert == "true");
			InvertButtonsPositionImages( cfg.btnPositionInvert );
			(inp = document.getElementsByName("buttonPositionInvert")[0]).checked = cfg.btnPositionInvert;
			inp.addEventListener("change", SaveSettings, false);

			if (cfg.btnPosition == null)
				cfg.btnPosition = "right";

			var inps = document.getElementsByName("buttonPosition");
			var i, cnt = inps.length;
			for (i=0; i<cnt; i++)
			{
				inps[i].checked = (inps[i].value == cfg.btnPosition);
				inps[i].addEventListener("change", SaveSettings, false);
			}

			if (cfg.useTextareaFont == null)
				cfg.useTextareaFont = "";
			(inp = document.getElementsByName("useTextareaFont")[0]).value = cfg.useTextareaFont;
			inp.addEventListener("change", SaveSettings, false);

			if (chrome && !is_firefox)
			{
				document.getElementById("btnSetupPopupHotkey").addEventListener("click", function()
				{
					if (navigator.userAgent.indexOf(" OPR/") < 0)
					{
						// Chrome
						chrome.tabs.create({ url: "chrome://extensions/configureCommands" });
					}
					else
					{
						// ChrOpera
						chrome.tabs.create({ url: "opera://settings/configureCommands" });
					}
				}, false);
			}

			// Use Translate Toolbar on each page
			if (cfg.useTranslateToolbar == null)
				cfg.useTranslateToolbar = "";
			if (is_firefox)
				cfg.useTranslateToolbar = "";
			(inp = document.getElementsByName("useTranslateToolbar")[0]).value = cfg.useTranslateToolbar;
			inp.addEventListener("change", SaveSettings, false);
			if (is_firefox)	// Firefox store did not support external scripts
			{
				inp.disabled = true;
				document.getElementById("blockUseTranslateToolbar").style.display = "none";
			}

			if (cfg.useContextMenuForPages == null)
				cfg.useContextMenuForPages = "";
			(inp = document.getElementsByName("useContextMenuForPages")[0]).value = cfg.useContextMenuForPages;
			inp.addEventListener("change", SaveSettings, false);


			// Bing keys
			(inp = document.getElementsByName("bingClientId")[0]).value = cfg.bingClientId;
			inp.addEventListener("change", SaveSettings, false);

			(inp = document.getElementsByName("bingClientSecret")[0]).value = cfg.bingClientSecret;
			inp.addEventListener("change", SaveSettings, false);


			// Other options
	//		cfg.useGoogleDict = ((cfg.useGoogleDict == null) || (cfg.useGoogleDict == "true"));
	//		(inp = document.getElementsByName("useGoogleDict")[0]).checked = cfg.useGoogleDict;
	//		inp.addEventListener("change", SaveSettings, false);

			cfg.useGoogleCn = (cfg.useGoogleCn == "true");
			(inp = document.getElementsByName("useGoogleCn")[0]).checked = cfg.useGoogleCn;
			inp.addEventListener("change", SaveSettings, false);

			cfg.openNewTabsNextToActive = (cfg.openNewTabsNextToActive == "true");
			(inp = document.getElementsByName("openNewTabsNextToActive")[0]).checked = cfg.openNewTabsNextToActive;
			inp.addEventListener("change", SaveSettings, false);
			if (!opera || opera.version()-0 >= 12.1)
				document.getElementsByName("openNewTabsNextToActive")[0].parentNode.style.display = "none";

			cfg.rememberLastTranslation = ((cfg.rememberLastTranslation == null) || (cfg.rememberLastTranslation == "true"));
			(inp = document.getElementsByName("rememberLastTranslation")[0]).checked = cfg.rememberLastTranslation;
			inp.addEventListener("change", SaveSettings, false);

			if (cfg.mode != "demo")
			{
				cfg.useGoogleTTS = ((cfg.useGoogleTTS == null) || (cfg.useGoogleTTS == "true"));
				(inp = document.getElementsByName("useGoogleTTS")[0]).checked = cfg.useGoogleTTS;
				inp.addEventListener("change", SaveSettings, false);
			}
			else
			{
				document.getElementsByName("useGoogleTTS")[0].checked = false;
				document.getElementsByName("useGoogleTTS")[0].disabled = true;
				document.getElementsByName("useGoogleTTS")[0].parentNode.style.textDecoration = "line-through";
			}

			cfg.usePersonalDictionary = ((cfg.usePersonalDictionary == null) || (cfg.usePersonalDictionary == "true"));
			(inp = document.getElementsByName("usePersonalDictionary")[0]).checked = cfg.usePersonalDictionary;
			inp.addEventListener("change", SaveSettings, false);

/*
			cfg.useSpeechRecognition = ((cfg.useSpeechRecognition == null) || (cfg.useSpeechRecognition == "true"));
			(inp = document.getElementsByName("useSpeechRecognition")[0]).checked = cfg.useSpeechRecognition;
			inp.addEventListener("change", SaveSettings, false);
*/
			cfg.useSelMarker = ((cfg.useSelMarker == null) || (cfg.useSelMarker == "true"));
			(inp = document.getElementsByName("useSelMarker")[0]).checked = cfg.useSelMarker;
			inp.addEventListener("change", SaveSettings, false);

			cfg.useExtensionButton = ((cfg.useExtensionButton == null) || (cfg.useExtensionButton == "true"));
			(inp = document.getElementsByName("useExtensionButton")[0]).checked = cfg.useExtensionButton;
			inp.addEventListener("change", SaveSettings, false);

			cfg.useEnterToTranslate = (cfg.useEnterToTranslate == "true");
			(inp = document.getElementsByName("useEnterToTranslate")[0]).checked = cfg.useEnterToTranslate;
			inp.addEventListener("change", SaveSettings, false);
		});
	}
}, false);

window.addEventListener('load', function()
{
	document.getElementsByTagName("TITLE")[0].innerText						= WORDS.txtOptionsTitle;
	document.getElementById("txtMadeBy").innerText							= WORDS.txtMadeBy;
/*
	// Now all feedbacks on my site
	document.getElementById("linkFeedback").innerText						= WORDS.linkFeedback;
	if (opera || (navigator.userAgent.indexOf(" OPR/") > 0) || (navigator.userAgent.indexOf(" YaBrowser/") > 0))
		document.getElementById("linkFeedback").href = "https://addons.opera.com/extensions/details/translator/?reports#feedback-container";
	else
		document.getElementById("linkFeedback").href = "https://chrome.google.com/webstore/detail/translator/blndkmebkmenignoajhoemebccmmfjib/support";
*/

	document.getElementById("hdrDefaultSourceLang").innerText				= WORDS.hdrDefaultSourceLang;
	document.getElementsByName("defSourceLang")[0].options[0].text			= WORDS.optAutoDetect;
	document.getElementById("hdrDefaultTargetLang").innerText				= WORDS.hdrDefaultTargetLang;
	document.getElementsByName("defTargetLang")[0].options[0].text			= WORDS.optAutoDetect;
	document.getElementById("hdrMaxStoredLangPairs").innerText				= WORDS.hdrMaxStoredLangPairs;
	document.getElementById("hdrTranslateBtnPosition").innerText			= WORDS.hdrTranslateBtnPosition;
	document.getElementById("txtAtRight").innerText							= WORDS.txtAtRight;
	document.getElementById("txtAtLeft").innerText							= WORDS.txtAtLeft;
	document.getElementById("txtInvertButons").innerText					= WORDS.txtInvertButons;
	document.getElementById("hdrTextareaFont").innerText					= WORDS.hdrTextareaFont;
	document.getElementsByName("useTextareaFont")[0].options[0].text		= WORDS.optDefault;
	document.getElementById("wrnTextareaFont").innerHTML					= WORDS.wrnTextareaFont;
	if (chrome && !is_firefox)
	{
		document.getElementById("wrnTextareaFont").getElementsByTagName("A")[0].addEventListener("click", function()
		{
			if (navigator.userAgent.indexOf(" OPR/") < 0)
			{
				// Chrome
				chrome.tabs.create({ url: "chrome://settings/fonts" });
			}
			else
			{
				// ChrOpera
				chrome.tabs.create({ url: "opera://settings/fonts" });
			}
		}, false);
	}
	document.getElementById("hdrSetupPopupHotkey").innerText				= WORDS.hdrSetupPopupHotkey;
	document.getElementById("btnSetupPopupHotkey").innerText				= WORDS.btnSetupPopupHotkey;
	document.getElementById("hdrUseTranslateToolbar").innerText				= WORDS.hdrUseTranslateToolbar;
	document.getElementsByName("useTranslateToolbar")[0].options[0].text	= WORDS.optDisabled;
	document.getElementById("wrnUseTranslateToolbar").innerHTML				= WORDS.wrnUseTranslateToolbar;
	document.getElementById("hdrUseContextMenuForPages").innerText			= WORDS.hdrUseContextMenuForPages;
	document.getElementsByName("useContextMenuForPages")[0].options[0].text	= WORDS.optDisabled;
	document.getElementById("hdrBingPrivateKey").innerText					= WORDS.hdrBingPrivateKey;
	document.getElementById("txtBingClientId").innerText					= WORDS.txtBingClientId;
	document.getElementById("txtBingClientSecret").innerText				= WORDS.txtBingClientSecret;
	document.getElementById("hintBingPrivateKey").innerHTML					= WORDS.hintBingPrivateKey;
	document.getElementById("hdrOtherOptions").innerText					= WORDS.hdrOtherOptions;
	document.getElementById("txtUseGoogleCn").innerText						= WORDS.txtUseGoogleCn;
	document.getElementById("txtRememberLastTranslation").innerText			= WORDS.txtRememberLastTranslation;
	document.getElementById("txtOpenNewTabsNextToActive").innerText			= WORDS.txtOpenNewTabsNextToActive;
	document.getElementById("txtUseTextToSpeech").innerText					= WORDS.txtUseTextToSpeech;
//	document.getElementById("txtUseSpeechRecognition").innerText			= WORDS.txtUseSpeechRecognition;
	document.getElementById("txtUseYellowMarker").innerText					= WORDS.txtUseYellowMarker;
	document.getElementById("txtOutputExtensionButton").innerText			= WORDS.txtOutputExtensionButton;
	document.getElementById("txtUseEnterToTranslate").innerText				= WORDS.txtUseEnterToTranslate;

	if (chrome)	// chrome do not support this feature
		document.getElementById("txtOutputExtensionButton").parentNode.style.display = "none";

	if (!chrome || is_edge || is_firefox)
		document.getElementById("blockSetupPopupHotkey").style.display = "none";

	if (!chrome || !chrome.browserAction || !chrome.browserAction.openPopup)
		document.getElementById("blockContextMenuOfPages").style.display = "none";
	
	var services = document.getElementsByName("useTranslateToolbar")[0].options;
	var i, len = services.length;
	for (i=0; i<len; i++)
	{
		if (services[i].value == "google")
			services[i].text = WORDS.tbByGoogle;
		else if (services[i].value == "bing")
			services[i].text = WORDS.tbByBing;
	}

	var services = document.getElementsByName("useContextMenuForPages")[0].options;
	var i, len = services.length;
	for (i=0; i<len; i++)
	{
		if (services[i].value == "google") services[i].text = WORDS.tbByGoogle;
		else if (services[i].value == "bing") services[i].text = WORDS.tbByBing;
		else if (services[i].value == "yandex") services[i].text = WORDS.tbByYandex;
		else if (services[i].value == "promt") services[i].text = WORDS.tbByPromt;
	}

	document.getElementById("txtYouCanUseMyOtherProducts").innerText	= WORDS.txtYouCanUseMyOtherProducts;
	document.getElementById("txtMyCalendarExensionDescr").innerText		= WORDS.txtMyCalendarExensionDescr;
	document.getElementById("txtMyWebanketaServiceDescr").innerText		= WORDS.txtMyWebanketaServiceDescr;

	if (is_firefox)
		WORDS.txtPoweredByOpera = WORDS.txtPoweredByOpera.replace(" Opera", " Firefox");
	else if (chrome && (navigator.userAgent.indexOf(" OPR/") < 0))
		WORDS.txtPoweredByOpera = WORDS.txtPoweredByOpera.replace(" Opera", " Chrome");
	document.getElementById("txtPoweredByOpera").innerText				= WORDS.txtPoweredByOpera;
}, false);
