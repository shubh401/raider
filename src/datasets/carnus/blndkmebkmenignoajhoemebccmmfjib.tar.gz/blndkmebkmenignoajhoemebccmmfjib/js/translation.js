/* globals widget, EXT_LOCALE, msAppId, yaAppId, udAppId, sbStoragePrefix, mostUsedLangPairs, WORDS, languages, lingvoLanguages, promtLanguagesFrom, babylonLanguages, toLangListener, StoreDetectedInputStringsLang, StoreLastToFromText, StoreLastFromText, StoreLastToText, AddMostUsedLangPair, ShowAutodetectedLang, ChangeToLang, SetupBackTranslationVisibility, StartTranslatingAnimation, StopTranslatingAnimation, SendAjaxRequest, SendMessageToBackgroundScript, useGoogleCn, activePage, defTargetLang, detectedInputStringsLang, promtLanguagesTo, RemoveClass, AppendClass, Trim, CreateTabWithUrl, OnEventOfFromToText, OnEventOfToText, OnEventOfFromText, baiduLanguagesTo, msLanguagesAutodetect, GetSignOfBaiduQuery, GetTranslatedPageUrlPrefix, bdAppId, bdSignId */
// Translator-extension

var inputStrings = [], outputStrings = [];
var xhrs = [], scripts = [];
var translatedStringsCnt = 0;
var translateProvider;
var retranslateCountred = 0;
var backTranslating = false;

function getTranslateHandler(idx, resultOf)
{
	return function(result, error, status)
	{
		// TODO: separate handlers for eache service with not supported languages support
		if (typeof inputStrings[idx] != "string")
			return;

		if (typeof result == "string")	// result as string (errors or non-object answers)
		{
			outputStrings[idx] = result.replace(/\\u000A/g, "\n").replace(/\\\"/g, '"') + (outputStrings[idx] || "");	// here can be transcription already

			if (translateProvider == "yandex")
			{
				// No translations for specified language pair in both requests
				if ((idx == 1)
					&& (outputStrings[idx-1] && outputStrings[idx-1].substr(0, 14) == "error status: ")
					&& (outputStrings[idx] && outputStrings[idx].substr(0, 14) == "error status: ")
					)
				{
					outputStrings[idx-1] = "error: not supported language";
					outputStrings[idx] = "";
				}
				else if ((idx === 0)
					&& (outputStrings[idx+1] && outputStrings[idx+1].substr(0, 14) == "error status: ")
					&& (outputStrings[idx] && outputStrings[idx].substr(0, 14) == "error status: ")
					)
				{
					outputStrings[idx] = "error: not supported language";
					outputStrings[idx+1] = "";
				}
				else
				{
					// No translations for specified language pair in one request
					if ((outputStrings[idx] && outputStrings[idx].substr(0, 14) == "error status: "))	// current is error
					{
						if (outputStrings[idx-1] && outputStrings[idx-1].substr(0, 14) != "error status: ")	// previous was not error
							outputStrings[idx] = "";
						if (outputStrings[idx+1] && outputStrings[idx+1].substr(0, 14) != "error status: ")	// next is not error
							outputStrings[idx] = "";
					}
					else
					{
						if (outputStrings[idx-1] && outputStrings[idx-1].substr(0, 14) == "error status: ")	// previous was error
						{
							outputStrings[idx-1] = "";
						}
						if (outputStrings[idx+1] && outputStrings[idx+1].substr(0, 14) == "error status: ")	// next is error
						{
							outputStrings[idx+1] = "";
						}
					}
				}
			}
			else if (translateProvider == "bing")
			{
				if (outputStrings[idx].indexOf("ArgumentOutOfRangeException: 'from' must be a valid language") === 0)
					outputStrings[idx] = "error: not supported language";
				else if (outputStrings[idx].indexOf("error status: 400 ({") === 0)	// wrong lang pair???
					outputStrings[idx] = "";	// dictionary error we can skip
				else if (outputStrings[idx].indexOf("error status: 502 ({") === 0)	// service disabled
					outputStrings[idx] = "";	// dictionary error we can skip
				else if ((outputStrings[idx].indexOf("error status: 500 ({") === 0) && (outputStrings[idx].indexOf("Object reference not set") > 0))
					outputStrings[idx] = "error: not supported language";
			}
			else if (translateProvider == "babylon")
			{
				// babylonTranslator.callback('babylon.0.7._babylon_api_response', {"translatedText":"\u0411\u0435\u0441\u043f\u043b\u0430\u0442\u043d\u043e"}, 200, null, null);
				var matches;
				if (matches = outputStrings[idx].match(/^babylonTranslator.callback\([^{]+{"translatedText":"(.*)"}[^}]+$/))
				{
					result = unescape( matches[1].replace(/\\u([\d\w]{4})/gi, function (match, grp) { return String.fromCharCode(parseInt(grp, 16)); } ) );
					result = result.replace(/\\n/g, "\n");

					// remove DIV elements and fix result
					var fooBox = document.createElement("DIV");
					fooBox.innerHTML = result.replace(/\\(.)/g, "$1");
					result = fooBox.innerText;
					result = result.replace(/\n +\n/g, "\n");
					result = result.replace(/^ +([^ ])/gm, "$1");
					result = result.replace("\\\n", "\\n");			// restore new lines

					outputStrings[idx] = result;
				}
			}
		}
		else if (result === null)		// null also object => separate if
		{
			outputStrings[idx] = result;
		}
		else if (typeof result == "object")	// result as object
		{
			if ((translateProvider == "google") && result.sentences && result.sentences.length)	// google dictionary (already not DEPRECATED)
			{
				//{"sentences":[{"trans":"Sports","orig":"спорт","translit":"","src_translit":"sport"}],"src":"mk","server_time":2}
				//{"sentences":[{"trans":"test page","orig":"test page","translit":"","src_translit":""}],"src":"en","server_time":56}
				var out = [];

				if (result.sentences.length > 1)
				{
					var i, len = result.sentences.length;
					for (i=0; i<len; i++)
						if (result.sentences[i].trans)
//							out.push( result.sentences[i].trans.replace(/ ([,.]) /g, "$1 ").replace(/ ([,.])$/g, "$1") );		// latest time google return commas in spaces :/
							out.push( result.sentences[i].trans );

					out = [out.join("")];
				}
				else
				{
					var sentences = result.sentences[0];
					if (sentences.trans)
					{
						// transcription of orig word
						var translit = "";
						if (sentences.src_translit && (inputStrings.length == 1) && (sentences.src_translit.split(/[ \r\n\t]+/).length < 3))
						{
	//						out.push( "sentences.orig + " ["+sentences.src_translit+"]" );
							translit = " <= ["+sentences.src_translit+"]";
						}

						if (sentences.translit && (inputStrings.length == 1) && (sentences.translit.split(/[ \r\n\t]+/).length < 3))
						{
							out.push( sentences.trans + " ["+sentences.translit+"]" + translit + "\n" );
						}
						else
							out.push( sentences.trans + translit + "\n" );
					}
//					else
//						out.push( "" );
				}

				if (result.dict)
				{
					out.push( "" );
					var i, j, dict = result.dict;
					for (i=0; i<dict.length; i++)
					{
						if (dict[i].pos)
							out.push( dict[i].pos + ":" );

						for (j=0; j<dict[i].terms.length; j++)
							out.push( (j+1) + ". " + dict[i].terms[j] );

						if (dict[i].pos || dict[i].terms.length)
							out.push( "" );
					}
				}

				outputStrings[idx] = out.join("\n");	// join parts via \n. May be need space?
				if (!backTranslating)
					StoreDetectedInputStringsLang( result.src );
			}
			else if ((translateProvider == "google") && result.length && result.join && result[0] && result[0][0] && result[0][0].length)	// new google dictionary
			{
				// [[["Гугл переводчик","google translate","Gugl perevodchik","",10]],,"en",,[["Гугл переводчик",[32000],false,false,0,0,0,0]],[["google translate",32000,[["Гугл переводчик",0,true,false],["Google Translate",0,true,false],["Google Translator и может",0,true,false],["Google переводчик",0,true,false],["Google Translator и",0,true,false]],[[0,16]],"google translate"]],,,[["en"]],45]
				// [[["окно","window",,,10],[,,"okno","ˈwindō"]],
				//	[["noun",["окно","окошко","витрина"],[["окно",["window","casement","gap","light"],,0.50283158],["окошко",["window"],,0.0056739203],["витрина",["showcase","glass case","window","shopwindow","case","shopfront"],,0.00035709812]],"window",1],["adjective",["оконный"],[["оконный",["window"],,0.020432571]],"window",3]],
				//	"en",
				//	,,[["window",32000,[["окно",0,true,false],["окна",0,true,false],["окне",0,true,false],["окном",0,true,false]],[[0,6]],"window",0,0]],1,,[["en"],,[1]],,,[["noun",[[["windowpane"],""]],"window"]],[["noun",[["an opening in the wall or roof of a building or vehicle that is fitted with glass or other transparent material in a frame to admit light or air and allow people to see out.","m_en_us1306540.001","The apartments and penthouses have double-glazed redwood framed windows , fitted kitchens and gas-fired central heating."],["a thing resembling a window in form or function, in particular.","m_en_us1306540.005"],["an interval or opportunity for action.","m_en_us1306540.010","February 15 to March 15 should be the final window for new offers"],["strips of metal foil or metal filings dispersed in the air to obstruct radar detection.","m_en_us1306540.012"]],"window"]],[[["You then presented this screen to the shopper in a pop-up window - something like a cash point ATM \u003cb\u003ewindow\u003c/b\u003e .",,,,3,"m_en_us1306540.003"],["He smiled at the \u003cb\u003ewindow\u003c/b\u003e of good opportunity that he thought he was getting into.",,,,3,"m_en_us1306540.010"],["browser \u003cb\u003ewindow\u003c/b\u003e",,,,3,"neid_22838"],["he broke the \u003cb\u003ewindow\u003c/b\u003e",,,,3,"neid_22835"],["Other differences relate to the rules for entering a phrase into the search engine phrase \u003cb\u003ewindow\u003c/b\u003e .",,,,3,"m_en_us1306540.007"],["A large shuttered sash \u003cb\u003ewindow\u003c/b\u003e overlooking the communal square makes this an exceptionally bright area.",,,,3,"m_en_us1306540.001"],["I notice that Jim Lamb is suiting up early and he's thinking that its time to go soon after the launch \u003cb\u003ewindow\u003c/b\u003e opens.",,,,3,"m_en_us1306540.011"],["thieves smashed a \u003cb\u003ewindow\u003c/b\u003e and took $600",,,,3,"m_en_us1306540.002"],["Food-themed \u003cb\u003ewindow\u003c/b\u003e displays in many shops and businesses in the town also added extra interest.",,,,3,"m_en_us1306540.004"],["Her eyes were gazing out the bay \u003cb\u003ewindow\u003c/b\u003e in her room.",,,,3,"m_en_us1306540.001"],["It's most effective used as a road map of the recent past, or more trivially, a \u003cb\u003ewindow\u003c/b\u003e on what happened the year you were born.",,,,3,"m_en_us1306540.008"],["Vijay Kranti hopes that the current exhibition will help open a \u003cb\u003ewindow\u003c/b\u003e on the life of those who have made the country their own.",,,,3,"m_en_us1306540.008"],["They found no hint of trouble and were able to make their launch \u003cb\u003ewindow\u003c/b\u003e in time.",,,,3,"m_en_us1306540.011"],["beautiful \u003cb\u003ewindow\u003c/b\u003e displays",,,,3,"m_en_gb0954400.004"],["A stained glass \u003cb\u003ewindow\u003c/b\u003e was smashed, along with plaster statues and the church organ, police said.",,,,3,"m_en_us1306540.002"],["Channel 5 is currently acting as a \u003cb\u003ewindow\u003c/b\u003e on America, with its America's Finest strand.",,,,3,"m_en_us1306540.008"],["Kat glanced out the car \u003cb\u003ewindow\u003c/b\u003e looking around, taking as much of the place into her memory as possible.",,,,3,"m_en_us1306540.001"],["When a keen reader writes about their reading, they are opening a \u003cb\u003ewindow\u003c/b\u003e into their soul, and inviting you to step inside and share a holy thing.",,,,3,"m_en_us1306540.008"],["A time capsule full of treasures has opened a \u003cb\u003ewindow\u003c/b\u003e into what life was like 113 years ago in Swindon.",,,,3,"m_en_us1306540.008"],["this is a \u003cb\u003ewindow\u003c/b\u003e of opportunity for companies",,,,3,"neid_22839"],["I prefer the red dress that's in the \u003cb\u003ewindow\u003c/b\u003e",,,,3,"m_en_us1306540.004"],["Selectors and critics forget that this is a \u003cb\u003ewindow\u003c/b\u003e on Indian cinema, good Indian cinema.",,,,3,"m_en_us1306540.008"],["The thieves broke in by forcing a casement \u003cb\u003ewindow\u003c/b\u003e in the dining room before ransacking the house.",,,,3,"m_en_us1306540.001"],["The front passenger \u003cb\u003ewindow\u003c/b\u003e rolled down just enough so she could see James Alcott.",,,,3,"m_en_us1306540.001"],["thieves smashed a \u003cb\u003ewindow\u003c/b\u003e and took £600",,,,3,"m_en_gb0954400.002"],["Microsoft Windows users can think of a terminal as like a DOS prompt or command \u003cb\u003ewindow\u003c/b\u003e .",,,,3,"m_en_us1306540.007"],["Light is drawn into the room through a large bay \u003cb\u003ewindow\u003c/b\u003e overlooking the front garden.",,,,3,"m_en_us1306540.001"],["I turned my head to the left and saw Rashad leaning out the front passenger side \u003cb\u003ewindow\u003c/b\u003e .",,,,3,"m_en_us1306540.001"],["This periodic table was spotted last week in Miami in the \u003cb\u003ewindow\u003c/b\u003e of an Armani shop.",,,,3,"m_en_us1306540.004"],["the office \u003cb\u003ewindow\u003c/b\u003e",,,,3,"neid_22835"]]],[["open the window","close the window","by the window","window shopping","window seat","ticket window","window cleaner","rear window","shop window","window frame"]]]
				var out = [];

				// translits
				var translit = "";
				var source_translit = "";

				// only for single string translate
				if (inputStrings.length == 1)
				{
					if (result[0][0] && result[0][0][2] && (result[0][0][2] !== ""))
						translit = " ["+result[0][0][2]+"]";
					else if (result[0][1] && result[0][1][2] && (result[0][1][2] !== ""))
						translit = " ["+result[0][1][2]+"]";

					if (result[0][0] && result[0][0][3] && (result[0][0][3] !== ""))
						source_translit = " <= ["+result[0][0][3]+"]";
					else if (result[0][1] && result[0][1][3] && (result[0][1][3] !== ""))
						source_translit = " <= ["+result[0][1][3]+"]";

					// if more than 2 words => ignore
					if ((translit.split(/[ \r\n\t]+/).length > 3))	// " [the word]" => 3 is ok
						translit = "";
					if ((source_translit.split(/[ \r\n\t]+/).length > 4))	// " <= [the word]" => 4 is ok
						source_translit = "";
				}

				// translate
				// TODO: recheck multi sentences text
				if (result[0].length > 1 && (translit === "") && (source_translit === ""))
				{
					var sentences = [];
					for (i=0; i<result[0].length; i++)
						sentences.push( result[0][i][0] );
					out.push( sentences.join("") );
				}
				else
					out.push( result[0][0][0] + translit + source_translit );
				out.push( "" );

				// dictionary
				if (result[1] && result[1].length)
				{
					var i, j, dict = result[1];
					for (i=0; i<dict.length; i++)
					{
						out.push( dict[i][0] + ":" );

						for (j=0; j<dict[i][1].length; j++)
							out.push( (j+1) + ". " + dict[i][1][j] );

						out.push( "" );
					}
				}

				// collect result
				outputStrings[idx] = out.join("\n");	// join parts via \n. May be need space?
				if (!backTranslating)
					StoreDetectedInputStringsLang( result[2] );
			}
			else if ((translateProvider == "bing") && (result.statusCode == 200) && result.translationResponse)		// New2 Microsoft Translator
			{
				outputStrings[idx] = result.translationResponse;
			}
			else if ((translateProvider == "bing") && (result.statusCode == 400))		// New2 Microsoft Translator
			{
				outputStrings[idx] = "error: not supported language";
			}
			else if ((translateProvider == "bing") && result.normalizedSource && result.displaySource && result.translations)		// New2 Microsoft Translator Dictionary (items.length can be 0)
			{
				var out = [];
				out.push( "" );
				out.push( "" );

				// collect by types
				var i, j, dict = result.translations;
				var type, by_types = {};
				for (i=0; i<dict.length; i++)
				{
					type = dict[i].posTag.toLowerCase();
					if (typeof by_types[type] == "undefined")
						by_types[type] = [ type+":" ];
					by_types[type].push( (by_types[type].length) + ". " + dict[i].displayTarget );
				}

				// join to `out`
				for (type in by_types)
				{
					[].push.apply(out, by_types[type]);
					out.push( "" );
				}

				outputStrings[idx] = out.join("\n");
			}
/*
			else if ((translateProvider == "bing") && (result.length > 0) && result[0].TranslatedText)		// New Microsoft Translator
			{
				var sub_strings = [];
				var i, cnt = result.length;
				for (i=0; i<cnt; i++)
					sub_strings.push( result[i].TranslatedText );
				outputStrings[idx] = sub_strings.join("\n");
				if (!backTranslating)
					StoreDetectedInputStringsLang( result[0].From );
			}
			else if ((translateProvider == "bing") && result.to && result.normalizedSource && result.items)		// Microsoft Translator Dictionary (items.length can be 0)
			{
				// {"originalText":"test","normalizedSource":"test","displaySource":"test","from":"en","to":"ru","items":[[{"normalizedTarget":"тест","displayTarget":"тест","posTag":"NOUN","confidence":0.3813,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":10129},{"normalizedText":"tests","displayText":"tests","numExamples":15,"frequencyCount":176},{"normalizedText":"quiz","displayText":"quiz","numExamples":15,"frequencyCount":156}]},{"normalizedTarget":"испытания","displayTarget":"испытания","posTag":"NOUN","confidence":0.1746,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":2412},{"normalizedText":"tests","displayText":"tests","numExamples":15,"frequencyCount":1882},{"normalizedText":"testing","displayText":"testing","numExamples":15,"frequencyCount":1699},{"normalizedText":"trials","displayText":"trials","numExamples":15,"frequencyCount":1002},{"normalizedText":"tested","displayText":"tested","numExamples":15,"frequencyCount":459},{"normalizedText":"challenges","displayText":"challenges","numExamples":15,"frequencyCount":244},{"normalizedText":"ordeal","displayText":"ordeal","numExamples":1,"frequencyCount":46}]},{"normalizedTarget":"проверка","displayTarget":"проверка","posTag":"NOUN","confidence":0.0896,"prefixWord":"","backTranslations":[{"normalizedText":"check","displayText":"check","numExamples":15,"frequencyCount":9045},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":1589},{"normalizedText":"verify","displayText":"verify","numExamples":15,"frequencyCount":1501},{"normalizedText":"validation","displayText":"validation","numExamples":15,"frequencyCount":1252},{"normalizedText":"verification","displayText":"verification","numExamples":15,"frequencyCount":1008},{"normalizedText":"checks","displayText":"checks","numExamples":15,"frequencyCount":730},{"normalizedText":"inspection","displayText":"inspection","numExamples":15,"frequencyCount":467}]},{"normalizedTarget":"экзамен","displayTarget":"экзамен","posTag":"NOUN","confidence":0.0431,"prefixWord":"","backTranslations":[{"normalizedText":"exam","displayText":"exam","numExamples":15,"frequencyCount":1459},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":355},{"normalizedText":"examination","displayText":"examination","numExamples":15,"frequencyCount":296},{"normalizedText":"exams","displayText":"exams","numExamples":8,"frequencyCount":39}]}],[{"normalizedTarget":"проверить","displayTarget":"проверить","posTag":"VERB","confidence":0.1478,"prefixWord":"","backTranslations":[{"normalizedText":"check","displayText":"check","numExamples":15,"frequencyCount":17406},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":3656},{"normalizedText":"verify","displayText":"verify","numExamples":15,"frequencyCount":3101},{"normalizedText":"validate","displayText":"validate","numExamples":15,"frequencyCount":978},{"normalizedText":"examine","displayText":"examine","numExamples":15,"frequencyCount":335},{"normalizedText":"inspect","displayText":"inspect","numExamples":10,"frequencyCount":332}]},{"normalizedTarget":"тестировать","displayTarget":"тестировать","posTag":"VERB","confidence":0.0967,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":637}]},{"normalizedTarget":"испытать","displayTarget":"испытать","posTag":"VERB","confidence":0.0669,"prefixWord":"","backTranslations":[{"normalizedText":"experience","displayText":"experience","numExamples":15,"frequencyCount":1810},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":731}]}]]}
				var out = [];
				out.push( "" );
				out.push( "" );

				var i, j, dict = result.items;
				for (i=0; i<dict.length; i++)
				{
					if (dict[i].length)
					{
						out.push( dict[i][0].posTag.toLowerCase() + ":" );
						for (j=0; j<dict[i].length; j++)
							out.push( (j+1) + ". " + dict[i][j].displayTarget );
						out.push( "" );
					}
				}

				outputStrings[idx] = out.join("\n");
				// detected languages stored in translate request
			}
			else if ((translateProvider == "bing") && result.to && result.items.length > 0)		// Microsoft Translator Online
			{
				var sub_strings = [];
				var i, cnt = result.items.length;
				for (i=0; i<cnt; i++)
					sub_strings.push( result.items[i].text.replace(/ \"\,\"/g, "\n") );		// multiline source Bing transform in broken string :/
				outputStrings[idx] = sub_strings.join("\n");
				if (!backTranslating)
					StoreDetectedInputStringsLang( result.from );
			}
*/
			else if ((translateProvider == "yandex") && result.text)	// yandex (translate)
			{
				outputStrings[idx] = result.text.join("\n") + (outputStrings[idx] || "");		// here can be transcription already

				// clear dictionary error, if it has (but current translate is fine)
				if (outputStrings[idx+1] && (outputStrings[idx+1].substr(0, 14) == "error status: "))	// next is error
					outputStrings[idx+1] = "";
			}
			else if ((translateProvider == "yandex") && result.def)	// yandex dictionary
			{
				if (result.def.length)	// ignore empty def
				{
					var out = [];
					if (idx > 0)
					{
						out.push( "" );
						out.push( "" );
					}

					var translit = "";

					var i, j, dict = result.def;
					for (i=0; i<dict.length; i++)
					{
						if ((translit === "") && dict[i].ts)
							outputStrings[0] = (outputStrings[0] || "") + (translit = " <= ["+dict[i].ts+"]");

						if (dict[i].pos)
							out.push( dict[i].pos + ":" );

						for (j=0; j<dict[i].tr.length; j++)
							out.push( (j+1) + ". " + dict[i].tr[j].text );

						if (dict[i].pos || dict[i].tr.length)
							out.push( "" );
					}

					outputStrings[idx] = out.join("\n");
				}
			}
			else if ((translateProvider == "promt") && (result["__type"] == "TranslationResult") || (result["d"] && (result["d"]["__type"] == "Translate.Ru.Classes.Results.TranslationResult")))	// promt
			{
				if (!result["__type"])
					result = result["d"];			// new version

				if (result.errCode)
				{
					if (result.errCode == 4)
						outputStrings[idx] = "error: not supported language";
					else
						outputStrings[idx] = "error code: " + result.errCode;
				}
				else
				{
					{
						var tmp_div = document.createElement("DIV");
						tmp_div.innerHTML = result.result;
						if (tmp_div.querySelector && tmp_div.querySelector("#shView"))
						{
							var out = [];

							var res_parts = tmp_div.querySelectorAll("#shView #cforms_result");
							if (!res_parts.length)
								res_parts = tmp_div.querySelectorAll("#shView .cforms_result");

							var i, len = res_parts.length;
							for (i=0; i<len; i++)
							{
								out.push("");
								out.push( res_parts[i].querySelector(".ref_cform .ref_psp").innerText.toLowerCase() + ":" );
								var list = res_parts[i].querySelectorAll("#translations OL LI .ref_result");
								var j, sub_len = list.length;
								for (j=0; j<sub_len; j++)
									out.push( (j+1) + ". " + Trim(list[j].innerText) );
							}
							out.shift();	// remove first space
							outputStrings[idx] = out.join("\n");
						}
						else
							outputStrings[idx] = result.result.replace(/\u003cbr\/\u003e/g, "\n");
					}

					var detected_lang = result.ptsDirCode.substring(0, 1);
					if (!backTranslating && promtLanguagesFrom[detected_lang])
						StoreDetectedInputStringsLang( promtLanguagesFrom[detected_lang] );
				}
			}
			else if ((translateProvider == "pragma") && result.dat && result.dat[0].rid)				// Pragma via extension API
			{
				outputStrings[idx] = unescape( result.dat[0].text.join("\n").replace(/\\u([\d\w]{4})/gi, function (match, grp) { return String.fromCharCode(parseInt(grp, 16)); } ) );
			}
			else if ((translateProvider == "baidu") && result.trans_result && result.trans_result.data)
			{
				outputStrings[idx] = unescape( result.trans_result.data[0].dst.replace(/\\u([\d\w]{4})/gi, function (match, grp) { return String.fromCharCode(parseInt(grp, 16)); } ) );
			}
			else if ((translateProvider == "baidu") && result.error)
			{
				outputStrings[idx] = "error code: " + result.error;
			}
			else if ((translateProvider == "lingvo") && result.items)				// WordListPart
			{
				var dict = {};
				var i, len = result.items.length;
				for (i=0; i<len; i++)
				{
					if (typeof dict[result.items[i].heading] == "object")
					{
						if (dict[result.items[i].heading].indexOf(result.items[i].lingvoTranslations) < 0)
							dict[result.items[i].heading].push(result.items[i].lingvoTranslations);
					}
					else
						dict[result.items[i].heading] = [result.items[i].lingvoTranslations];
				}

				var out = [];
				for (i in dict)
					out.push(i + " ‒ " + dict[i].join(", "));

				outputStrings[idx] = out.join("\n");	// join parts via \n. May be need space?
				outputStrings[idx] += "\n\n";
			}
			else if ((translateProvider == "lingvo") && result.foundUnits)			// Phrases
			{
				var dict = {};
				var i, len = result.foundUnits.length;
				for (i=0; i<len; i++)
				{
					if (typeof dict[result.foundUnits[i].sourceFragment.text] == "object")
					{
						if (dict[result.foundUnits[i].sourceFragment.text].indexOf(result.foundUnits[i].targetFragment.text) < 0)
							dict[result.foundUnits[i].sourceFragment.text].push(result.foundUnits[i].targetFragment.text);
					}
					else
						dict[result.foundUnits[i].sourceFragment.text] = [result.foundUnits[i].targetFragment.text];
				}

				var out = [];
				for (i in dict)
					out.push(i + " ‒ " + dict[i].join(", "));
				outputStrings[idx] = out.join("\n");	// join parts via \n. May be need space?
				outputStrings[idx] += "\n\n(c) http://lingvolive.com/";
			}
			else if ((translateProvider == "urban") && result.list)		// Urban Dictionary		// old:  && result.result_type
			{
				// http://api.urbandictionary.com/v0/define?key=54dfbdc4e47a0f59e23b186668684cd4&term=andre&0.6412415498425227
				var out = [];

				var i, len = result.list.length;
				if (len)
				{
					for (i=0; i<len; i++)
					{
						out.push( "=== " + result.list[i].word + " ("+result.list[i].author+") +" + result.list[i].thumbs_up + ", -" + result.list[i].thumbs_down +" ===" );
						out.push( result.list[i].definition );
						if (result.list[i].example)
						{
							out.push( "\n// example:" );	// do we need translate it, if this dictionary only use english?
							out.push( result.list[i].example );
						}
						out.push( "\n" );
					}
				}

				outputStrings[idx] = out.join("\n");	// join parts via \n. May be need space?
			}
			else if ((translateProvider == "deepl") && result.result && result.result.translations)
			{
				// {"id":1,"jsonrpc":"2.0","result":{"source_lang":"DE","source_lang_is_confident":0,"target_lang":"ES","translations":[{"beams":[{"num_symbols":3,"postprocessed_sentence":"cristalera","score":-5000.09,"totalLogProb":-1.15642},{"num_symbols":2,"postprocessed_sentence":"cristal","score":-5000.11,"totalLogProb":-1.00554},{"num_symbols":3,"postprocessed_sentence":"escaparate","score":-5000.15,"totalLogProb":-1.81225},{"num_symbols":4,"postprocessed_sentence":"vitrina","score":-5000.18,"totalLogProb":-2.81411},{"num_symbols":4,"postprocessed_sentence":"ventanilla","score":-5000.2,"totalLogProb":-3.15957},{"num_symbols":3,"postprocessed_sentence":"taquilla","score":-5000.25,"totalLogProb":-3.11903},{"num_symbols":2,"postprocessed_sentence":"ventana","score":-5000.25,"totalLogProb":-2.25736}],"timeAfterPreprocessing":9223372036854776,"timeReceivedFromEndpoint":9223372036854776,"timeSentToEndpoint":9223372036854776,"total_time_endpoint":1}]}}
				var i, out = [];

				if (result.result.target_lang !== document.getElementById("toText")["myLanguage"].toUpperCase())
				{
					out.push("error: not supported target language");
				}
				else
				{
					var variants = result.result.translations[0].beams;
					for (i=0; i<variants.length; i++ )
					{
						if (!i)
						{
							out.push( variants[i].postprocessed_sentence );
							if (variants.length > 1)
							{
								out.push("");
								out.push("alternatives:");
							}
						}
						else
							out.push( "- " + variants[i].postprocessed_sentence );


						// limit result by 3 alternatives
						if (i > 2)
							break;
					}
				}

				outputStrings[idx] = out.join("\n");
				if (!backTranslating)
					StoreDetectedInputStringsLang( result.result.source_lang );
			}
			else	// undefined cases
				outputStrings[idx] = result;
		}
		else	// undefined cases
			outputStrings[idx] = result;


		translatedStringsCnt++;
		if (translatedStringsCnt == inputStrings.length)
		{
			// check total result

			// check on expired msAppId => retranslate
			if (!retranslateCountred
				&& (outputStrings[0] !== null)
				&& outputStrings[0]["indexOf"]
				&& ((outputStrings[0].indexOf("The token has expired") > 0) || (outputStrings[0].indexOf("Invalid appId") > 0)))
			{
				if (translateProvider == "bing")
				{
					msAppId = "";
					TranslateText();
					retranslateCountred++;
					return;
				}
				else if (translateProvider == "dictionaries")
				{
					udAppId = "";
					TranslateText();
					retranslateCountred++;
					return;
				}
			}


			if (backTranslating)
			{
				StopTranslatingAnimation();
				if (document.getElementById("chkBackTranslation").checked)
				{
					var toFromText = document.getElementById("toFromText");
					toFromText.value = outputStrings.join("");
//					StoreLastToFromText(toFromText.value);
					OnEventOfFromToText();
					backTranslating = false;
				}
				retranslateCountred = 0;
			}
			else
			{
				if (detectedInputStringsLang
					&& (detectedInputStringsLang == document.getElementById("toLang").value)
					&& (detectedInputStringsLang != SetupAutoTargetLang(detectedInputStringsLang, document.getElementById("toLang").value)))
				{
					TranslateText();
					return;
				}

				StopTranslatingAnimation();
				if (detectedInputStringsLang)
//					StoreLastFromText(document.getElementById("fromText").value, detectedInputStringsLang);
					OnEventOfFromText(null, null, detectedInputStringsLang);
//				ShowAutodetectedLang(detectedInputStringsLang);

				var toText = document.getElementById("toText");
				toText.value = outputStrings.join("");
				if (toText.value === "")
					toText.value = document.getElementById("fromText").value;

//				StoreLastToText(toText.value);
//				RepaintFavoriteButton();
				OnEventOfToText();

				retranslateCountred = 0;

				if (document.getElementById("chkBackTranslation").checked && (translateProvider != "dictionaries") && (translateProvider != "urban"))
					BackTranslateResult();
			}
		}
	};
}

function getAjaxTranslateHandler(idx)
{
	return function()
	{
		if (this.readyState == 4)
		{
			if (this.status == 200)
			{
				var result;
				try
				{
					result = JSON.parse(this.responseText);
				}
				catch (e)
				{
					// try to fix error (,, => ,undefined,)
					try
					{
						result = JSON.parse(this.responseText.replace(/([\[\,])(?=[\,\]])/g, "$1null"));
					}
					catch (e)
					{
						result = this.responseText;
					}
				}
				getTranslateHandler(idx, translateProvider)( result );
			}
			else	// error
			{
				getTranslateHandler(idx)( "error status: " + this.status + (this.responseText ? " (" + this.responseText + ")" : "") );
			}
			xhrs[idx] = null;
		}
	};
}
/*
function SendMessageToBgProcess(msg)
{
	if (opera && opera.extension)
		opera.extension.postMessage(msg);
	else if (backgroundPage)
		backgroundPage.onMessageHandler(msg, window);
}
*/
function Text2Strings(text, maxStrLength)
{
	var strings = [];
	if (text.length > maxStrLength)
	{
		var ss, arr = text.split(/([;.,\-\r\n]+)/);
		var i, cnt = arr.length;
		for (i=0; i<cnt; i++)
		{
			ss = arr[i];
			while (i<(cnt-1) && ((ss.length + arr[i+1].length) <= maxStrLength))
				ss += arr[++i];

			if (ss.length <= maxStrLength)
				strings.push( ss );
			else
				strings.push( ss.substr(0, maxStrLength) );
		}
	}
	else
		strings.push( text );

	return strings;
}

function TranslateUrl(url)
{
	var fromLang	= document.getElementById("fromLang").value;
	var toLang		= document.getElementById("toLang").value;

	if (fromLang.indexOf('~') >= 0)
		fromLang = fromLang.split('~', 2)[0];

	SendMessageToBackgroundScript({
									action:		"translate_url",
									prefixUrl:	GetTranslatedPageUrlPrefix(translateProvider, fromLang, toLang),
									url:		url || activePage.url
									});
}

function TranslateByGoogle(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	// split by max possible length
	inputStrings = Text2Strings(text, 350);

	// send each substring
	var i, cnt = inputStrings.length;
	for (i=0; i<cnt; i++)
	{
		if (useGoogleCn)
		{
			// Google in China did not has googleapi domain
			xhrs[i] = SendAjaxRequest("https://translate.google.cn/translate_a/t?client=dict-chrome-ex",
										"GET",
										null,
										{
											hl:	EXT_LOCALE,
											sl:	(from_lang ? from_lang : "auto"),
											tl:	to_lang,
											q:	inputStrings[i]
										},
										getAjaxTranslateHandler(i)
										);
		}
		else
		{
			// dt=rm	-- transcription
			xhrs[i] = SendAjaxRequest("https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&dt=bd&dt=rm",
										"GET",
										null,
										{
											hl:	EXT_LOCALE,
											sl:	(from_lang ? from_lang : "auto"),
											tl:	to_lang,
											q:	inputStrings[i]
										},
										getAjaxTranslateHandler(i)
										);
		}
	}
}


// taken from: http://werxltd.com/wp/2010/05/13/javascript-implementation-of-javas-string-hashcode-method/
function StringHashCodeByJava(str)
{
	if (str.length === 0)
		return 0;

	var i, hash = 0;
	for (i=0; i<str.length; i++)
	{
		hash = ((hash << 5) - hash) + str.charCodeAt(i);
		hash = hash & hash; // Convert to 32bit integer
	}
	return hash;
}

function TranslateByMicrosoft(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	if (!retranslateCountred && (msAppId === ""))
	{
		SendMessageToBackgroundScript({ action:"get_msAppId", refresh:true, next_action:"retranslate" });
		retranslateCountred++;
		return;
	}

	// split by max possible length
		inputStrings = Text2Strings(text, 300);

	// send each substring
		var j, sub_strings;
		var i, cnt = inputStrings.length;
		for (i=0; i<cnt; i++)
		{
			sub_strings = inputStrings[i].replace(/\\/g, '\\\\').replace(/"/g, '\\"').split(/[\r\n]+/);

			if (msAppId != "-")
			{
				// https://msdn.microsoft.com/en-us/library/ff512385.aspx
				xhrs[i] = SendAjaxRequest("https://api.microsofttranslator.com/v2/ajax.svc/TranslateArray2",
											"GET",
											null,
											{
												appId:	"Bearer " + msAppId,
												ctr:	"",
												loc:	EXT_LOCALE,
												from:	(from_lang ? from_lang : ""),
												to:		to_lang,
												texts:	'["' + sub_strings.join('","') + '"]'
											},
											getAjaxTranslateHandler(i)
											);
			}
			else	// based on cookies
			{
				// new: POST:
				//	detect - https://www.bing.com/tdetect?&IG=16E4E722FC144ED7B16AA33D7CE54711&IID=translator.5032.3
				//				text: test
				//	= en
				//	translate - https://www.bing.com/ttranslate?&IG=16E4E722FC144ED7B16AA33D7CE54711&IID=translator.5032.2
				//				text: test
				//				from: en
				//				to: en
				//	= {"statusCode":200,"translationResponse":"тест"}
				//	dict - https://www.bing.com/ttranslationlookup?&IG=16E4E722FC144ED7B16AA33D7CE54711&IID=translator.5032.2
				//				from: en
				//				to: en
				//				text: test
				// = {"normalizedSource":"test","displaySource":"test","translations":[{"normalizedTarget":"тест","displayTarget":"тест","posTag":"NOUN","confidence":0.3813,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":10129},{"normalizedText":"tests","displayText":"tests","numExamples":15,"frequencyCount":176},{"normalizedText":"quiz","displayText":"quiz","numExamples":15,"frequencyCount":156}]},{"normalizedTarget":"испытания","displayTarget":"испытания","posTag":"NOUN","confidence":0.1746,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":2412},{"normalizedText":"tests","displayText":"tests","numExamples":15,"frequencyCount":1882},{"normalizedText":"testing","displayText":"testing","numExamples":15,"frequencyCount":1699},{"normalizedText":"trials","displayText":"trials","numExamples":15,"frequencyCount":1002},{"normalizedText":"tested","displayText":"tested","numExamples":15,"frequencyCount":459},{"normalizedText":"challenges","displayText":"challenges","numExamples":15,"frequencyCount":244},{"normalizedText":"ordeal","displayText":"ordeal","numExamples":1,"frequencyCount":46}]},{"normalizedTarget":"проверить","displayTarget":"проверить","posTag":"VERB","confidence":0.1478,"prefixWord":"","backTranslations":[{"normalizedText":"check","displayText":"check","numExamples":15,"frequencyCount":17406},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":3656},{"normalizedText":"verify","displayText":"verify","numExamples":15,"frequencyCount":3101},{"normalizedText":"validate","displayText":"validate","numExamples":15,"frequencyCount":978},{"normalizedText":"examine","displayText":"examine","numExamples":15,"frequencyCount":335},{"normalizedText":"inspect","displayText":"inspect","numExamples":10,"frequencyCount":332}]},{"normalizedTarget":"тестировать","displayTarget":"тестировать","posTag":"VERB","confidence":0.0967,"prefixWord":"","backTranslations":[{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":637}]},{"normalizedTarget":"проверка","displayTarget":"проверка","posTag":"NOUN","confidence":0.0896,"prefixWord":"","backTranslations":[{"normalizedText":"check","displayText":"check","numExamples":15,"frequencyCount":9045},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":1589},{"normalizedText":"verify","displayText":"verify","numExamples":15,"frequencyCount":1501},{"normalizedText":"validation","displayText":"validation","numExamples":15,"frequencyCount":1252},{"normalizedText":"verification","displayText":"verification","numExamples":15,"frequencyCount":1008},{"normalizedText":"checks","displayText":"checks","numExamples":15,"frequencyCount":730},{"normalizedText":"inspection","displayText":"inspection","numExamples":15,"frequencyCount":467}]},{"normalizedTarget":"испытать","displayTarget":"испытать","posTag":"VERB","confidence":0.0669,"prefixWord":"","backTranslations":[{"normalizedText":"experience","displayText":"experience","numExamples":15,"frequencyCount":1810},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":731}]},{"normalizedTarget":"экзамен","displayTarget":"экзамен","posTag":"NOUN","confidence":0.0431,"prefixWord":"","backTranslations":[{"normalizedText":"exam","displayText":"exam","numExamples":15,"frequencyCount":1459},{"normalizedText":"test","displayText":"test","numExamples":15,"frequencyCount":355},{"normalizedText":"examination","displayText":"examination","numExamples":15,"frequencyCount":296},{"normalizedText":"exams","displayText":"exams","numExamples":8,"frequencyCount":39}]}]}
				// ID from https://www.bing.com/translator =  IG:"16E4E722FC144ED7B16AA33D7CE54711"
				// ID not required. Can just use cookies! :)
				// content-type: application/x-www-form-urlencoded
				var text = sub_strings.join('","');
/*
				var post_vars = [];
				post_vars.push({id:StringHashCodeByJava(text), text:text});
				xhrs[i] = SendAjaxRequest("https://www.bing.com/translator/api/Translate/TranslateArray?from="+(from_lang ? from_lang : "")+"&to="+to_lang,
											"POST",
											{
												"Content-type":		"application/json; charset=UTF-8"
											},
											JSON.stringify(post_vars),
											getAjaxTranslateHandler(i)
											);

				if (cnt == 1)
				{
					inputStrings.push("");	// pseudo string for getting dictionary
					i++;
					xhrs[i] = SendAjaxRequest("https://www.bing.com/translator/api/Dictionary/Lookup?from="+(from_lang ? from_lang : "")+"&to="+to_lang,
												"GET",
												null,
												{
													"text": text
												},
												getAjaxTranslateHandler(i)
												);
				}
*/
				var localTranslateTextFunc = function(from_detected_lang)
				{
					inputStrings = [text, text];	// second for dictionary

					xhrs[0] = SendAjaxRequest("https://www.bing.com/ttranslate",
												"POST",
												null,
												{
													text:	text,
													from:	from_detected_lang,
													to:		to_lang
												},
												getAjaxTranslateHandler(0)
												);

					// Dictionary
					// TODO: may be only for 1 word?
					xhrs[1] = SendAjaxRequest("https://www.bing.com/ttranslationlookup",
												"POST",
												null,
												{
													text:	text,
													from:	from_detected_lang,
													to:		to_lang
												},
												getAjaxTranslateHandler(1)
												);
				};

				if (from_lang)
					localTranslateTextFunc(from_lang);
				else
				{
					// Detect source language
					var xhr = SendAjaxRequest("https://www.bing.com/tdetect",
												"POST",
												null,
												{ text:	text },

												function()
												{
													if (this.readyState == 4)
													{
														if (this.status == 200)
														{
															var detectLang = this.responseText;
															if (msLanguagesAutodetect[detectLang])
																detectLang = msLanguagesAutodetect[detectLang];
															StoreDetectedInputStringsLang( detectLang );
															localTranslateTextFunc( detectLang );
														}
														else	// error
														{
															inputStrings = [text];
															getTranslateHandler(0)( "error status: " + this.status );
														}
														xhr = null;
													}
												}
												);
				}

			}
		}

	//
	// http://api.microsofttranslator.com/V2/Http.svc/Detect?text= . urlencode($inputStr)
	// http://api.microsofttranslator.com/V2/Ajax.svc/Speak?appId=Bearer%20[sessId]&text=&language=&format=audio/wav

	// https://www.bing.com/translator
	// https://www.bing.com/translator/api/Translate/TranslateArray?from=-&to=de
	// https://www.bing.com/translator/api/Dictionary/Lookup?from=en&to=de&text=test
	// https://www.bing.com/translator/api/language/Speak?locale=de-DE&gender=male&media=audio/mp3&text=Test
	// https://www.bing.com/translator/api/Language/GetSpeechDialectsForLocale?locale=en
}

function TranslateByYandex(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	if (!retranslateCountred && (yaAppId === ""))
	{
		SendMessageToBackgroundScript({ action:"get_yaAppId", refresh:true, next_action:"retranslate" });
		retranslateCountred++;
		return;
	}

	var localTranslateTextFunc = function(from_detected_lang)
	{
		inputStrings = [text, text];	// second for dictionary

		xhrs[0] = SendAjaxRequest("https://translate.yandex.net/api/v1/tr.json/translate?srv=yawidget",
									"GET",
									null,
									{
										lang:	from_detected_lang+"-"+to_lang,
										text:	text
									},
									getAjaxTranslateHandler(0)
									);

		// Dictionary
		// TODO: may be only for 1 word?
		xhrs[1] = SendAjaxRequest("https://dictionary.yandex.net/dicservice.json/lookup",
									"GET",
									null,
									{
										ui:		(EXT_LOCALE=="ru" ? "ru" : "en"),
										sid:	yaAppId,
										lang:	from_detected_lang+"-"+to_lang,
										text:	text
									},
									getAjaxTranslateHandler(1)
									);
	};

	if (from_lang)
		localTranslateTextFunc(from_lang);
	else
	{
		// Detect source language
//		xhr.open( "GET", "http://translate.yandex.net/api/v1/tr.json/detect?srv=tr-text&text=" + encodeURIComponent(text), true );
//		xhr.open( "GET", "https://translate.yandex.net/api/v1.5/tr.json/detect?text=" + encodeURIComponent(text), true );	// TODO: need the key
		var xhr = SendAjaxRequest("https://translate.yandex.net/api/v1/tr.json/detect?srv=yawidget",
									"GET",
									null,
									{ text:	text },

									function()
									{
										if (this.readyState == 4)
										{
											if (this.status == 200)
											{
												var res = JSON.parse(this.responseText);
												if (res.lang)
												{
													StoreDetectedInputStringsLang( res.lang );
													localTranslateTextFunc( res.lang );
												}
												else
												{
													inputStrings = [text];
													getTranslateHandler(0)( "error: can't detect language" );
												}
											}
											else	// error
											{
												inputStrings = [text];
												getTranslateHandler(0)( "error status: " + this.status );
											}
											xhr = null;
										}
									}
									);
	}

}

function TranslateByPromt(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();

	StartTranslatingAnimation();
	inputStrings = [text];

	var post_vars = {};
	post_vars.dirCode = "";
	post_vars.template = "General";
	post_vars.text = text;
	post_vars.lang = (EXT_LOCALE == "ru" ? "ru" : "en");	// EXT_LOCALE
	post_vars.limit = 3000;
	post_vars.useAutoDetect = true;
	post_vars.key = "";
	post_vars.ts = "MainSite";
	post_vars.tid = "";
	post_vars.IsMobile = false;

	// setup langs
	if (!from_lang)
		post_vars.dirCode += "a";	// any
	else if (promtLanguagesTo[from_lang])
		post_vars.dirCode += promtLanguagesTo[from_lang];
	else
		post_vars.dirCode += "-";	// undefined

	if (promtLanguagesTo[to_lang])
		post_vars.dirCode += promtLanguagesTo[to_lang];
	else
	{
//		post_vars.dirCode += "-";	// undefined
		getTranslateHandler(0)( "error: not supported target language" );
		return;
	}

//	xhrs[0] = SendAjaxRequest("https://www.translate.ru/services/TranslationService.asmx/GetTranslation",
	xhrs[0] = SendAjaxRequest("https://www.translate.ru/services/soap.asmx/GetTranslation",
								"POST",
								{
									"Content-type":		"application/json; charset=utf-8",
									"Accept":			"application/json, text/javascript, */*; q=0.01",
									"X-Requested-With":	"XMLHttpRequest"
								},
								JSON.stringify(post_vars),

								getAjaxTranslateHandler(0)
							);
}

var used_pragma_fixer = 0;
function TranslateByPragma(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
 	StartTranslatingAnimation();

/*
	xhrs[0] = new XMLHttpRequest();
	xhrs[0].onreadystatechange = function()
	{
		if (this.readyState == 4)
		{
//			StopTranslatingAnimation();
//			var toText = document.getElementById("toText");

			if (this.status == 200)
			{
				var try_update_cookies = 0;

				if (this.responseText.search(/\<textarea[ \r\n\t]*[^>]+[ \r\n\t]*(name|class)\=[\"\']?DstTe?xt[\'\"]?[ \r\n\t]*[^\>]*>([^\>]*)\<\/textarea\>/i) > 0)
				{
//						toText.value = RegExp.$1;
					var transText = RegExp.$2;
					if (transText.search(/\\u[0-9]{4}[^0-9]/) >= 0)
						transText = unescape(transText.replace(/\\(u[0-9]{4}[^0-9])/g, "%$1"));

					if ((transText.indexOf("translate.ua") > 0) && (text.indexOf("translate.ua") < 0))
					{
						try_update_cookies = 1;
					}
					else
					{
						if (this.responseText.search(/\{[ \r\n\t]*[\"\']responseData[\"\'][ \r\n\t]*\:[ \r\n\t]*\{[ \r\n\t]*[\"\']language[\"\'][ \r\n\t]*:[ \r\n\t]*[\"\']([^\"\']+)[\"\']/i) > 0)
						{
	//							detectedInputStringsLang = RegExp.$1;
							getTranslateHandler(0)( {responseData: {translatedText:transText, detectedSourceLanguage:RegExp.$1}} );
						}
						else
							getTranslateHandler(0)( transText );

						try_update_cookies = -1;
					}
				}

				if (try_update_cookies >= 0)
				{
					// TODO: ask open the page manualy... Can't make it automatically

//					if (this.responseText.indexOf("<textarea") < 0)
					{
						if (!used_pragma_fixer)
						{
							SendMessageToBackgroundScript({ action: "setup_pragma_cookies" });
							used_pragma_fixer = 1;
						}
						else
						{
							getTranslateHandler(0)( "error: can't use Pragma :(\n\nTry to open http://translate.ua/on-line before use it." );
							used_pragma_fixer = 0;
						}
					}
//					else
//						getTranslateHandler(0)( "error: strange result (source)" );

//						console.log(this.responseText);
//						toText.value = "error: strange result";
//					StoreLastToText(toText.value);
				}
			}
			else	// error
			{
				getTranslateHandler(0)( "error status: " + this.status );
//					var toText = "error status: " + this.status;
//					toText.value = this.responseText;
			}
			xhrs[0] = null;
		}
	}

	inputStrings = [text];
//		var url = "http://slovari.yandex.ru/async/translator.xml?cid=slovari"+"&sl="+from_lang+"&tl="+to_lang+"&text="+encodeURIComponent(text);
//		xhr.open( "POST", "http://online.translate.ua/us?url=translate.ua", true );
	xhrs[0].open( "POST", "http://online.translate.ua/en?h=420&w=600&url=translate.ua", true );
	xhrs[0].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//	xhrs[0].setRequestHeader("Referer", "http://online.translate.ua/en?h=420&w=600&url=translate.ua");
//	xhrs[0].setRequestHeader("Referer", "http://online.translate.ua/");
//	xhrs[0].setRequestHeader("Cookie", "ref=translate.ua");
//	xhrs[0].setRequestHeader("Cookie", "__utma=188194487.667253659.1330961379.1330961379.1330961379.1");
	if (from_lang == "") from_lang = "un";
//	xhrs[0].withCredentials = true;
	xhrs[0].send( "SrcTxt="+encodeURIComponent(text)+"&Subject=**&LangFrom="+from_lang+"&LangTo="+to_lang+"&Translate=++Translate+++&DstTxt=&DlgLang=en&hide_lang=ru+uk+en" );
*/

	// split by max possible length
		inputStrings = Text2Strings(text, 350);

	// send each substring
		var i, cnt = inputStrings.length;
		for (i=0; i<cnt; i++)
		{
//			var translate_obj_str = JSON.stringify( {src:(from_lang?from_lang:0), trg:to_lang, dat:[encodeURIComponent( inputStrings[i].replace(/[\\"]/g, '\\$&').replace(/\u0000/g, '\\0').replace("\n", '","') )], dom:null} );
			var translate_obj_str = JSON.stringify( {src:(from_lang?from_lang:0), trg:to_lang, dat:[ inputStrings[i].replace(/[\\"]/g, '\\$&').replace(/\u0000/g, '\\0').replace("\n", '","') ], dom:null} );
//			console.log(translate_obj_str);
//			console.log("{" + translate_obj_str.substr(1, translate_obj_str.length-2) + "}");
			// currently support only HTTP
			xhrs[i] = SendAjaxRequest("http://addon.translate.ua/mozilla/tran_ajax.php?func=translate",
										"GET",
										null,
										{ data: "{" + translate_obj_str.substr(1, translate_obj_str.length-2) + "}" },

										getAjaxTranslateHandler(i)
										);
		}
}

function TranslateByBaidu(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	if (!retranslateCountred && (bdAppId === ""))
	{
		SendMessageToBackgroundScript({ action:"get_bdAppId", refresh:true, next_action:"retranslate" });
		retranslateCountred++;
		return;
	}

	// get part of string
		inputStrings = Text2Strings(text, 350);

	// send each substring
		var i, cnt = inputStrings.length;
		for (i=0; i<cnt; i++)
		{
/*
			// deprecated
			xhrs[i] = SendAjaxRequest("http://translate.baidu.com/v2transapi",
										"POST",
										null,
										{
											from:				(!from_lang ? "" : (baiduLanguagesTo[from_lang] ? baiduLanguagesTo[from_lang] : from_lang)),
											to:					(baiduLanguagesTo[to_lang] ? baiduLanguagesTo[to_lang] : to_lang),
											query:				inputStrings[i],
											simple_means_flag:	3,
										},

										getAjaxTranslateHandler(i)
										);
*/
			// new
			window.gtk = bdSignId;	// require for correct sign request
			xhrs[i] = SendAjaxRequest("https://fanyi.baidu.com/v2transapi",
										"POST",
										null,
										{
											from:				(!from_lang ? "auto" : (baiduLanguagesTo[from_lang] ? baiduLanguagesTo[from_lang] : from_lang)),
											to:					(baiduLanguagesTo[to_lang] ? baiduLanguagesTo[to_lang] : to_lang),
											query:				inputStrings[i],
											transtype:			"translang",
											simple_means_flag:	3,
											sign:				GetSignOfBaiduQuery(inputStrings[i]),
											token:				bdAppId
										},

										getAjaxTranslateHandler(i)
										);
			// {"trans_result":{"from":"en","to":"ru","domain":"all","type":2,"status":0,"data":[{"dst":"\u0438\u0441\u043f\u044b\u0442\u0430\u043d\u0438\u044f","prefixWrap":0,"src":"test","relation":[],"result":""}]},"dict_result":[],"liju_result":[],"logid":2784317112}
		}
}

// TODO:
// try: http://www.freetranslation.com/
// try: http://translate.reference.com/english/russian/open-window/
// try: http://www.systranet.com/translate/
// try: http://www.worldlingo.com/en/products_services/worldlingo_translator.html

function TranslateByBabylon(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	// get part of string
		inputStrings = Text2Strings(text, 350);

	// send each substring
		var i, cnt = inputStrings.length;
		for (i=0; i<cnt; i++)
		{
			// TODO: http://translation.babylon.com/mobile/
			// POST: from=ID&to=ID&ortxt=window&translateit=Translate

			// or: http://translation.babylon.com/
			// ( http://translation.babylon.com/translate/babylon.php?v=1.0&q=open%20window&langpair=0%7C7&callback=babylonTranslator.callback&context=babylon.0.7._babylon_api_response )
			// babylonLanguages[]
			// currently support only HTTP
			xhrs[i] = SendAjaxRequest("http://translation.babylon-software.com/translate/babylon.php?v=1.0",
										"GET",
										null,
										{
											q:			inputStrings[i],
											langpair:	(babylonLanguages[from_lang] ? babylonLanguages[from_lang] : 0)+"|"+(babylonLanguages[to_lang]),
											callback:	"babylonTranslator.callback",
											context:	"babylon.0.7._babylon_api_response"
										},

										getAjaxTranslateHandler(i)
										);
		}
}


function TranslateByBabylonDictionary(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	// alternative
	// http://info.babylon.com/onlinebox.cgi?rt=ol&tid=pop&cid=CD1&tl=en&term=window

	PrepareResultFieldForHtml();
	document.getElementById("result_as_html").getElementsByTagName("IFRAME")[0].src = "http://info.babylon.com/cgi-bin/bis.fcgi?"
																					+ "rt=ol&tid=BabylonSearch&mr=99&sl="+from_lang+"&tl="+to_lang+"&term="+encodeURIComponent(text);
}

function TranslateByLingvoDictionary(from_lang, to_lang, text)
{
	// http://lingvolive.com/translate/en-ru/window
	// lingvoLanguages[]

	// http://lingvolive.com/api/Translation/WordListPart/?dstLang=1049&pageSize=10&prefix=window&srcLang=1033&startIndex=0
	/// http://lingvolive.com/api/Translation/Translate/?dstLang=1049&srcLang=1033&text=window
	// http://lingvolive.com/api/Translation/Phrases/?dstLang=1049&srcLang=1033&text=window
	/// http://lingvolive.com/api/Translation/Examples/?dstLang=1049&srcLang=1033&text=window
	/// http://lingvolive.com/api/social/feed/summary?dstLang=1049&srcLang=1033&text=window
	//// http://lingvolive.com/api/Translation/InflectedForms/?lang=1033&text=window

	// lingvo live Chrome extension
	// https://lingvolive.ru/api/Translation/Minicard?text=ray&srclang=1033&dstlang=1049&returnXml=false


	PrepareResultFieldForText();
	StartTranslatingAnimation();

	inputStrings = [text, text];	// for different sources
	var url;

	// WordListPart
/*
	xhrs[0] = new XMLHttpRequest();
	xhrs[0].onreadystatechange = getAjaxTranslateHandler(0);
	url = "https://lingvolive.com/api/Translation/WordListPart/?pageSize=10"+
			"&srcLang="+lingvoLanguages[from_lang]+
			"&dstLang="+lingvoLanguages[to_lang]+
			"&prefix="+encodeURIComponent(text)+
			"&startIndex=0";
	xhrs[0].open( "GET", url, true );
	xhrs[0].send( );
*/
	xhrs[0] = SendAjaxRequest("https://lingvolive.com/api/Translation/WordListPart/?pageSize=10",
								"GET",
								null,
								{
									srcLang:	lingvoLanguages[from_lang],
									dstLang:	lingvoLanguages[to_lang],
									prefix:		text,
									startIndex:	0
								},
								getAjaxTranslateHandler(0)
								);

	// Phrases
/*
	xhrs[1] = new XMLHttpRequest();
	xhrs[1].onreadystatechange = getAjaxTranslateHandler(1);
	url = "https://lingvolive.com/api/Translation/Phrases/"+
			"?srcLang="+lingvoLanguages[from_lang]+
			"&dstLang="+lingvoLanguages[to_lang]+
			"&text="+encodeURIComponent(text);
	xhrs[1].open( "GET", url, true );
	xhrs[1].send( );
*/
	xhrs[1] = SendAjaxRequest("https://lingvolive.com/api/Translation/Phrases/",
								"GET",
								null,
								{
									srcLang:	lingvoLanguages[from_lang],
									dstLang:	lingvoLanguages[to_lang],
									text:		text,
								},
								getAjaxTranslateHandler(1)
								);
}

function TranslateByUrbanDictionary(from_lang, to_lang, text)
{
	PrepareResultFieldForText();
	StartTranslatingAnimation();

	if (!retranslateCountred && (udAppId === ""))
	{
		SendMessageToBackgroundScript({ action:"get_udAppId", refresh:true, next_action:"retranslate" });
		retranslateCountred++;
		return;
	}

	// sample: http://m.urbandictionary.com/#define?term=alaskan%20firedragon

	// get part of string
		inputStrings = [text.substr(0, 300)];

	// send each substring
		xhrs[0] = SendAjaxRequest("http://api.urbandictionary.com/v0/define",
									"GET",
									null,
									{
										key:	udAppId,
										term:	inputStrings[0],
										".":	Math.random(),
									},
									getAjaxTranslateHandler(0)
									);
}

function TranslateByDeepl(from_lang, to_lang, text)
{
	if (text.match(/^https?:\/\/[^\r\n]+$/))
	{
		TranslateUrl(text);
		return;
	}

	PrepareResultFieldForText();
	StartTranslatingAnimation();

	// get part of string
		inputStrings = Text2Strings(text, 350);

	// send each substring
		var i, cnt = inputStrings.length;
		for (i=0; i<cnt; i++)
		{
			xhrs[i] = SendAjaxRequest("https://www2.deepl.com/jsonrpc",
										"POST",
										{
											"Content-type":		"application/json; charset=UTF-8"
										},
										JSON.stringify({
											jsonrpc: "2.0",
											method: "LMT_handle_jobs",
											params: {
												jobs: [
													{
														kind: "default",
														raw_en_sentence: inputStrings[i]
													}
												],
												lang: {
													user_preferred_langs:		["EN","FR","ES","DE"],
													source_lang_user_selected:	(!from_lang ? "auto" : from_lang.toUpperCase()),
													target_lang:				to_lang.toUpperCase()
												},
												priority: -1
											},
											id: 4
										}),

										getAjaxTranslateHandler(i)
										);
		}
}

function SetupAutoTargetLang(from_lang, to_lang)
{
	if ((defTargetLang !== "") && (from_lang != defTargetLang))
		to_lang = defTargetLang;
	else
	{
		var mostUsed, mostUsedFrom, mostUsedTo;
		for (var i in mostUsedLangPairs)
		{
			mostUsed = i.split('~', 2);
			if ((mostUsed[0] !== "") && (mostUsed[1] !== "") && (mostUsed[0] != mostUsed[1]))
			{
				if (!mostUsedTo && mostUsed[0] == from_lang) mostUsedTo = mostUsed[1];
				else if (!mostUsedFrom && mostUsed[1] == from_lang) mostUsedFrom = mostUsed[0];
			}
		}
		if (mostUsedTo) to_lang = mostUsedTo;
		else if (mostUsedFrom) to_lang = mostUsedFrom;
	}

	if ((from_lang == to_lang) && (from_lang != "en"))
		to_lang = "en";

	var toLang = document.getElementById("toLang");
	if (toLang.value != to_lang)
	{
		toLang.value = to_lang;
		ChangeToLang( toLang );
	}

	return to_lang;
}

function TranslateText(is_selection)
{
	// clear from last transaction
		var i, cnt;
		if (cnt = xhrs.length)
		{
			for (i=0; i<cnt; i++)
				if (xhrs[i])
				{
					xhrs[i].abort();
					xhrs[i] = null;
				}
			xhrs = [];
		}

		cnt = scripts.length;
		for (i=0; i<cnt; i++)
			if (scripts[i])
				scripts[i].parentNode.removeChild(scripts[i]);
		backTranslating = false;
		StopTranslatingAnimation();

		scripts = [];
		inputStrings = [];
		outputStrings = [];
		translatedStringsCnt = 0;
		StoreDetectedInputStringsLang("");

		SetupBackTranslationVisibility();

	// create new transaction
//		StoreLastToText("");
//		StoreLastToFromText("");
		var toTextEl = document.getElementById("toText");
		var from_lang = document.getElementById("fromLang").value,
			to_lang = document.getElementById("toLang").value,
			text = document.getElementById("fromText").value;

		if (from_lang.indexOf('~') >= 0)
			from_lang = from_lang.split('~', 2)[0];

//		StoreLastFromText(text, from_lang);
//		OnEventOfFromText();

		if (from_lang == to_lang)	// langs are equal => detect target language
			to_lang = SetupAutoTargetLang(from_lang, to_lang);

		if (from_lang == to_lang)
		{
			toTextEl.value = text;
//			StoreLastToText(text);
			OnEventOfToText();
			return;
		}

		var toFromTextEl = document.getElementById("toFromText");

		toTextEl.value = "";
		OnEventOfToText();
		toFromTextEl.value = "";
		OnEventOfFromToText();

		text = Trim(text);
		if (text.length)
		{
			AddMostUsedLangPair(from_lang, to_lang);

			var lastTranslateDetectToKey = sbStoragePrefix+"lastTranslateDetectTo";
			widget.cfg.getAsync(lastTranslateDetectToKey, function(cfg)
			{
				if (is_selection)
				{
					if (from_lang !== "")	// if fromLang != Autodetect => setup autodetect
					{
						var lastTranslateDetectTo = cfg.lastTranslateDetectToKey;
						if (lastTranslateDetectTo)
						{
/*
							var fromLang = document.getElementById("fromLang");
							fromLang.value = from_lang = "";
							ChangeFromLang(fromLang);
*/
							var toLang = document.getElementById("toLang");
							toLang.value = to_lang = lastTranslateDetectTo;
							ChangeToLang(toLang);
						}
					}
					else
					{
						var new_cfg = {};
						new_cfg[lastTranslateDetectToKey] = to_lang;
						widget.cfg.setAsync(new_cfg);
					}
				}
				else if (from_lang === "")
				{
					var new_cfg = {};
					new_cfg[lastTranslateDetectToKey] = to_lang;
					widget.cfg.setAsync(new_cfg);
				}

				if (from_lang !== "")
					document.getElementById("fromText")["myLanguage"] = from_lang;
				document.getElementById("toText")["myLanguage"] = to_lang;

				if (translateProvider == "bing")
					TranslateByMicrosoft(from_lang, to_lang, text);
				else if (translateProvider == "yandex")
					TranslateByYandex(from_lang, to_lang, text);
				else if (translateProvider == "promt")
					TranslateByPromt(from_lang, to_lang, text);
				else if (translateProvider == "pragma")
					TranslateByPragma(from_lang, to_lang, text);
				else if (translateProvider == "baidu")
					TranslateByBaidu(from_lang, to_lang, text);
				else if (translateProvider == "babylon")
					TranslateByBabylon(from_lang, to_lang, text);
				else if (translateProvider == "dictionaries")
					TranslateByBabylonDictionary(from_lang, to_lang, text);
				else if (translateProvider == "lingvo")
					TranslateByLingvoDictionary(from_lang, to_lang, text);
				else if (translateProvider == "urban")
					TranslateByUrbanDictionary(from_lang, to_lang, text);
				else if (translateProvider == "deepl")
					TranslateByDeepl(from_lang, to_lang, text);
				else
					TranslateByGoogle(from_lang, to_lang, text);
			});
		}
}

function SetupUIBasedOnMode(mode)
{
	if (mode == "demo")
	{
		document.getElementById("chkBackTranslation").parentNode.style.visibility = "hidden";
		SetupBackTranslationVisibility(false);
		PrepareResultFieldForHtml();

		widget.cfg.getAsync([
								sbStoragePrefix+"translateLastFromTextLang",
								sbStoragePrefix+"translateToLang",
								"defTargetLang"
							], function(cfg)
		{
			var iframe = document.getElementById("result_as_html").getElementsByTagName("IFRAME")[0];
			var fillIframe = function()
			{
				iframe.contentDocument.open();
				iframe.contentDocument.write("<style>BODY{margin:1px; font-size:14px;} PRE{font-size:12px; white-space:pre-wrap;}</style>");
				iframe.contentDocument.write("<style>.linkToVerify{ cursor: pointer; color: blue; text-decoration: underline;}</style>");

				var lang_pair = [ cfg[sbStoragePrefix+"translateLastFromTextLang"], cfg[sbStoragePrefix+"translateToLang"] ];
				for (partner_name in partner_images)
				{
					var partner = partner_images[partner_name];
					if (!CheckPartnerOnConditions(partner, lang_pair, cfg.defTargetLang))
						continue;

					iframe.contentDocument.write("<center><a href='"+partner.link+"' target='_blank'><img src='"+partner.image+"' /></a></center>");
				}

				iframe.contentDocument.write("<pre>" + WORDS.txtUnregisteredModeDetails + "</pre>");
				iframe.contentDocument.write("<span class='linkToVerify'>" + WORDS.txtVerify + "</span>");
				iframe.contentDocument.write("<script src='js/shared_data.js'></script>");
				iframe.contentDocument.close();
			};
			window.addEventListener('DOMContentLoaded', fillIframe);
			fillIframe();
		});
	}
	else
	{
		document.getElementById("chkBackTranslation").parentNode.style.visibility = "visible";
		SetupBackTranslationVisibility();
		PrepareResultFieldForText();
	}
}

function VerifyWidgetAsync(manual)
{
	widget.cfg.getAsync(["translator_uuid", "check_tries"], function(cfg)
	{
		var now = (new Date())-0;
		var check_tries = cfg.check_tries-0 || 0;

		SendAjaxRequest("https://translator.sailormax.net/ajax/verify",
						"POST",
						null,
						{ "uuid":cfg.translator_uuid, "language":navigator.language },
						function(result, error, status)
						{
							if (this.readyState == 4)
							{
								var uuid_status = 0;
								if (this.status == 200)
									uuid_status = (this.responseText == "ok" ? 1 : 0);
								else
									console.log("vstat: " + this.responseText + " ("+this.status+")");

								var new_cfg = {};
								if (uuid_status)
								{
									check_tries = 0;
									new_cfg["last_verified"] = now;
									new_cfg["mode"] = widget.mode = "";
									SetupUIBasedOnMode(widget.mode);
								}
								else
								{
									if (manual)
									{
										CreateTabWithUrl("https://translator.sailormax.net/cabinet?uuid="+cfg.translator_uuid);
										return;
									}
									else
									{
										check_tries++;
										if ((check_tries < 1) || (check_tries >= 3))	// first two bad verifications free
										{
											widget.mode = "demo";
											new_cfg["mode"] = widget.mode;
											SetupUIBasedOnMode(widget.mode);
										}
									}
								}

								new_cfg["last_check"] = now;
								new_cfg["check_tries"] = check_tries;
								widget.cfg.setAsync( new_cfg );
							}

						});
	});
}

/********/
window.addEventListener('load', function()
{
	widget.cfg.getAsync([
							"translator_uuid", "last_check", "last_verified", "mode"
						], function(cfg)
	{
		// cases when need reset verification mode
		var updateCfg = {};
		if ((cfg.translator_uuid == null) || (cfg.translator_uuid.length != 36) || (cfg.translator_uuid.indexOf("-") != 8))
		{
			cfg.translator_uuid = MEL.getUUID("4utc");
			updateCfg["translator_uuid"] = cfg.translator_uuid;
		}

		if (JSON.stringify({}) !== JSON.stringify(updateCfg))
		{
			updateCfg["last_verified"]	= cfg.last_verified	= 0;
			updateCfg["last_check"]		= cfg.last_check	= 0;
			updateCfg["check_tries"]	= cfg.check_tries	= 0;
			updateCfg["mode"]			= cfg.mode			= "";			// reset demo-mode
			widget.cfg.setAsync(updateCfg);
		}
		//

		var now = (new Date())-0;
		var last_checked = cfg.last_check-0 || 0;
		var last_verified = cfg.last_verified-0 || 0;
		widget.mode = cfg.mode;

		if ((last_verified > now) || ((now - last_verified) > 604800000))	// week
		{
			if ((last_checked > now) || ((now - last_checked) > 172800000))	// 2 days
			{
				// try
				VerifyWidgetAsync();
			}
		}

		SetupUIBasedOnMode(widget.mode);
	});
}, false);
/********/

function BackTranslateResult()
{
	if (!document.getElementById("chkBackTranslation").checked)
		return;

	var from_lang = document.getElementById("fromLang").value,
		to_lang = document.getElementById("toLang").value,
		text = document.getElementById("toText").value;

	if (from_lang.indexOf('~') >= 0)
	{
		from_lang = from_lang.split('~', 2)[0];
		if (from_lang === "")
			from_lang = document.getElementById("fromText")["myLanguage"];
	}
	else if ((from_lang === "") && detectedInputStringsLang)
		from_lang = detectedInputStringsLang;

	if (from_lang == to_lang)
	{
		document.getElementById("toFromText").value = text;
		return;
	}

	if (text.length)
	{
		scripts = [];
		inputStrings = [];
		outputStrings = [];
		translatedStringsCnt = 0;

		var toFromText = document.getElementById("toFromText");
		toFromText["myLanguage"] = from_lang;

		backTranslating = true;
		if (translateProvider == "bing")
			TranslateByMicrosoft(to_lang, from_lang, text);
		else if (translateProvider == "yandex")
			TranslateByYandex(to_lang, from_lang, text);
		else if (translateProvider == "promt")
			TranslateByPromt(to_lang, from_lang, text);
		else if (translateProvider == "pragma")
			TranslateByPragma(to_lang, from_lang, text);
		else if (translateProvider == "baidu")
			TranslateByBaidu(to_lang, from_lang, text);
		else if (translateProvider == "babylon")
			TranslateByBabylon(to_lang, from_lang, text);
		else
			TranslateByGoogle(to_lang, from_lang, text);
	}
}

function OpenCopyrightLink()
{
	var urlMask = "";

	var from_lang = document.getElementById("fromLang").value,
		to_lang = document.getElementById("toLang").value,
		text = document.getElementById("fromText").value;

	if (from_lang.indexOf('~') >= 0)
		from_lang = from_lang.split('~', 2)[0];

	if (translateProvider == "google")
		urlMask = "https://translate.google."+(useGoogleCn?"cn":"com")+"/#[from_lang]/[to_lang]/[text]".replace("[from_lang]", (from_lang?from_lang:"auto")).replace("[to_lang]", to_lang);
	else if (translateProvider == "bing")
		urlMask = "https://www.bing.com/translator?text=[text]&from=[from_lang]&to=[to_lang]".replace("[from_lang]", (from_lang?from_lang:"")).replace("[to_lang]", to_lang);
	else if (translateProvider == "yandex")
		urlMask = "https://translate.yandex.com/m/translate?text=[text]&lang=[from_lang]-[to_lang]".replace("[from_lang]", (from_lang?from_lang:"")).replace("[to_lang]", to_lang);
	else if (translateProvider == "promt")
		urlMask = "http://www.online-translator.com/";
	else if (translateProvider == "pragma")
		urlMask = "http://www.translate.ua/us/on-line";
	else if (translateProvider == "baidu")
		urlMask = "https://fanyi.baidu.com/#"+(!from_lang ? "auto" : (baiduLanguagesTo[from_lang] ? baiduLanguagesTo[from_lang] : from_lang))+"/"+(baiduLanguagesTo[to_lang] ? baiduLanguagesTo[to_lang] : to_lang)+"/[text]";
	else if (translateProvider == "babylon")
		urlMask = "http://translation.babylon-software.com/[from_lang]/to-[to_lang]/[text]/".replace("[from_lang]", from_lang?languages[from_lang].toLowerCase():"english").replace("[to_lang]", languages[to_lang].toLowerCase());
	else if (translateProvider == "dictionaries")
		urlMask = "http://dictionary.babylon-software.com/[text]/";
	else if (translateProvider == "lingvo")
		urlMask = "http://www.lingvo-online.ru/"+(EXT_LOCALE=="ru"?"ru":"en")+"/Translate/[from_lang]-[to_lang]/[text]".replace("[from_lang]", from_lang).replace("[to_lang]", to_lang);
	else if (translateProvider == "urban")
		urlMask = "https://www.urbandictionary.com/define.php?term=[text]";
	else if (translateProvider == "deepl")
		urlMask = "https://www.deepl.com/translator#zz/de/[text]";

	if (urlMask !== "")
	{
		urlMask = urlMask.replace("[text]", encodeURIComponent(text));
		CreateTabWithUrl(urlMask);
	}
}

function PrepareResultFieldForText()
{
	if (document.getElementById("result_as_text").parentNode.className.indexOf("result_as_html") < 0)
		return;

	document.getElementById("result_as_text").getElementsByTagName("TEXTAREA").value = "";
	RemoveClass(document.getElementById("result_as_text").parentNode, "result_as_html");
}

function PrepareResultFieldForHtml()
{
	if (document.getElementById("result_as_text").parentNode.className.indexOf("result_as_html") >= 0)
		return;

	document.getElementById("result_as_html").getElementsByTagName("IFRAME")[0].src = "about:blank";
	AppendClass(document.getElementById("result_as_text").parentNode, "result_as_html");
}



//////////// MEL
var MEL = {};

MEL.uuid_lut = [];
MEL.uuid_rand_obj = null;
MEL.getUUID = function(v, node_id)
{
	if (typeof v == "undefined")
		v = "4";

	switch (parseInt(v))
	{
		case 4:	// random
			// v4: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
			// based on comment of http://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript
			var lut = MEL.uuid_lut;
			if (!lut.length)
			{
				for (var i=0; i<256; i++)
					lut[i] = (i<16?'0':'')+(i).toString(16);
				MEL.uuid_lut = lut;

				if (window.crypto || window.msCrypto)
				{
					MEL.uuid_rand_obj = window.crypto || window.msCrypto;
					if (!MEL.uuid_rand_obj.random)
						MEL.uuid_rand_obj.random = function()
						{
							var arr = new Uint32Array(1);
							this.getRandomValues(arr);
							return (arr[0] / 0xffffffff);
						};
				}
				else if (window.MersenneTwister)
					MEL.uuid_rand_obj = new window.MersenneTwister();
				else
				{
					console.log("Warning! UUID use Math.random(), which can be unsafety. Use mersenne-twister.js");
					MEL.uuid_rand_obj = Math;
				}
			}

			var prefix = "";
			var d1 = MEL.uuid_rand_obj.random()*0xffffffff|0;
			var d2 = MEL.uuid_rand_obj.random()*0xffffffff|0;

			if (v == "4utc")
			{
				var dt = Date.now ? Date.now() : new Date()-0;
				// Bitwise operators work only with 32bit signed integers => split the date
				var dt0 = dt & 0xffffffff | 0;
				var dt1 = dt / 0xffffffff | 0;
				prefix = lut[dt1>>>8&0xff] + lut[dt1&0xff] + lut[dt0>>>24&0xff] + lut[dt0>>>16&0xff] +'-'+ lut[dt0>>>8&0xff] + lut[dt0&0xff];
			}
			else
			{
				var d0 = MEL.uuid_rand_obj.random()*0xffffffff|0;
				prefix = lut[d0&0xff] + lut[d0>>>8&0xff] + lut[d0>>>16&0xff] + lut[d0>>>24&0xff] +'-'+ lut[d1&0xff] + lut[d1>>>8&0xff];
			}

			var d3 = MEL.uuid_rand_obj.random()*0xffffffff|0;
			return prefix
					+'-'+ (typeof node_id == "undefined"
							? lut[d1>>>16&0x0f|0x40] + lut[d1>>>24&0xff]
							: lut[node_id>>8&0x0f|0x40] + lut[node_id&0xff]
							)
					+'-'+ lut[d2&0x3f|0x80] + lut[d2>>>8&0xff]
					+'-'+ lut[d2>>>16&0xff] + lut[d2>>>24&0xff] + lut[d3&0xff] + lut[d3>>>8&0xff] + lut[d3>>>16&0xff] + lut[d3>>>24&0xff];

		case 1:	// MAC address & date-time
		case 2:	// DCE Security
		case 3:	// MD5 hash & namespace
		case 5:	// SHA-1 hash & namespace
		default:
			return "";
	}
};


if (!window.crypto && !window.msCrypto)
{
	var new_script = document.createElement("SCRIPT");
//	new_script.src = chrome.runtime.getURL("js/libs/mersenne-twister.js");
	new_script.src = "js/libs/mersenne-twister.js";
	var firstScript = document.getElementsByTagName("SCRIPT")[0];
	firstScript.parentNode.insertBefore(new_script, firstScript);
}
