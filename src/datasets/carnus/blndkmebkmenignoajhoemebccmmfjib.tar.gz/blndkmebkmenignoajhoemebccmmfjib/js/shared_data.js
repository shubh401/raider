/*
function GetSupportedMimeType()
{
	var i, supportedMimeTypes = ["audio/mp3", "audio/mpeg", "audio/x-pn-realaudio-plugin"];	// , "application/x-mplayer2"
	for (i in supportedMimeTypes)
		if ((plugin = navigator.mimeTypes[supportedMimeTypes[i]]) && plugin.enabledPlugin)
			return supportedMimeTypes[i];
	return false;
}
*/

function Trim(text)
{
	return text.replace(/(^[ \t\n\r\0\x0B]+)|([ \t\r\n\0\x0B]+$)/g, "");
}

function GetStyleOfElement(el, style_name)
{
	if (style_name)
	{
		if (document.defaultView && document.defaultView.getComputedStyle)
		{
			try { return document.defaultView.getComputedStyle(el, "").getPropertyValue(style_name); }
			catch (e) { return ""; }
		}
		else if (el.currentStyle)
		{
			style_name = style_name.replace(/-(\w)/g, function(){ return arguments[1].toUpperCase(); });
			return el.currentStyle[style_name];
		}
	}
	else
	{
		var style;
		if (el.style.getAttribute)
			style = el.style.getAttribute("cssText");
		else
			style = el.getAttribute("style");

		if (style)
			return style;
	}
	return ""; 
}

function AppendClass(el, name)
{
	if (el["classList"] && (name.indexOf(" ") < 0)) return el.classList.add(name);
	if ((" "+el.className+" ").search(" "+name+" ") < 0)
		el.className += " " + name;
}

function RemoveClass(el, name)
{
	if (el["classList"] && (name.indexOf(" ") < 0)) return el.classList.remove(name);
	el.className = (" "+el.className+" ").replace(" "+name+" ", " ").replace(/^ +/, "").replace(/ +$/, "").replace(/ +/, " ");
}

function DetectUserPreferedLanguage()
{
	var def_lng = "en";
	var lng = "";
	var user_langs = [window.navigator.language];
	if (window.navigator.userLanguage)
		user_langs.push( window.navigator.userLanguage );
	if (window.navigator.browserLanguage)
		user_langs.push( window.navigator.browserLanguage );
	if (user_langs)
	{
		var en_lng = "";
		var i, cnt = user_langs.length;
		for (i=0; i<cnt; i++)
		{
			lng = user_langs[i];
			var lang_prior = lng.split(";");
			var lang_country = lang_prior[0].split("-");
			lng = lang_country[0].toLowerCase();
			if (lng == "en")
				en_lng = "en";
			else if (languages[lng])
				break;
			lng = "";
		}

		if (!lng) lng = en_lng;
		if (!lng) lng = def_lng;
	}
	else
		lng = def_lng;
	return lng;
}

function GetTranslatedPageUrlPrefix(translateProvider, fromLang, toLang)
{
	var prefixUrl;

	switch (translateProvider)
	{
		case "bing":
			prefixUrl = "https://www.microsofttranslator.com/bv.aspx?lo=TP&from="+fromLang+"&to="+toLang+"&a=";
			break;

		case "yandex":
			prefixUrl = "https://translate.yandex.com/translate?dir=auto&from="+fromLang+"&lang="+fromLang+"-"+toLang+"&to="+toLang+"&ui=&url=";
			break;

		case "promt":
			// setup langs
			var lang_pair = "";

			if (!fromLang)
				lang_pair += "a";	// any
			else if (promtLanguagesTo[fromLang])
				lang_pair += promtLanguagesTo[fromLang];
			else
				lang_pair += "-";	// undefined

			if (promtLanguagesTo[toLang])
				lang_pair += promtLanguagesTo[toLang];
			else
				lang_pair += "-";	// undefined
			//

			prefixUrl = "https://www.translate.ru/siteTranslation/autolink/?direction="+lang_pair+"&template=General&sourceURL=";
			break;

		default:	// google
			prefixUrl = "https://translate.google." + (useGoogleCn ? "cn" : "com") + "/translate?sl="+fromLang+"&tl="+toLang+"&u=";
	}

	return prefixUrl;
}

function CheckPartnerOnConditions(partner, langPair, defaultTargetLang)
{
	if (partner.require)
	{
		if (partner.require.user_langs)
		{
			if (partner.require.user_langs.indexOf(DetectUserPreferedLanguage()) < 0
				&& (partner.require.user_langs.indexOf(defaultTargetLang) < 0)
				)
				return false;
		}

		if (partner.require.dict_langs)
		{
			var dict_langs_found = 0;
			for (var j in partner.require.dict_langs)
				if (langPair.indexOf(partner.require.dict_langs[j]) >= 0 || (langPair.join("-") == partner.require.dict_langs[j]))
					dict_langs_found++;
			if (!dict_langs_found)
				return false;
		}
	}
	return true;
}

(function()
{
	var links = document.getElementsByTagName('SPAN');
	if ((links.length == 1) && (links[0].className == "linkToVerify"))
	{
		links[0].onclick = function()
		{
			parent.VerifyWidgetAsync(true);
		};
	}
})();

// http://translate.googleapis.com/translate_a/l?client=te&hl=en&cb=_callbacks_._0gh4pjncd
// _callbacks_._0gh4pjncd({'sl':{'auto':'Detect language','af':'Afrikaans',...});
var languages = {
'af'	: 'Afrikaans',
'sq'	: 'Albanian',
'am'	: 'Amharic',
'ar'	: 'Arabic',
'hy'	: 'Armenian',
'az'	: 'Azerbaijani',
'eu'	: 'Basque',
'be'	: 'Belarusian',
'bn'	: 'Bengali',
'bh'	: 'Bihari',
'br'	: 'Breton',
'bg'	: 'Bulgarian',
'my'	: 'Burmese',
'ca'	: 'Catalan',
//'chr'	: 'Cherokee',	// no one support it
'zh'	: 'Chinese',
'zh-CN'	: 'Chinese_simplified',
'zh-CHS': 'Chinese_simplified_legacy',
'zh-HK'	: 'Chinese_traditional_HongKong',
'zh-MO'	: 'Chinese_traditional_Macao',
'zh-SG'	: 'Chinese_traditional_Singapure',
'zh-TW'	: 'Chinese_traditional_Taiwan',
'zh-CHT': 'Chinese_traditional_legacy',
'co'	: 'Corsican',
'hr'	: 'Croatian',
'cs'	: 'Czech',
'da'	: 'Danish',
'dv'	: 'Dhivehi',
'nl'	: 'Dutch',
'en'	: 'English',
'eo'	: 'Esperanto',
'et'	: 'Estonian',
'fo'	: 'Faroese',
'tl'	: 'Filipino',
'fi'	: 'Finnish',
'fr'	: 'French',
'fy'	: 'Frisian',
'gl'	: 'Galician',
'ka'	: 'Georgian',
'de'	: 'German',
'el'	: 'Greek',
'gu'	: 'Gujarati',
'ht'	: 'Haitian_creole',
'iw'	: 'Hebrew',
'hi'	: 'Hindi',
'hu'	: 'Hungarian',
'is'	: 'Icelandic',
'id'	: 'Indonesian',
'iu'	: 'Inuktitut',
'ga'	: 'Irish',
'it'	: 'Italian',
'ja'	: 'Japanese',
'jw'	: 'Javanese',
'kn'	: 'Kannada',
'kk'	: 'Kazakh',
'km'	: 'Khmer',
'ko'	: 'Korean',
'ku'	: 'Kurdish',
'ky'	: 'Kyrgyz',
'lo'	: 'Lao',
'la'	: 'Latin',
'lv'	: 'Latvian',
'lt'	: 'Lithuanian',
'lb'	: 'Luxembourgish',
'mk'	: 'Macedonian',
'ms'	: 'Malay',
'ml'	: 'Malayalam',
'mt'	: 'Maltese',
'mi'	: 'Maori',
'mr'	: 'Marathi',
'mn'	: 'Mongolian',
'ne'	: 'Nepali',
'no'	: 'Norwegian',
'oc'	: 'Occitan',
'or'	: 'Oriya',
'ps'	: 'Pashto',
'fa'	: 'Persian',
'pl'	: 'Polish',
'pt'	: 'Portuguese',
'pt-PT'	: 'Portuguese_portugal',
'pa'	: 'Punjabi',
'qu'	: 'Quechua',
'ro'	: 'Romanian',
'ru'	: 'Russian',
'sa'	: 'Sanskrit',
'gd'	: 'Scots_gaelic',
'sr'	: 'Serbian',
'sr-Cyrl': 'Serbian (Cyrillic)',
'sr-Latn': 'Serbian (Latin)',
'sd'	: 'Sindhi',
'si'	: 'Sinhalese',
'sk'	: 'Slovak',
'sl'	: 'Slovenian',
'es'	: 'Spanish',
'su'	: 'Sundanese',
'sw'	: 'Swahili',
'sv'	: 'Swedish',
'syr'	: 'Syriac',
'tg'	: 'Tajik',
'ta'	: 'Tamil',
'tt'	: 'Tatar',
'te'	: 'Telugu',
'th'	: 'Thai',
'bo'	: 'Tibetan',
'to'	: 'Tonga',
'tr'	: 'Turkish',
'uk'	: 'Ukrainian',
'ur'	: 'Urdu',
'uz'	: 'Uzbek',
'ug'	: 'Uighur',
'vi'	: 'Vietnamese',
'cy'	: 'Welsh',
'yi'	: 'Yiddish',
'yo'	: 'Yoruba',
'wo'	: 'Wolof'
};

var msLanguagesAutodetect = {
"he"	: "iw"
};

var promtLanguagesFrom = {
"e"		: "en",
"s"		: "es",
"i"		: "it",
"j"		: "ja",
"g"		: "de",
"p"		: "pt",
"r"		: "ru",
"f"		: "fr",
};

var promtLanguagesTo = {
"en"	: "e",
"es"	: "s",
"it"	: "i",
"ja"	: "j",
"de"	: "g",
"pt"	: "p",
"ru"	: "r",
"fr"	: "f",
};

var lingvoLanguages = {
"zh-CN"	: 1028,
"da"	: 1030,
"nl"	: 1043,
"en"	: 1033,
"fi"	: 1035,
"fr"	: 1036,
"de"	: 32775,
"el"	: 1032,
"hu"	: 1038,
"it"	: 1040,
"kk"	: 1087,
"la"	: 1142,
"nb-no"	: 1044,
"pl"	: 1045,
"pt-br"	: 2070,
"ru"	: 1049,
"es"	: 1034,
"tt"	: 1092,
"tr"	: 1055,
"uk"	: 1058,
};

var babylonLanguages = {
"en"	: 0,
"fr"	: 1,
"it"	: 2,
"de"	: 6,
"pt"	: 5,
"es"	: 3,
"ar"	: 15,
"ca"	: 99,
/* <option value="344">Castilian</option> */
"cs"	: 31,
"zh-CN"	: 10,
"zh"	: 9,
"da"	: 43,
"el"	: 11,
"iw"	: 14,
"hi"	: 60,
"hu"	: 30,
"fa"	: 51,
"ja"	: 8,
"ko"	: 12,
"nl"	: 4,
"no"	: 46,
"pl"	: 29,
"ro"	: 47,
"ru"	: 7,
"sv"	: 48,
"tr"	: 13,
"th"	: 16,
"uk"	: 49,
"ur"	: 39,
};

var baiduLanguagesTo = {
"ar"	: "ara",
"et"	: "est",
"bg"	: "bul",
"da"	: "dan",
"fr"	: "fra",
"fi"	: "fin",
"ko"	: "kor",
"ro"	: "rom",
"ja"	: "jp",
"sv"	: "swe",
"sl"	: "slo",
"zh"	: "wyw",
"zh-CN"	: "zh",
"zh-CHT": "cht",
"es"	: "spa",
"vi"	: "vie",
};

// https://www.bing.com/translator/api/Language/GetSpeechDialectsForLocale?locale=en
var lang_default_locales = {
'ar'	: 'ar-EG',
'ca'	: 'ca-ES',
'zh-CHS': 'zh-CN',
'zh-HK'	: 'zh-HK',
'zh-TW'	: 'zh-TW',
'zh-CHT': 'zh-CN',
'da'	: 'da-DK',
'nl'	: 'nl-NL',
'en'	: 'en-US',
'fi'	: 'fi-FI',
'fr'	: 'fr-FR',
'de'	: 'de-DE',
'it'	: 'it-IT',
'ja'	: 'ja-JP',
'ko'	: 'ko-KR',
'no'	: 'nb-NO',
'pl'	: 'pl-PL',
'pt'	: 'pt-BR',
'pt-PT'	: 'pt-PT',
'ru'	: 'ru-RU',
'es'	: 'es-ES',
'sv'	: 'sv-SE',
};
