﻿/* globals chrome, widget, WORDS, is_edge, SendAjaxRequest, ToolbarUIItemProperties, popupMinimumSize */
var theButton;
var iconImgSrc = "icons/icon-18.png";		// Opera Classic + default
if (chrome)
{
	// https://developer.mozilla.org/en-US/Add-ons/WebExtensions/manifest.json/browser_action#Choosing_icon_sizes
	var req_size = 16 * window.devicePixelRatio;
	if (is_edge)
		req_size = 20 * window.devicePixelRatio;
	else if (chrome && chrome.i18n)	// Chrome
		req_size = 19 * window.devicePixelRatio;

	var possible_icons = chrome.runtime.getManifest().browser_action.default_icon;
	req_size = Math.round(req_size);
	while ((req_size > 0) && (typeof possible_icons[req_size] == "undefined"))
		req_size--;
	if (typeof possible_icons[req_size] != "undefined")
		iconImgSrc = possible_icons[req_size];
}

var msAppIdWasRefreshed = 0;
var yaAppIdWasRefreshed = 0;
var udAppIdWasRefreshed = 0;
var bdAppIdWasRefreshed = 0;
//var msAppId = "4A3CABC2D69C013FAB95D4E92B66F1AC2D6D2E11";
var msAppId = "";
var udAppId = "54dfbdc4e47a0f59e23b186668684cd4";
var yaAppId = "5c313937";
var bdAppId = "";
var bdSignId = "";

var activeTab_UUID = 0;													// TODO: remove it with code
var cmForSelection = 0;
var cmForPage = 0;

var lastUsedStat = 0;
var tabs_ports = [];
var lastActiveTab = null;
var lastActivePopup = null;


function setupBandgeIcon(stat)
{
	if (!theButton)
		return;

	if (typeof stat == "undefined")
		stat = lastUsedStat;
	else
		lastUsedStat = stat;

	if (opera)
	{
		if (stat > 0)
			theButton.icon = iconImgSrc.replace("icons/", "icons/selection/");
		else if (stat < 0)
			theButton.icon = iconImgSrc.replace("icons/", "icons/disabled/");
		else
			theButton.icon = iconImgSrc;
	}
	else
	{
		if (stat > 0)
			theButton.setIcon( {path: iconImgSrc.replace("icons/", "icons/selection/")} );
		else if (stat < 0)
			theButton.setIcon( {path: iconImgSrc.replace("icons/", "icons/disabled/")} );
		else
			theButton.setIcon( {path: iconImgSrc} );
	}
}

function SetupCookiesByUrl(url, oncomplete)
{
	// fix bug with recursive reloading popup on trying open new tab while popup is opened
	if (opera)
	{
		var temp_tab = opera.extension.tabs.create({url: url, focused: false});
		if (temp_tab.readyState)
		{
			var loop = setInterval(function()
			{
				if (temp_tab.readyState === 'complete')
				{
					clearInterval(loop);
//					temp_tab.close();	// wait for fix. Now it close popup :(
					if (oncomplete)
						oncomplete();
				}
			}, 100);
		}
		else if (oncomplete)
			setTimeout( oncomplete, 2000 );
	}
	else
	{
		chrome.tabs.create({url: url, active: false, selected:false}, function(temp_tab)
		{
			var gotNewId = false;
			var funcTabListener = function(tabId, info)
			{
				if (!gotNewId && (temp_tab.id == tabId) && (info.status == "complete"))
				{
					gotNewId = true;
					if (oncomplete)
						oncomplete();
					chrome.tabs.remove(tabId);
					chrome.tabs.onUpdated.removeListener(funcTabListener);
				}
			};

			chrome.tabs.onUpdated.addListener(funcTabListener);
			funcTabListener(temp_tab.id, temp_tab);		// for case when tab was already loaded before listener
		});
	}
}

function ExtractAppId(srcUrl, extractRules, callback, post_data)
{
	var xhr = SendAjaxRequest(srcUrl,
								(post_data ? "POST" : "GET"),
								null,
								post_data,
								function()
								{
									if (this.readyState == 4)
									{
										if (this.status == 200)
										{
											for (targetVar in extractRules)
											{
												var re = extractRules[targetVar];
												if (re.test(this.responseText))
													window[targetVar] = RegExp.$1;
												else
													console.log("using default "+targetVar+"!");
											}
											window[targetVar+"WasRefreshed"] = (new Date())-0;
										}
										xhr = null;

										if (callback)
											callback();
									}
								}
								);
}

function RefreshMsAppId(callback)
{
	widget.cfg.getAsync(["bingClientId", "bingClientSecret"], function(cfg)
	{
/*
		if (cfg.bingClientId && cfg.bingClientSecret)
		{
			// get private access token
			// https://msdn.microsoft.com/en-us/library/hh454950.aspx (deprecated)
			ExtractAppId("https://datamarket.accesscontrol.windows.net/v2/OAuth2-13/",
						new RegExp("^(.+)$"),
						"msAppId",
						function()
						{
							try
							{
								window["msAppId"] = JSON.parse(window["msAppId"]).access_token;
							}
							catch (e)
							{
								window["msAppId"] = "";
							}
							callback();
						},
						{
							grant_type:		'client_credentials',
							client_id:		cfg.bingClientId,
							client_secret:	cfg.bingClientSecret,
							scope:			'http://api.microsofttranslator.com'
						});
		}
		else
*/
		{
			// get public access token
			SetupCookiesByUrl("https://www.bing.com/translator", function()
			{
				window["msAppId"] = "-";
				callback();
			});
		}
	});
}

function RefreshYaAppId(callback)
{
	ExtractAppId("https://translate.yandex.com",
				//{"yaAppId": new RegExp("config\\s*=\\s*\\{\\s*SID:\\s*[\"']([^\"']+)[\"']", "im") },
				{"yaAppId": new RegExp(",\s+SID:\s*['\"]([^'\"]+)['\"],\s+", "im") },
				callback);
}

function RefreshUdAppId(callback)
{
	ExtractAppId("http://m.urbandictionary.com/javascripts/application.js",
				{"udAppId": new RegExp("\\?key=([0-9a-z]+)", "im") },
				callback);
}

function RefreshBdAppId(callback)
{
	ExtractAppId("https://fanyi.baidu.com/",
				{
					"bdSignId": new RegExp("window.gtk[\\s]*=[\\s]*['\"]([0-9\\.]+)['\"]", "im"),
					"bdAppId": new RegExp("token:[\\s]*['\"]([0-9a-z]+)['\"]", "im"),				// main var has to be last!
				},
				callback);
}


function IsTabCanReceiveMessage(tab, tab_port)
{
	if (!opera && (typeof tab_port == "undefined"))
		tab_port = false;	// old Opera can be `undefined`, but new Opera(Chrome) can't

	return tab
//			&& (tab_port && typeof (tab_port != "undefined"))	// for new Opera/Chrome
			&& (tab_port || (typeof tab_port == "undefined"))	// Back compatibility with old Operas
			&& (typeof tab.url != "undefined")
			&& (tab.url !== "")
			&& tab.url.indexOf("operaemail:/");	// if we can work with active page
}

function updateBandgeStatus(activeTab, activeTabPort)
{
	if (IsTabCanReceiveMessage(activeTab, activeTabPort))
	{
		setupBandgeIcon(0);
		(activeTabPort || activeTab).postMessage({ action:"get_active_page_selection" });
	}
	else	// Can't detect active page
	{
		setupBandgeIcon(-1);
	}
}

function CreateTabWithUrl(url)
{
	if (opera)
	{
		var newTab = opera.extension.tabs.create({ url:url, focused:true });
//		tab.focus();
	}
	else
	{
		if (lastActiveTab)
			var newTab = chrome.tabs.create({ url:url, active:true, index:lastActiveTab.index+1 });		// always next to active?
		else
			var newTab = chrome.tabs.create({ url:url, active:true });
	}

	if (opera && (opera.version()-0 < 12.1))
	{
		widget.cfg.getAsync("openNewTabsNextToActive", function(cfg)
		{
			if (cfg.openNewTabsNextToActive == "true")
			{
				var activeTab = opera.extension.tabs.getFocused();
				if (activeTab.tabGroup)
				{
					var allTabs = activeTab.tabGroup.tabs.getAll();
					var targetList = activeTab.tabGroup;
				}
				else
				{
					var allTabs = opera.extension.tabs.getAll();
					var targetList = activeTab.browserWindow;
				}

				var nextTab = null;
				var i, cnt = allTabs.length;
				for (i=0; i<cnt; i++)
					if ((allTabs[i].id == activeTab.id) && (i < cnt-1))
					{
						nextTab = allTabs[i+1];
						break;
					}

				targetList.insert(newTab, nextTab);
			}
		});
	}

	return newTab;
}


var onMessageHandler;
//window.addEventListener("load", function()
window.addEventListener("DOMContentLoaded", function()
{
	onMessageHandler = function(msg, sender, respFunc)		// global for possiblity call it from popup (Chrome)
	{
		if (opera)
		{
			sender = msg.source;
			msg = msg.data;
		}
		else if ((typeof sender == "undefined") && msg.source)
		{
			sender = msg.source;
		}

		var appIdName;
		var getAppIdName;
		var appIdWasRefreshed;
		var resp_msg;

		switch (msg.action)
		{
			case "bg_console_log":
				console.log([sender, msg.data]);
				break;

			case "get_sender_tab_info":
				respFunc( sender.tab );
				break;

			case "get_content_script_cfgs":	// from userJs, but only by Chrome
				widget.cfg.getAsync(msg.names, function(cfg)
				{
					respFunc( cfg );
				});
				break;

			case "tab_changed_url":	// from userJs
				if (opera)
					opera.extension.tabs.onfocus(null);
				// else Chrome has tabs.onActivated handler
				break;


			case "get_msAppId":
				if (typeof appIdName == "undefined")
				{
					resp_msg = { action:"setup_msAppId", value:msAppId, next_action:msg["next_action"], next_action_args:msg["next_action_args"] };
					appIdName = "msAppId";
					getAppIdName = "RefreshMsAppId";
					appIdWasRefreshedName = "msAppIdWasRefreshed";
				}
			case "get_yaAppId":
				if (typeof appIdName == "undefined")
				{
					resp_msg = { action:"setup_yaAppId", value:yaAppId, next_action:msg["next_action"], next_action_args:msg["next_action_args"] };
					appIdName = "yaAppId";
					getAppIdName = "RefreshYaAppId";
					appIdWasRefreshedName = "yaAppIdWasRefreshed";
				}
			case "get_udAppId":
				if (typeof appIdName == "undefined")
				{
					resp_msg = { action:"setup_udAppId", value:udAppId, next_action:msg["next_action"], next_action_args:msg["next_action_args"] };
					appIdName = "udAppId";
					getAppIdName = "RefreshUdAppId";
					appIdWasRefreshedName = "udAppIdWasRefreshed";
				}
			case "get_bdAppId":
				if (typeof appIdName == "undefined")
				{
					resp_msg = { action:"setup_bdAppId", value:bdAppId, value2:bdSignId, next_action:msg["next_action"], next_action_args:msg["next_action_args"] };
					appIdName = "bdAppId";
					appIdName2 = "bdSignId";
					getAppIdName = "RefreshBdAppId";
					appIdWasRefreshedName = "bdAppIdWasRefreshed";
				}
			case "get_xxAppId":	// used previous cases
				if (((resp_msg.value === "") && ((new Date()-window[appIdWasRefreshedName]) > 1000*5))							// not faster, than 5 seconds
					|| (msg.refresh && (resp_msg.value != "-")  && ((new Date()-window[appIdWasRefreshedName]) > 1000*5*60))	// not faster, than 5 minutes
					|| ((new Date()-window[appIdWasRefreshedName]) > 1000*3*60*60)												// not older, than 3 hours (TODO: test interval)
					)
				{
					// Warning! this function can be called from injected script => new temporary tabs can be loaded in the loop.
					window[getAppIdName](function()
					{
						window[appIdWasRefreshedName] = (new Date())-0;
						resp_msg.refreshed = 1;
						resp_msg.value = window[appIdName];		// new value
						if (typeof appIdName2 != "undefined")
							resp_msg.value2 = window[appIdName2];
						if (sender["onMessageHandler"])
							sender.onMessageHandler( resp_msg );
						else if (sender.postMessage)
							sender.postMessage( resp_msg );
						else if (respFunc)
							respFunc( resp_msg );
					});
				}
				else
				{
					if (sender["onMessageHandler"])
						sender.onMessageHandler( resp_msg );
					else if (sender.postMessage)
						sender.postMessage( resp_msg );
					else if (respFunc)
						respFunc( resp_msg );
				}
				break;


			// Deprecated?
			case "refresh_msAppId":
				RefreshMsAppId(function()
				{
					sender.postMessage({ action:"setup_msAppId", value:msAppId, refreshed:1 });
				});
				break;

			case "selection_changed":	// from userJs
				widget.cfg.getAsync("useSelMarker", function(cfg)
				{
					if ((cfg.useSelMarker == null) || (cfg.useSelMarker == "true"))
					{
						if (opera)
							tabs_ports[opera.extension.tabs.getFocused().id] = sender;		// fix for Opera. Sometimes it remember wrong port :/
						setupBandgeIcon( (msg.selection === "" ? 0 : 1) );
					}
				});
				activeTab_UUID = msg.uuid;	// selection can change only in active page
				break;

			case "get_active_page_data":	// from popup
				// always update lastActivePopup
				if (opera)
					lastActivePopup = (opera.extension.popup ? opera.extension.popup : sender);	// temporary, while Opera don't has it
				else
					lastActivePopup = chrome.extension.getViews({ "type":"popup" })[0];

//				var activeTab = opera.extension.tabs.getFocused();
				var activeTab = lastActiveTab;
				if (activeTab && IsTabCanReceiveMessage(activeTab, (opera ? activeTab.port : tabs_ports[activeTab.id])))
				{
					if (activeTab_UUID)
					{
						if (opera)
							opera.extension.broadcastMessage({ action:"get_active_page_data", uuid:activeTab_UUID });	// activeTab is not enough. Page can has a frames...
						else if (tabs_ports[activeTab.id])
							tabs_ports[activeTab.id].postMessage({ action:"get_active_page_data", uuid:activeTab_UUID });
					}
					else if (!opera && tabs_ports[activeTab.id])
						tabs_ports[activeTab.id].postMessage({ action:"get_active_page_data" });
					else if (opera && activeTab)
						(tabs_ports[activeTab.id] || activeTab.port).postMessage({ action:"get_active_page_data" });
				}
				else	// no tab? just return empty answer
				{
					if (opera)
					{
						if (lastActivePopup)
							lastActivePopup.postMessage({ action:"set_active_page_data" });
					}
					else if (sender && (typeof sender.onMessageHandler == "function"))
					{
						sender.onMessageHandler({ action:"set_active_page_data" }, window);
					}
					else if (lastActivePopup && lastActivePopup.onMessageHandler)
					{
						lastActivePopup.onMessageHandler({ action:"set_active_page_data" }, window);
					}
				}
				break;

			case "set_active_page_data":	// from userJs
				if (!activeTab_UUID || (activeTab_UUID && (msg.uuid == activeTab_UUID)))
				{
					if (opera)
						lastActivePopup.postMessage(msg);
					else
						lastActivePopup.onMessageHandler(msg, window);
				}
//				if (activeTab_UUID == msg.uuid)	// this message is consequence of direct message to require tab
//					opera.extension.broadcastMessage(request.data);	// TODO: send directly to popup, when it will be possible
				break;

			case "translate_url":	// from popup
				// fix bug with recursive reloading popup on trying open new tab while popup is opened
				theButton.disabled = true;

				if (opera)
					var activeTab = opera.extension.tabs.getFocused();
				else
					var activeTab = lastActiveTab;
				if (!msg.url && activeTab && (typeof activeTab.url != "undefined"))
					msg.url = activeTab.url;

				if (msg.url)
					CreateTabWithUrl(msg.prefixUrl + encodeURIComponent(msg.url));

				// fix bug with recursive reloading popup on trying open new tab while popup is opened
				theButton.disabled = false;
				break;

			case "setup_pragma_cookies":	// from popup
				SetupCookiesByUrl("http://online.translate.ua", function()
				{
					if (opera)
						sender.postMessage({ action:"retranslate_text" });
					else
						sender.onMessageHandler({ action:"retranslate_text" });
				});
				break;

			case "get_translated_selection":	// from userJs
				// TODO: open popup with translation, when it will be possible :/
				break;

			case "change_popup_size":	// from popup (Opera Classic)
				if (popupMinimumSize.width < ToolbarUIItemProperties.popup.width + msg.deltaX)
					theButton.popup.width = ToolbarUIItemProperties.popup.width + msg.deltaX;
				else
					theButton.popup.width = popupMinimumSize.width;

				if (popupMinimumSize.height < ToolbarUIItemProperties.popup.height + msg.deltaY)
					theButton.popup.height = ToolbarUIItemProperties.popup.height + msg.deltaY;
				else
					theButton.popup.height = popupMinimumSize.height;

				lastActivePopup = (opera.extension.popup ? opera.extension.popup : sender);	// temporary, while Opera don't has it
				lastActivePopup.postMessage({
					action: "fix_elements_size",
					deltaX: theButton.popup.width-popupMinimumSize.width,
					deltaY: theButton.popup.height-popupMinimumSize.height
				});
				break;

			case "save_popup_size":
				ToolbarUIItemProperties.popup.width = theButton.popup.width;
				ToolbarUIItemProperties.popup.height = theButton.popup.height;
				widget.cfg.setAsync( {"popupSize": theButton.popup.width + "x" + theButton.popup.height} );
				break;

			case "update_extension_button":
				widget.cfg.getAsync("useExtensionButton", function(cfg)
				{
					var useExtensionButton = ((cfg.useExtensionButton == null) || (cfg.useExtensionButton == "true"));

					if (opera.contexts.toolbar.length)
					{
						if (!useExtensionButton)
							opera.contexts.toolbar.removeItem( theButton );
					}
					else
					{
						if (useExtensionButton)
							opera.contexts.toolbar.addItem( theButton );
					}
				});
				break;

			case "create_tab_with_url":
				CreateTabWithUrl(msg.url);
				break;
		}

		return true;
	};


	widget.cfg.getAsync(["useExtensionButton", "msAppId", "yaAppId", "udAppId", "msAppIdWasRefreshed", "yaAppIdWasRefreshed", "udAppIdWasRefreshed"], function(cfg)
	{
		if (cfg.msAppId != null)	msAppId = cfg.msAppId;
		if (cfg.yaAppId != null)	yaAppId = cfg.yaAppId;
		if (cfg.udAppId != null)	udAppId = cfg.udAppId;
		if (cfg.msAppIdWasRefreshed != null)	msAppIdWasRefreshed = cfg.msAppIdWasRefreshed;
		if (cfg.yaAppIdWasRefreshed != null)	yaAppIdWasRefreshed = cfg.yaAppIdWasRefreshed;
		if (cfg.udAppIdWasRefreshed != null)	udAppIdWasRefreshed = cfg.udAppIdWasRefreshed;

		var useExtensionButton = ((cfg.useExtensionButton == null) || (cfg.useExtensionButton == "true"));

		if (opera)
		{
			theButton = opera.contexts.toolbar.createItem(ToolbarUIItemProperties);
			if (useExtensionButton)
				opera.contexts.toolbar.addItem(theButton);


			opera.extension.onmessage = onMessageHandler;

			opera.extension.tabs.onfocus = function(evt, port)
			{
				var activeTab = opera.extension.tabs.getFocused();
				if (activeTab)	// in Opera 11.xx it can be null
				{
					if (port)
						tabs_ports[activeTab.id] = port;									// fix port after tab change content
					updateBandgeStatus(activeTab, port || activeTab.port);
					lastActiveTab = activeTab;
				}
				else
					updateBandgeStatus(null);
			};
			opera.extension.tabs.onfocus();
		}
		else
		{
			theButton = chrome.browserAction;

			chrome.runtime.onConnect.addListener(function(port) {
				if (!port.sender.tab || (port.sender.url != port.sender.tab.url)) // skip start screen and [i]frames
					return;

				if (tabs_ports[port.sender.tab.id])
					port.onMessage.removeListener( onMessageHandler );

				tabs_ports[port.sender.tab.id] = port;
				port.onDisconnect.addListener(function()
				{
					port.onMessage.removeListener( onMessageHandler );
					delete tabs_ports[port.sender.tab.id];
				});
				port.onMessage.addListener( onMessageHandler );
				if (port.sender.tab.active)						// selected -> highlighted, but active is better?
					updateBandgeStatus(port.sender.tab, port);
			});

			chrome.runtime.onMessage.addListener( onMessageHandler );

			chrome.tabs.onActivated.addListener(function(activeInfo) {
				// tabs_ports setup at onConnect handler
				// TODO: check activeInfo.tabId on disconnect status (back action do not restore connection. Opera Next bug?)
				chrome.tabs.get(activeInfo.tabId, function(activeTab)
				{
					lastActiveTab = activeTab;
					if (lastActiveTab.url.indexOf("http") !== 0)					// we don't have access to internal pages
						updateBandgeStatus(activeTab, tabs_ports[activeTab.id]);
					else
					{
						// if this is new tab without connection => manual include script (extension was restarted)
						if (!tabs_ports[activeTab.id])
						{
							// tabs_ports will be filled in onConnect
							chrome.tabs.executeScript(lastActiveTab.id, { file:"includes/user_js.js", allFrames:true, runAt:"document_end" }, function(result)
							{
								if (chrome.runtime.lastError)
									console.log("Can't inject content script. " + chrome.runtime.lastError.message + " Address: " + lastActiveTab.url);

								// Warning: even if page has selection on this step, we ignore it, because we don't know source element, but we have to ignore some elements
								updateBandgeStatus(activeTab, tabs_ports[activeTab.id]);
							});
						}
						else
							updateBandgeStatus(activeTab, tabs_ports[activeTab.id]);
					}
				});
			});

			var UpdateActiveWindowBadge = function()
			{
				chrome.tabs.query({active:true, currentWindow:true}, function(activeTabs){
					if (activeTabs.length)
					{
						lastActiveTab = activeTabs[0];
						updateBandgeStatus(activeTabs[0], tabs_ports[activeTabs[0].id]);
					}
				});
			};

			chrome.windows.onFocusChanged.addListener(function(windowId)
			{
				if (windowId < 0)
					return;

				UpdateActiveWindowBadge();
			});


			UpdateActiveWindowBadge();
		}
	});

//	RefreshMsAppId();
//	RefreshUDAppId();
}, false );


function CreateOrRemovePageContextMenu()
{
	widget.cfg.getAsync("useContextMenuForPages", function(cfg)
	{
		if (cmForPage)
			chrome.contextMenus.remove(cmForPage);

		if ((cfg.useContextMenuForPages != null) && (cfg.useContextMenuForPages !== ""))
		{
			cmForPage = chrome.contextMenus.create({
													"id": "mn_translate_this_page",
													"title": WORDS.cmTranslatePage,
													"contexts": ["page"],
													"onclick": function(args)
														{
															// translate only external pages (Firefox can show this menu on extension's pages)
															if (args.pageUrl.indexOf("http") === 0)
															{
																widget.cfg.getAsync(["useContextMenuForPages", "useGoogleCn", "defTargetLang"], function(cfg)
																{
																	if ((cfg.useContextMenuForPages != null) && (cfg.useContextMenuForPages !== ""))
																	{
																		useGoogleCn = cfg.useGoogleCn;
																		var urlPrefix = GetTranslatedPageUrlPrefix(cfg.useContextMenuForPages, "", cfg.defTargetLang);
																		CreateTabWithUrl(urlPrefix + encodeURIComponent(args.pageUrl));
																	}
																});
															}
														}
													});
		}
	});
}


window.addEventListener("load", function()
{
	// only if browser support manual open popups
	if ((typeof chrome == "object") && chrome.browserAction && chrome.browserAction["openPopup"])
	{
		CreateOrRemovePageContextMenu();
		cmForSelection = chrome.contextMenus.create({
													"id": "mn_translate_this_selection",
													"title": WORDS.cmTranslateIt,
													"contexts": ["selection"],
													"onclick": function(args)
														{
															if (!is_firefox)
																// but Chrome support only this kind of using
																chrome.browserAction.openPopup(function(args)						// undocumeted function
																{
																	// error cases?
																});
															else
																chrome.browserAction.openPopup();	// firefox support this method without arguments
														}
													});
/*
		// TODO: test this method on chrome. Currently it doesn't work (70)
		if (is_firefox)
		{
			// Firefox support only this method of using `openPopup()`!
			chrome.menus.onClicked.addListener(function(info, tab) {
				if (info.menuItemId == "mn_translate_this_selection")
					chrome.browserAction.openPopup();	// firefox support this method without arguments
			});
		}
*/
	}
}, false);
