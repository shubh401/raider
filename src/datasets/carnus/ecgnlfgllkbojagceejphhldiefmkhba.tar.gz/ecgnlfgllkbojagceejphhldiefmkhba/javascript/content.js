/*
 * VNPT Chrome Token Sign extension
 *
 * Created by Tran Ha on 20/10/2015
 * Copyright (c) 2015 VNPT-CA. All rights reserved.
 * Lô 2A Làng Quốc tế Thăng Long, Nguyễn Phong Sắc, Phường Dịch Vọng, Quận Cầu Giấy, Hà Nội 
 * 
 */

var inuse = false;

// Forward the message from page.js to background.js
window.addEventListener("message", function(event) {
  
    // We only accept messages from ourselves
    if (event.source !== window)
        return;

    // and forward to extension
    if (event.data.src && (event.data.src === "page.js")) {
       // event.data["origin"] = location.origin;
       event.data["origin"] = '0';
        chrome.runtime.sendMessage(event.data, function(response) {
          //alert("forward to extension");
        });

        // Only add unload handler if extension has been used
        if (!inuse) {
            // close the native component if page unloads
            window.addEventListener("beforeunload", function(event) {
                chrome.runtime.sendMessage({src: 'page.js', type: 'DONE'});
            }, false);
            inuse = true;
        }
    }
}, false);

// post messages from extension to page
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    window.postMessage(request, '*');
});

// inject page.js to the DOM of every page
var s = document.createElement('script');
s.src = chrome.extension.getURL('page.js');

// remove script tag after script itself has loaded
s.onload = function() {this.parentNode.removeChild(this);};
(document.head || document.documentElement).appendChild(s);
