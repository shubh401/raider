define([
	"js/backbone/collections/GitHubDir.js", 
	"js/backbone/collections/Scripts.js", 
	"js/backbone/collections/Features.js", 
	"js/backbone/collections/Sources.js", 
	"js/backbone/models/Script.js", 
	"js/backbone/models/Feature.js", 
	"js/backbone/helpers/GitHubHelper.js"
], function(GitHubDir, ScriptCollection, FeatureCollection, SourceCollection, ScriptModel, FeatureModel, GitHubHelper){
	
	return {
		
		load: function(){
			var me = this;
			var deferred = $.Deferred();
			var sourceCollection = new SourceCollection();
			
			sourceCollection.fetchSources().done(function(){
				chrome.storage.local.get(function(data){
					if(data.scripts !== undefined){
						return me.restoreData(JSON.parse(data.scripts))
							.done(function(scriptCollections){
								deferred.resolve(scriptCollections);
							})
							.fail(deferred.fail);
					}
					
					GitHubHelper.fetchSourceCollection(sourceCollection)
						.done(function(result){
							chrome.storage.local.set({
								scripts: JSON.stringify(result.scripts) // storage seems to mess with this if we store it as an object, so lets stringify first
							}, function(data){
								deferred.resolve(result.scriptCollections);
							});
						})
						.fail(deferred.reject);
				});
			});
			
			return deferred.promise();
		}, 
		
		restoreData: function(scripts){
			var scriptCollections = [];
			
			for(var repositoryUrl in scripts){
				var scriptCollection = new ScriptCollection(scripts[repositoryUrl]);
				scriptCollections.push(scriptCollection);
			}
			
			return GitHubHelper.updateScriptCollectionsInstalledFlags(scriptCollections);
		}
	};
});
