define([
	"js/backbone/models/GitHubEntry.js", 
	"js/backbone/collections/GitHubDir.js", 
	"js/backbone/collections/Scripts.js", 
	"js/backbone/collections/Features.js", 
	"js/backbone/models/Script.js"
	], function(GitHubEntry, GitHubDir, ScriptCollection, FeatureCollection, ScriptModel){
	var GitHubHelper = {
		
		gitHubDirToScriptCollection: function(gitHubDir){
			var me = this;
			var deferred = $.Deferred();
			
			var promises = gitHubDir.map(function(gitHubEntry){
				if(gitHubEntry.get("type") !== "dir"){
					return;
				}
				
				var gitHubDir = new GitHubDir();
				gitHubDir.url = gitHubEntry.get("url");
				
				var deferred = $.Deferred();
				
				gitHubDir.fetch().done(function(){
					me.fetchScript(gitHubDir, gitHubEntry)
						.done(deferred.resolve)
						.fail(deferred.reject);
				}).fail(deferred.reject);
				
				return deferred.promise();
			});
			
			$.when.apply($, promises).done(function(){
				var scripts = Array.prototype.slice.call(arguments);
				var scriptCollection = new ScriptCollection(scripts);
				
				me.updateScriptCollectionsInstalledFlags([scriptCollection]).done(function(){
					deferred.resolve(scriptCollection, scripts);
				}).fail(deferred.reject);
			}).fail(deferred.reject);
			
			return deferred.promise();
		}, 
		
		fetchScript: function(gitHubDir, gitHubEntry){
			var me = this;
			var deferred = $.Deferred();
			var metadataEntry = gitHubDir.findWhere({
				name: "metadata.json"
			}); 
			
			if(metadataEntry === undefined){
				throw "Missing metadata.json";	
			}
			
			var metadataFile = new GitHubEntry();
			metadataFile.url = metadataEntry.get("url");
			
			metadataFile.fetch().done(function(){
				var script = new ScriptModel(JSON.parse(atob(metadataFile.get("content"))));
				script.set("id", gitHubEntry.get("path").replace(/extensions\/(.*)/, "$1"));
				var baseUrl = gitHubDir.url.replace(/^(.*)\?.*$/, "$1") + "/";
				
				me.populateScriptContent(script, baseUrl).done(function(){
					deferred.resolve(script);
				}).fail(deferred.reject);
			}).fail(deferred.reject);
			
			return deferred.promise();
		}, 
		
		populateScriptContent: function(script, baseUrl){
			var me = this;
			var requests = [];
			
			script.get("features").forEach(function(feature){
				var jsRequest = me.requestFileContent(baseUrl + feature.js);
				var cssRequest = me.requestFileContent(baseUrl + feature.css);
				
				requests.push(jsRequest);
				requests.push(cssRequest);
				
				jsRequest.done(function(content){
					feature.js = content;
				});
				
				cssRequest.done(function(content){
					feature.css = content;
				});
			});
			
			return $.when.apply($, requests);
		}, 
		
		requestFileContent: function(url){
			var deferred = $.Deferred();
			var file = new GitHubEntry();
			file.url = url;
			
			file.fetch().done(function(){
				deferred.resolve(atob(file.get("content")));
			}).fail(deferred.reject);
			
			return deferred.promise();
		}, 
		
		updateScriptCollectionsInstalledFlags: function(scriptCollections){
			var deferred = $.Deferred();
			var me = this;
			
			chrome.storage.sync.get(function(data){
				scriptCollections.forEach(function(scriptCollection){
					scriptCollection.forEach(function(model){
						var installedFeatures = (data.installed && data.installed[model.get("id")] ? data.installed[model.get("id")] : []);
						var features = new FeatureCollection(model.get("features"));
						
						features.forEach(function(feature){
							var featureInstalled = (installedFeatures.indexOf(feature.get("id")) !== -1);
							feature.set("installed", featureInstalled);
						});
						
						model.set("features", features);
					});
				});
				
				deferred.resolve(scriptCollections);
			});
			
			return deferred.promise();
		}, 
		
		fetchSource: function(source){
			var deferred = $.Deferred();
			var gitHubDir = new GitHubDir();
			gitHubDir.url = source.get("url");
			
			gitHubDir.fetch()
				.done(function(){
					GitHubHelper.gitHubDirToScriptCollection(gitHubDir)
						.done(function(scriptCollection, scripts){
							deferred.resolve({
								source: source, 
								scriptCollection: scriptCollection, 
								scripts: scripts
							});
						})
						.fail(deferred.reject);
				})
				.fail(deferred.reject);
			
			return deferred.promise();
		}, 
		
		fetchSourceCollection: function(sourceCollection){
			var me = this;
			var deferred = $.Deferred();
			var deferreds = [];
			
			sourceCollection.forEach(function(source){
				deferreds.push(GitHubHelper.fetchSource(source));
			});
			
			$.when.apply(me, deferreds).done(function(){
				var args = Array.prototype.slice.call(arguments);
				var scripts = {};
				var scriptCollections = [];
				
				args.forEach(function(entry){
					scripts[entry.source.get("url")] = entry.scripts;
					scriptCollections.push(entry.scriptCollection);
				});
				
				deferred.resolve({
					scripts: scripts, 
					scriptCollections: scriptCollections
				});
			}).fail(deferred.reject);
			
			return deferred.promise();
		}
		
	};
	
	return GitHubHelper;
});

