define(["text!js/backbone/templates/features.html", "js/backbone/collections/Features.js", "js/backbone/views/Feature.js"], function(template, FeatureCollection, FeatureView){
	return Backbone.View.extend({
		
		tagName: "tr", 
		
		template: _.template(template), 
		
		initialize: function(){
			this.model.on("change", this.render, this);
		},
		
		events: {
			
		}, 
		
		render: function(){
			var me = this;
			
			if(!me.model.isInstalled()){
				me.$el.html("");
				return me;
			}
			
			me.$el.html(me.template());
			var featuresElement = me.$el.find(".features");
			featuresElement.html("");
			
			var featureCollection = me.model.get("features");
			
			featureCollection.forEach(function(featureModel){
				console.log("featureModel", featureModel);
				featuresElement.append((new FeatureView({
					model: featureModel, 
					scriptModel: me.model
				})).render().$el);
			});
			
			return me;
		}
		
	});
});