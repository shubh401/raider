define(["text!js/backbone/templates/feature.html"], function(template){
	return Backbone.View.extend({
		
		tagName: "li", 
		
		template: _.template(template), 
		
		initialize: function(options){
			this.options = options;
			this.model.on("change", this.render, this);
		},
		
		events: {
			"click [data-action=enable]": function(event){
				var me = this;
				event.preventDefault();
				me.options.scriptModel.installFeatureSync(me.model.get("id"));
			}, 
			
			"click [data-action=disable]": function(event){
				var me = this;
				event.preventDefault();
				console.log(me.options.scriptModel);
				me.options.scriptModel.uninstallFeatureSync(me.model.get("id"));
			}
		}, 
		
		render: function(){
			var me = this;
			
			me.$el.html(me.template({
				id: me.model.get("id"), 
				installed: me.model.get("installed"), 
				name: me.model.get("name")
			}));
			
			return me;
		}
		
	});
});