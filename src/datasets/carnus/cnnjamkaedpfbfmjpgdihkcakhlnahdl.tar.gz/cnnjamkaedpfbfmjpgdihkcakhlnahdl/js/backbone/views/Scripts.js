define(["js/backbone/views/Script.js", "js/backbone/views/Features.js"], function(ScriptView, FeaturesView){
	return Backbone.View.extend({
		
		initialize: function(options){
			var me = this;
			me.options = options;
			$(document).on("render", function(){
				me.render();
			});	
		}, 
		
		render: function(){
			this.$el = $("<table/>");
			//var thead = $("<thead/>").appendTo(this.$el);
			//thead.append('<tr><th>Name</th><th></th></tr>');
			var tbody = $("<tbody/>").appendTo(this.$el);
			this.options.collections.forEach(function(collection){
				collection.forEach(function(model){
					console.log("ScriptsView, model features", model.get("features"));
					tbody.append(new ScriptView({
						model: model
					}).render().$el);
					
					tbody.append(new FeaturesView({
						model: model
					}).render().$el);
				});
			});
			
			return this;
		}
		
	});
});