define([
	"text!js/backbone/templates/sources.html", 
	"js/backbone/collections/Sources.js", 
	"js/backbone/models/Source.js", 
	"js/backbone/views/Source.js"
], function(template, SourceCollection, SourceModel, SourceView){
	return Backbone.View.extend({
		
		template: _.template(template), 
		
		initialize: function(options){
			this.options = options;
			//this.model.on("change", this.render, this);
		},
		
		events: {
			"submit [data-action=add-source]": function(event){
				var me = this;
				event.preventDefault();
				
				var rawSource = {
					url: $(event.target).find(".add-source-input").val().trim()
				};
				
				if(rawSource.url.length <= 0){
					alert("No source specified");
					return;
				}
				
				me.options.collection.push(rawSource);
				me.options.collection.saveSources().done(function(){
					me.render();
				});
			}
		}, 
		
		render: function(){
			var me = this;
			
			me.$el.html(me.template());
			var sourcesElement = me.$el.find(".sources");
			sourcesElement.html("");
			
			me.options.collection.forEach(function(sourceModel){
				console.log("sourceModel", sourceModel);
				sourcesElement.append((new SourceView({
					model: sourceModel, 
					sourceCollection: me.options.collection, 
					sourcesView: me
				})).render().$el);
			});
			
			return me;
		}
		
	});
});