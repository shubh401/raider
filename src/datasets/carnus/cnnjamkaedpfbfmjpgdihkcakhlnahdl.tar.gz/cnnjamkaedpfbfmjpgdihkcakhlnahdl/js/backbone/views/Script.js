define(["text!js/backbone/templates/script.html"], function(template){
	return Backbone.View.extend({
		
		tagName: "tr", 
		
		template: _.template(template), 
		
		initialize: function(){
			this.model.on("change", this.render, this);
		},
		
		events: {
			"click [data-action=install]": function(event){
				event.preventDefault();
				var me = this;
				me.model.installFeatureSync(0);
			}, 
			
			"click [data-action=uninstall]": function(event){
				event.preventDefault();
				var me = this;
				me.model.uninstallFeatureSync(0);
			}
		}, 
		
		render: function(){
			var me = this;
			
			me.$el.html(me.template({
				installed: me.model.isInstalled(), 
				url: me.model.get("url"), 
				name: me.model.get("name")
			}));
			
			return me;
		}
		
	});
});