define(["text!js/backbone/templates/source.html"], function(template){
	return Backbone.View.extend({
		
		tagName: "li", 
		
		template: _.template(template), 
		
		initialize: function(options){
			this.options = options;
			this.model.on("change", this.render, this);
		},
		
		events: {
			"click [data-action=remove]": function(event){
				var me = this;
				event.preventDefault();
				
				me.options.sourceCollection.remove(me.model);
				me.options.sourceCollection.saveSources().done(function(){
					me.options.sourcesView.render();
				});
			}
		}, 
		
		render: function(){
			var me = this;
			
			me.$el.html(me.template({
				url: me.model.get("url")
			}));
			
			return me;
		}
		
	});
});