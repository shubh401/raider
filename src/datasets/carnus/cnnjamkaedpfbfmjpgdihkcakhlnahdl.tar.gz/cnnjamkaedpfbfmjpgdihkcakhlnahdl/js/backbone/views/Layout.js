define(["text!js/backbone/templates/layout.html", "js/backbone/collections/Sources.js", "js/backbone/views/Sources.js"], function(template, SourceCollection, SourcesView){
	return Backbone.View.extend({
		
		template: _.template(template), 
		
		events: {
			"click [data-action=reload-scripts]": function(event){
				event.preventDefault();
				
				chrome.storage.local.remove("scripts", function(data){
					window.location.reload();
				});
			}, 
			
			"click [data-action=open-side-panel]": function(){
				$("#side-panel, #side-panel-overlay").fadeIn();
				$("#side-panel > [data-action=add-source] .add-source-input").focus();
			}, 
			
			"click #side-panel-overlay": function(){
				$("#side-panel, #side-panel-overlay").fadeOut();
			}, 
		}, 
		
		render: function(){
			var me = this;
			
			me.$el.addClass("content");
			me.$el.html(me.template());
			
			var sourceCollection = new SourceCollection();
			sourceCollection.fetchSources().done(function(){
				me.$el.find("#side-panel").html((new SourcesView({
					layout: me, 
					collection: sourceCollection
				})).render().$el);
			});
			
			return me;
		}
		
	});
});