define(["js/backbone/models/GitHubEntry.js", "js/backbone/collections/Scripts.js"], function(GitHubEntry, ScriptCollection){
	var GitHubDir = Backbone.Collection.extend({
		
		model: GitHubEntry, 
		
		toScriptCollection: function(){
			var me = this;
			var deferred = $.Deferred();
			
			var promises = me.map(function(gitHubEntry){
				if(gitHubEntry.get("type") !== "dir"){
					return;
				}
				
				var gitHubDir = new GitHubDir();
				gitHubDir.url = gitHubEntry.get("url");
				
				var deferred = $.Deferred();
				gitHubDir.fetch().done(function(){
					me.fetchScript(gitHubDir)
						.done(deferred.resolve)
						.fail(deferred.reject);
				}).fail(deferred.reject);
				
				return deferred.promise();
			});
			
			$.when.apply($, promises).done(function(){
				deferred.resolve(new ScriptCollection(arguments));
			}).fail(deferred.reject);
			
			return deferred.promise();
		}, 
		
		fetchScript: function(gitHubDir, deferred){
			var deferred = $.Deferred();
			var metadataEntry = gitHubDir.findWhere({
				name: "metadata.json"
			}); 
			
			if(metadataEntry === undefined){
				throw "Missing metadata.json";	
			}
			
			var metadataFile = new GitHubEntry();
			metadataFile.url = metadataEntry.get("url");
			
			metadataFile.fetch().done(function(){
				var scriptJson = JSON.parse(atob(metadataFile.get("content")));
				console.log("Fetched script from github", scriptJson);
				deferred.resolve(scriptJson);
			}).fail(deferred.reject);
			
			return deferred.promise();
		}
		
	});
	
	return GitHubDir;
});

