define(["js/backbone/models/Source.js"], function(Source){
	return Backbone.Collection.extend({
		
		model: Source, 
		
		defaultSources: [
			"https://api.github.com/repos/azu-/paketti/contents/extensions?ref=master"
		], 
	
		fetchSources: function(){
			var me = this;
			var deferred = $.Deferred();
			
			chrome.storage.sync.get(function(data){
				me.reset(data.sources || []);
				
				if(me.length <= 0){
					me.defaultSources.forEach(function(sourceUrl){
						me.push({
							url: sourceUrl
						});
					});
					
					me.saveSources().done(function(){
						deferred.resolve();
					});	
					
					return;
				}
				
				deferred.resolve();
			});
			
			return deferred.promise();
		}, 
		
		saveSources: function(){
			var me = this;
			var deferred = $.Deferred();
			
			chrome.storage.sync.get(function(data){
				data.sources = _.uniq(me.toJSON());
				
				chrome.storage.sync.set(data, function(){
					deferred.resolve();
				});
			});
			
			return deferred.promise();
		}
		
		
	});
});

