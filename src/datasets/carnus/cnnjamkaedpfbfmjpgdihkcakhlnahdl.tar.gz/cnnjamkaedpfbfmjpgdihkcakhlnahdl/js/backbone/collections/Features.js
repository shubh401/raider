define(["js/backbone/models/Feature.js"], function(Feature){
	return Backbone.Collection.extend({
		
		model: Feature, 
		
	});
});

