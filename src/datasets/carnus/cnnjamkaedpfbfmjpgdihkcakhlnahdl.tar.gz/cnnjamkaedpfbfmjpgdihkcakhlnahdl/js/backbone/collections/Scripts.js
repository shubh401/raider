define(["js/backbone/models/Script.js", "js/backbone/collections/Features.js"], function(Script, FeatureCollection){
	return Backbone.Collection.extend({
		
		model: Script, 
		
	});
});

