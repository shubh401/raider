define(["js/backbone/collections/Features.js"], function(FeatureCollection){
	return Backbone.Model.extend({
		
		name: null, 
		
		url: null, 
		
		features: null, 
		
		initialize: function() {
			var me = this;
		}, 
		
		isInstalled: function(){
			return (this.getInstalledFeatures().length > 0);	
		}, 
		
		getInstalledFeatures: function(){
			return this.get("features").where({
				installed: true
			});
		}, 
		
		installFeature: function(id){
			this.setFeatureInstalled(id, true);
		}, 
		
		uninstallFeature: function(id){
			this.setFeatureInstalled(id, false);
		}, 
		
		setFeatureInstalled: function(id, installed){
			var me = this;
			var features = me.get("features");
			console.log("features", features);
			console.log("find feature by id", id);
			var feature = features.findWhere({id: id});
			
			if(feature === undefined){
				console.warn("feature to install does not exist with id", id);
				return;
			}
			
			feature.set("installed", installed);
			me.set("features", features);
			console.log("feature installed", feature.get("id"));
		}, 
		
		installFeatureSync: function(featureId){
			var me = this;
			
			chrome.storage.sync.get(function(data){
				console.log("INSTALL chrome sync data", data);
				console.log("model", me);
				var installedFeatures = (data.installed && data.installed[me.get("id")] ? data.installed[me.get("id")] : []);
				
				data.installed = data.installed || {};
	
				installedFeatures.push(featureId);
				installedFeatures = _.uniq(installedFeatures);
				console.log("set installed features", installedFeatures);
				console.log("model id", me.get("id"));
				data.installed[me.get("id")] = installedFeatures;
				console.log("sync set", data);
				
				chrome.storage.sync.set(data, function(){
					console.log("saved");
					
					me.installFeature(featureId);
					me.trigger("change");
					$(document).trigger("render");
					
					console.log("reload");
					chrome.tabs.reload();
				});
			});
		},
		
		uninstallFeatureSync: function(featureId){
			var me = this;
			
			chrome.storage.sync.get(function(data){
				console.log("UNINSTALL chrome sync data", data);
				var installedFeatures = (data.installed && data.installed[me.get("id")] ? data.installed[me.get("id")] : []);
				data.installed = data.installed || {};
				console.log("set installed features", installedFeatures);
				data.installed[me.get("id")] = installedFeatures;
				var index = installedFeatures.indexOf(featureId);
				installedFeatures.splice(index, 1);
				
				console.log("sync set", data);
				
				chrome.storage.sync.set(data, function(){
					console.log("saved");
					
					me.uninstallFeature(featureId);
					me.trigger("change");
					$(document).trigger("render");
					
					console.log("reload");
					chrome.tabs.reload();
				});
			});
		}
		
	});
});

