define([], function(){
	return Backbone.Model.extend({
		
		url: null
		
	});
});

