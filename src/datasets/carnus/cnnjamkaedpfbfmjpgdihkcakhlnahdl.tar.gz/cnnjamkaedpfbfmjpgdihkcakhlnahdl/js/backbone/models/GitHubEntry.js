define([], function(){
	return Backbone.Model.extend({
		
		name: null, 
		url: null, 
		type: null, 
		path: null
		
	});
});

