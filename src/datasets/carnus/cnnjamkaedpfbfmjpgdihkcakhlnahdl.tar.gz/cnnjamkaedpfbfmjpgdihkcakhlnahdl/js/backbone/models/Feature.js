define([], function(){
	return Backbone.Model.extend({
		
		installed: false, 
		
		initialize: function() {
			var me = this;
		}
		
	});
});

