(function(){
	var Popup = window.Popup = function(){
		var gitHubDir = null;
		var element = null;
		var utils = {};
		
		var init = function(){
			$(function(){
				$.when(
					$.getScript("js/ext/underscore-min.js"), 
					$.getScript("js/ext/require.js")
				).done(function(){
					require([
						"js/ext/jquery-1.11.1.min.js", 
						"js/ext/underscore-min.js", 
						"js/ext/backbone-min.js", 
						"js/backbone/views/Scripts.js", 
						"js/backbone/collections/Scripts.js", 
						"js/backbone/views/Layout.js", 
						"js/Paketti.js", 
						"js/backbone/collections/Sources.js"
					], function(jquery, underscore, Backbone, ScriptsView, ScriptCollection, LayoutView, Paketti, SourceCollection){
						window.Backbone = Backbone;
						//bindEvents();
						
						element = $(this);
						utils.ScriptsView = ScriptsView;
						utils.ScriptCollection = ScriptCollection;
						utils.LayoutView = LayoutView;
						utils.SourceCollection = SourceCollection;
						
						Paketti.load().done(render).fail(function(){
							$("body").text("Error loading something. Resetting to default sources...");
							
							setTimeout(function(){
								chrome.storage.sync.remove("sources", function(data){
									window.location.reload();
								});
							}, 2000);
						});
					});
				}).fail(function(){
					console.log("error");
				});
			});
		};
		
		var render = function(scriptCollections){
			var layout = new utils.LayoutView().render().$el;
			
			var scriptsView = new utils.ScriptsView({
				collections: scriptCollections
			}).render().$el;
			
			layout.find(".paketti-content").html(scriptsView);
			$("body").html(layout);
			
			$("#paketti").data("initialized", true);
		};
		
		init();
	};
	
	new Popup();
})();