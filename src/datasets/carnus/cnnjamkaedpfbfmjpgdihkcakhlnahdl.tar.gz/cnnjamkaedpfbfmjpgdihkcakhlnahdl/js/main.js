(function(){
	// this is required to use require js in content_scripts
	require.load = function (context, moduleName, url) {
	    var xhr;
	    xhr = new XMLHttpRequest();
	    xhr.open("GET", chrome.extension.getURL(url) + '?r=' + new Date().getTime(), true);
	    xhr.onreadystatechange = function (e) {
	        if (xhr.readyState === 4 && xhr.status === 200) {
	            eval(xhr.responseText);
	            context.completeLoad(moduleName);
	        }
	    };
	    xhr.send(null);
	};
	
	requirejs.config({
	    shim: {
	        'js/ext/jquery-1.11.1.min': {
	            exports: '$'
	        },
	        'js/ext/underscore-min': {
	            exports: '_'
	        },
	        'js/ext/backbone-min': {
	            deps: ['js/ext/underscore-min', 'js/ext/jquery-1.11.1.min'],
	            exports: 'Backbone'
	        }
	    }
	});
	
	var Main = function(){
		var init = function(){
			$(function(){
				$.getScript(chrome.extension.getURL("js/ext/require.js"), function(){
					require([
						"js/ext/jquery-1.11.1.min", 
						"js/ext/underscore-min", 
						"js/ext/backbone-min", 
					], function(jquery, underscore, Backbone){
						window.Backbone = Backbone;
						
						require([
							"js/backbone/collections/Scripts", 
							"js/backbone/collections/GitHubDir", 
							"js/backbone/collections/Sources", 
							"js/backbone/helpers/GitHubHelper", 
							"js/Paketti.js"
						], function(ScriptsCollection, GitHubDir, SourceCollection, GitHubHelper, Paketti){
							applyScripts(ScriptsCollection, GitHubDir, SourceCollection, GitHubHelper, Paketti);
						});
					});
				});
			});
		};
		
		var applyScripts = function(ScriptsCollection, GitHubDir, SourceCollection, GitHubHelper, Paketti){
			var sourceCollection = new SourceCollection();
			
			Paketti.load().done(function(scriptCollections){
				scriptCollections.forEach(function(scriptCollection){
					scriptCollection.forEach(function(scriptModel){
						var regex = new RegExp(scriptModel.get("url")); 
						if(window.location.href.match(regex) !== null){
							applyInstalledFeatures(scriptModel.get("features"));
						}
					});
				});
			}).fail(function(error){
				console.log("error", error);
			});
		};
		
		var applyInstalledFeatures = function(features){
			var installedFeatures = features.where({
				installed: true	
			});
			
			installedFeatures.forEach(function(feature){
				var js = feature.get("js");
				var css = feature.get("css");
				
				eval(js);
				
				var style = $("<style/>", {type: "text/css"}).html(css);
				$("head").append(style);
			});
		};
		
		init();
	};
	
	new Main();
})();
